declare module "*.css" {
  const classes: { readonly [key: string]: string };
  export default classes;
}

declare module "*.module.scss" {
  const classes: { readonly [key: string]: string };
  export default classes;
}

// custom.d.ts
declare module "*.mp3" {
  const src: string;
  export default src;
}

declare module "*.png" {
  const value: string;
  export default value;
}
declare module "*.m4a" {
  const src: string;
  export default src;
}

declare module "howler" {
  export class Howl {
    constructor(options: {
      src: string[];
      autoplay?: boolean;
      loop?: boolean;
      volume?: number;
      onend?: () => void;
      onload?: () => void;
      onplay?: () => void;
      onpause?: () => void;
      onstop?: () => void;
      onloaderror?: (id: number, error: any) => void;
      onplayerror?: (id: number, error: any) => void;
    });
    play(): void;
    pause(): void;
    stop(): void;
    seek(time: number): void;
    duration(): number;
    on(event: string, callback: () => void): void;
  }

  export class Howler {
    static volume(value: number): void;
    static mute(muted: boolean): void;
  }
}
