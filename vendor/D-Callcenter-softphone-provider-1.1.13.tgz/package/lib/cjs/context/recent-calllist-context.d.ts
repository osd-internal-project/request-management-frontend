/// <reference types="react" />
import { PropsReact } from "../type/props";
type RecentCallListContextType = {
    recentCallList: any;
    setRecentCallList: (recentCallList: any) => void;
    fetch: boolean;
    setFetch: (fetch: boolean) => void;
    uuid: string;
    setUUID: (uuid: string) => void;
};
export declare const RecentCallListProvider: ({ children }: PropsReact) => import("react/jsx-runtime").JSX.Element;
export declare const RecentCallListConsumer: import("react").Consumer<RecentCallListContextType>;
export declare const useRecentCallList: () => RecentCallListContextType;
export {};
