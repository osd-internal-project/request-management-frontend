import React from 'react';
interface ThemeColorContextProps {
    buttonColor: string;
    backgroundColor: string;
    textColor: string;
    setThemeColor: (theme: Partial<ThemeColorContextProps>) => void;
}
export declare const ThemeColorProvider: React.FC<{
    children: React.ReactNode;
}>;
export declare const useThemeColor: () => ThemeColorContextProps;
export {};
