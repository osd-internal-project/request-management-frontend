/// <reference types="react" />
import PropTypes from "prop-types";
import { PropsReact } from "../type/props";
type VideoLayoutContextType = {
    videoLayout: boolean;
    setVideoLayout: (videoLayout: boolean) => void;
};
export declare const VideoLayoutProvider: {
    ({ children }: PropsReact): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
    };
};
export declare const WebcamConsumer: import("react").Consumer<VideoLayoutContextType>;
export declare const useContainerLayout: () => VideoLayoutContextType;
export {};
