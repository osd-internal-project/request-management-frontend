import React from "react";
export type ListType = {
    [key: string]: any;
};
export type SelectionHandler = (selectedItem: ListType) => void;
interface SelectStatusContextProps {
    statusList: ListType[];
    setStatusList: (list: (ListType | string)[]) => void;
    selectedStatus: ListType | undefined;
    setSelectedStatus: (status: ListType) => void;
    onSelect: SelectionHandler;
    setOnSelect: (handler: SelectionHandler) => void;
    displayField: string;
    setDisplayField: (field: string) => void;
    placeholder: string;
    setPlaceholder: (customPlaceholder: string) => void;
}
export declare const SelectStatusProvider: React.FC<{
    children: React.ReactNode;
}>;
export declare const SelectStatusContextConsumer: React.Consumer<SelectStatusContextProps>;
declare const useSelectStatusContext: () => SelectStatusContextProps;
export default useSelectStatusContext;
