/// <reference types="react" />
import { SetStateAction } from "../lib/hook";
import { PropsReact } from "../type/props";
import Delegate from "../lib/call-manager";
/**
 * @param socketServer Web Socket Server eg. wss://<host>/ws.
 * @param username Username Voip Server.
 * @param password Password Voip Server.
 * @param ipServer Username Voip Server eg. <host>.
 * @param displayName Display name .
 * @param organizeName Organize name .
 * @param iconOnline Icon online .
 * @param iconOffline Icon offline .
 * @param isUserFavoriteVisible Control visibility of the favorite button.
 * @param isUserRecentVisible Control visibility of the recent button.
 * @param isUserContactVisible Control visibility of the contact button.
 * @param isUserNumpadVisible Control visibility of the numpad button.
 * @param notificationVisible Control visibility of notifications.
 * - @param isBusy Indicates if the user is currently busy.
 * @param ringtoneCallUrl URL for the ringtone during an outgoing call.
 * @param ringtoneReceiveUrl URL for the ringtone during an incoming call.
 * @param externalRecentCallListDatabase use external Recent Call List or not.
 * @param externalContactCallListDatabase use external Contact Call ist or not.
 * @param limitDigit Limit digit for the phone number.  Default is 10.
 * @param duration Duration for DTMF signal transmission in milliseconds. Default is 2000.
 */
type SoftPhoneUserType = {
    socketServer: string;
    username: string;
    password: string;
    ipServer: string;
    displayName: string;
    organizeName: string;
    iconOnline?: React.ReactNode;
    iconOffline?: React.ReactNode;
    isUserFavoriteVisible: boolean;
    isUserRecentVisible: boolean;
    isUserContactVisible: boolean;
    isUserNumpadVisible: boolean;
    notificationVisible?: {
        isBusy?: boolean;
    };
    ringtoneCallUrl: string;
    ringtoneReceiveUrl: string;
    externalRecentCallListDatabase?: boolean;
    externalContactCallListDatabase?: boolean;
    limitDigit?: number;
    duration?: number;
};
type SoftPhoneUserContextType = {
    user: SoftPhoneUserType;
    /**
     * @param socketServer Web Socket Server eg. wss://<host>/ws.
     * @param username Username Voip Server.
     * @param password Password Voip Server.
     * @param ipServer Username Voip Server eg. <host>.
     * @param displayName Display name .
     * @param organizeName Organize name .
     * @param iconOnline Icon online .
     * @param iconOffline Icon offline .
     * @param isUserFavoriteVisible Control visibility of the favorite button.
     * @param isUserRecentVisible Control visibility of the recent button.
     * @param isUserContactVisible Control visibility of the contact button.
     * @param isUserNumpadVisible Control visibility of the numpad button.
     * @param notificationVisible Control visibility of notifications.
     * - @param isBusy Indicates if the user is currently busy.
     * @param ringtoneCallUrl URL for the ringtone during an outgoing call.
     * @param ringtoneReceiveUrl URL for the ringtone during an incoming call.
     * @param externalRecentCallListDatabase use external Recent Call List or not.
     * @param externalContactCallListDatabase use external Contact Call ist or not.
     * @param limitDigit Limit digit for the phone number.  Default is 10.
     * @param duration Duration for DTMF signal transmission in milliseconds. Default is 2000.
     */
    set: (newState: SetStateAction<SoftPhoneUserType>) => void;
    delegate: Delegate;
};
export declare const SoftPhoneUserProvider: ({ children }: PropsReact) => import("react/jsx-runtime").JSX.Element;
export declare const SoftPhoneUserConsumer: import("react").Consumer<SoftPhoneUserContextType | null>;
declare const useSoftPhoneUser: () => SoftPhoneUserContextType | null;
export default useSoftPhoneUser;
