/// <reference types="react" />
import { SetStateAction } from "../lib/hook";
import { PropsReact } from "../type/props";
export type PhoneStatusType = {
    created: boolean;
    answer: boolean;
    mute: boolean;
    hold: boolean;
    conference: boolean;
};
type PhoneStatusContextType = {
    phoneStatus: PhoneStatusType;
    setPhoneStatus: (newState: SetStateAction<PhoneStatusType>) => void;
};
export declare const PhoneStatusProvider: ({ children }: PropsReact) => import("react/jsx-runtime").JSX.Element;
export declare const PhoneStatusConsumer: import("react").Consumer<PhoneStatusContextType>;
export declare const usePhoneStatus: () => PhoneStatusContextType;
export {};
