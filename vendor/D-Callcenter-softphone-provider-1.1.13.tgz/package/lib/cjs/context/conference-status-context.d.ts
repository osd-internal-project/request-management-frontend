/// <reference types="react" />
import { SetStateAction } from "../lib/hook";
import { PropsReact } from "../type/props";
type ConferenceStatusType = {
    created: boolean;
    answer: boolean;
    mute: boolean;
    hold: boolean;
    conference: boolean;
};
type ConferenceStatusContextType = {
    conferenceStatus: ConferenceStatusType;
    setConferenceStatus: (newState: SetStateAction<ConferenceStatusType>) => void;
};
export declare const ConferenceStatusProvider: ({ children }: PropsReact) => import("react/jsx-runtime").JSX.Element;
export declare const ConferenceStatusConsumer: import("react").Consumer<ConferenceStatusContextType>;
export declare const useConferenceStatus: () => ConferenceStatusContextType;
export {};
