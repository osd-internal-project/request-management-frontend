/// <reference types="react" />
import { PropsReact } from "../type/props";
type InviterUserContextType = {
    inviterUser: any | null;
    setInviterUser: (value: any | null) => void;
};
export declare const InviterUserProvider: ({ children }: PropsReact) => import("react/jsx-runtime").JSX.Element;
export declare const InviterUserConsumer: import("react").Consumer<InviterUserContextType>;
export declare const useInviterUser: () => InviterUserContextType;
export {};
