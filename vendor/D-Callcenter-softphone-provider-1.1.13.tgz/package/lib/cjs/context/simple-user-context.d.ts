/// <reference types="react" />
import { PropsReact } from "../type/props";
type SimpleUserContextType = {
    simpleUser: any | null;
    setSimpleUser: (value: any | null) => void;
};
export declare const SimpleUserProvider: ({ children }: PropsReact) => import("react/jsx-runtime").JSX.Element;
export declare const SimpleUserConsumer: import("react").Consumer<SimpleUserContextType>;
export declare const useSimpleUser: () => SimpleUserContextType;
export {};
