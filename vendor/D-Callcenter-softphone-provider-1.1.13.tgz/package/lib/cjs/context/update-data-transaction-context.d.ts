import React, { ReactNode } from 'react';
import CallManager from '../lib/call-manager';
import { CallData, ContactsData, IndexedContactData } from '../lib/transaction-data-type';
export interface ExternalDatabaseType {
    callManager: CallManager;
    callData: CallData | null;
    contact: ContactsData | null;
    setOnDelete: (callback: (id?: string) => void) => void;
    setOnFavoriteUpdate: (callback: (data?: IndexedContactData) => void) => void;
}
interface ExternalDatabaseProviderProps {
    children: ReactNode;
}
export declare const ExternalDatabaseProvider: React.FC<ExternalDatabaseProviderProps>;
export declare const ExternalContextConsumer: React.Consumer<ExternalDatabaseType | null>;
declare const useExternalDatabase: () => ExternalDatabaseType | null;
export default useExternalDatabase;
