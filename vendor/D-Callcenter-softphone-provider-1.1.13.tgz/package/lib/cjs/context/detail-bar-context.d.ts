import React from "react";
import PropTypes from "prop-types";
import { PropsReact } from "../type/props";
type DetailBarContextType = {
    isDetailBarVisible: boolean;
    setIsDetailBarVisible: any;
};
export declare const DetailBarProvider: {
    ({ children }: PropsReact): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
    };
};
export declare const DetailBarContextConsumer: React.Consumer<DetailBarContextType>;
export declare const useDetailBar: () => DetailBarContextType;
export {};
