import "./detail-bar.css";
declare const DetailBar: ({ handleCancel, isCardVisible, setTimeStatus, timeStatus, setSecondsRemaining, secondsRemaining, isCardPhoneConference, isCardPhoneConferenceShow, playCall, isCardVisibleCallCreated, setTimeConferenceStatus, timeConferenceStatus, setSecondsConferenceRemaining, secondsConferenceRemaining, isCallConference, setIsCallConference, isCallTransfer, setIsCallTransfer, }: any) => import("react/jsx-runtime").JSX.Element;
export default DetailBar;
