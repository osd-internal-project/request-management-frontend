declare const Contacts: ({ result, isAddContact, setIsAddContact, isEditContact, setIsEditContact, currentContact, setCurrentContact, }: any) => import("react/jsx-runtime").JSX.Element;
export default Contacts;
