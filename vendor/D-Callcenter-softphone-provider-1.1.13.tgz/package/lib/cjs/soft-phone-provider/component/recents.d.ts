declare const Recents: ({ resultContact, result, isEditContact, setIsEditContact, currentContact, setCurrentContact, }: any) => import("react/jsx-runtime").JSX.Element;
export default Recents;
