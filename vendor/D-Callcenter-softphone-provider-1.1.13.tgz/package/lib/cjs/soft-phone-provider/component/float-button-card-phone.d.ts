import React from "react";
interface FloatButtonCardPhoneProps {
    icon?: React.ReactNode;
}
declare const FloatButtonCardPhone: React.FC<FloatButtonCardPhoneProps>;
export default FloatButtonCardPhone;
