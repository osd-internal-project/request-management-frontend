import "./numpad.css";
declare const Numpad: (props: any) => import("react/jsx-runtime").JSX.Element;
export default Numpad;
