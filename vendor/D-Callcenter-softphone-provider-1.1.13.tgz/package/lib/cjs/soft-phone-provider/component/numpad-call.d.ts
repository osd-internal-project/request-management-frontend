declare const NumpadCall: ({ isNumpadCallVisible, isCardVisible, isCardVisibleCallCreated, isCardPhoneConference, isCardPhoneConferenceShow, playCall, numpadValue, setNumpadValue, isCallTransfer, }: any) => any;
export default NumpadCall;
