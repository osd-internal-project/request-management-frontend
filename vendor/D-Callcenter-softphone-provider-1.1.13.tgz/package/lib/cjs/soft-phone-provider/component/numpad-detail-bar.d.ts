declare const NumpadDetailBar: ({ numpadValue, setNumpadValue }: any) => import("react/jsx-runtime").JSX.Element;
export default NumpadDetailBar;
