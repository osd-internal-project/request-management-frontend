import React from "react";
import { CardPhoneTypes } from "../../lib/transaction-data-type";
declare const CardPhone: React.FC<CardPhoneTypes>;
export default CardPhone;
