declare const AddContact: ({ setIsAddContact }: any) => import("react/jsx-runtime").JSX.Element;
export default AddContact;
