import React from "react";
interface CheckLongTextProps {
    text?: string | undefined;
    maxWidth?: number;
    maxLength?: number;
}
declare const CheckLongText: React.FC<CheckLongTextProps>;
export default CheckLongText;
