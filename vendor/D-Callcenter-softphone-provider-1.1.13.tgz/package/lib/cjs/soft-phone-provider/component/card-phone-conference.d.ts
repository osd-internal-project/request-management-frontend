import React from "react";
type TimeConferenceStatusType = string;
type SettimeConferenceStatusType = (timeConferenceStatus: TimeConferenceStatusType) => void;
type SecondsConferenceRemainingType = number;
type SetsecondsConferenceRemainingType = (secondsConferenceRemaining: SecondsConferenceRemainingType) => void;
interface Name {
    id: string;
    name: {
        displayName: string;
        number: string;
        favorite: boolean;
    };
}
interface resultContacts {
    letter: string;
    names: Name[];
}
type CardPhoneConferenceTypes = {
    resultContact: resultContacts[];
    isCardPhoneConference: boolean;
    setTimeConferenceStatus: SettimeConferenceStatusType;
    timeConferenceStatus: TimeConferenceStatusType;
    setSecondsConferenceRemaining: SetsecondsConferenceRemainingType;
    secondsConferenceRemaining: SecondsConferenceRemainingType;
    isCardPhoneConferenceShow: any;
    setIsCallConference: (value: boolean | ((prevState: boolean) => boolean)) => void;
    setIsCallTransfer: (value: boolean | ((prevState: boolean) => boolean)) => void;
    isCallConference: boolean;
    isCallTransfer: boolean;
};
declare const CardPhoneConference: React.FC<CardPhoneConferenceTypes>;
export default CardPhoneConference;
