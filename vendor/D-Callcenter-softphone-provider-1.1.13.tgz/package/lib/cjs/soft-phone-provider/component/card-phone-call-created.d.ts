import React from "react";
type timeStatus = string;
type settimeStatus = (timeStatus: Partial<timeStatus>) => void;
type secondsRemaining = number;
type setSecondsRemaining = (secondsRemaining: Partial<secondsRemaining>) => void;
interface Name {
    id: string;
    name: {
        displayName: string;
        number: string;
        favorite: boolean;
    };
}
interface resultContacts {
    letter: string;
    names: Name[];
}
type CardPhoneCallCreatedProps = {
    resultContact: resultContacts[];
    isCardVisibleCallCreated: boolean;
    setTimeStatus: settimeStatus;
    timeStatus: timeStatus;
    setSecondsRemaining: setSecondsRemaining;
    secondsRemaining: secondsRemaining;
    setIsCallConference: (value: boolean | ((prevState: boolean) => boolean)) => void;
    setIsCallTransfer: (value: boolean | ((prevState: boolean) => boolean)) => void;
    isCallConference: boolean;
    isCallTransfer: boolean;
};
declare const CardPhoneCallCreated: React.FC<CardPhoneCallCreatedProps>;
export default CardPhoneCallCreated;
