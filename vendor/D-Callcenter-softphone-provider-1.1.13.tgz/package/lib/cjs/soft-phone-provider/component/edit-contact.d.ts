declare const EditContact: ({ contact, setIsEditContact }: any) => import("react/jsx-runtime").JSX.Element;
export default EditContact;
