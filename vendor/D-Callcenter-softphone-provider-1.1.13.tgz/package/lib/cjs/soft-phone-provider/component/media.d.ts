export declare function getVideo(id: string): Promise<HTMLElement>;
