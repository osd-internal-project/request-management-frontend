import React from "react";
export type LayoutLandingTypes = {
    children: React.ReactNode;
};
export declare const LayoutLanding: React.FC<LayoutLandingTypes>;
export default LayoutLanding;
