/**
 * `MediaControl` is a wrapper component that displays a settings popover for managing audio input and output.
 * It contains the `SpeakerControl` and `MicrophoneControl` components.
 *
 * @component
 * @returns {JSX.Element} A button with a popover for media settings.
 *
 * @remarks
 * - Uses Ant Design's `Popover` for dropdown display.
 * - Toggles visibility via internal `open` state.
 */
export declare const MediaControl: () => JSX.Element;
/**
 * `MicrophoneControl` allows users to:
 * - Select a microphone device (audio input).
 * - Adjust microphone gain (input volume).
 * - Apply microphone settings to the SIP.js `SimpleUser` media stream.
 *
 * @component
 * @returns {JSX.Element} UI for selecting input device and adjusting gain.
 *
 * @remarks
 * - Requires microphone permissions.
 * - Applies gain using Web Audio API.
 * - Calls `replaceTrack` on the active SIP session.
 */
export declare const MicrophoneControl: () => JSX.Element;
declare global {
    interface HTMLMediaElement {
        /**
         * Sets the audio output device (sink) for the media element.
         *
         * @param sinkId - The ID of the audio output device (e.g., "default" or a specific device ID).
         * @returns A promise that resolves when the sink is successfully set.
         *
         * @remarks
         * - This method is only supported in certain browsers such as **Chrome**, **Edge**, and **Opera**.
         * - It is **not supported** in **Firefox** and **Safari** as of current browser versions.
         * - Always check for the existence of `setSinkId` before calling it to avoid runtime errors.
         *
         * @example
         * ```ts
         * if (typeof audioElement.setSinkId === "function") {
         *   await audioElement.setSinkId("default");
         * }
         * ```
         */
        setSinkId(sinkId: string): Promise<void>;
    }
}
/**
 * `SpeakerControl` allows users to:
 * - Select an audio output device (e.g., speaker).
 * - Adjust output volume for media elements.
 *
 * @component
 * @returns {JSX.Element} UI for selecting output device and adjusting volume.
 *
 * @remarks
 * - Applies selected output device using `setSinkId` on media elements.
 * - Targets elements returned by `getVideo("remote_audio_softphone")` and `getVideo("remote_video_softphone")`.
 */
export declare const SpeakerControl: () => JSX.Element;
/**
 * `MediaMonitor` is a React component that displays a real-time signal strength indicator
 * based on the current Media Quality metrics of an ongoing SIP call.
 *
 * It uses a `CallMonitor` utility to observe metrics such as:
 * - Mean Opinion Score (MOS)
 * - Round Trip Time (RTT)
 * - Jitter
 * - Packet Loss
 *
 * These metrics are visualized with a colored signal bar UI and are also shown in a tooltip.
 *
 * @returns JSX.Element representing a signal strength button with tooltip info.
 */
export declare const MediaMonitor: () => JSX.Element;
