import React from "react";
interface SelectStatusProps {
    styleSettings?: React.CSSProperties;
    initialDisplayField?: string;
}
declare const SelectStatus: React.FC<SelectStatusProps>;
export default SelectStatus;
