declare const Favorite: ({ result, isEditContact, setIsEditContact, currentContact, setCurrentContact }: any) => import("react/jsx-runtime").JSX.Element;
export default Favorite;
