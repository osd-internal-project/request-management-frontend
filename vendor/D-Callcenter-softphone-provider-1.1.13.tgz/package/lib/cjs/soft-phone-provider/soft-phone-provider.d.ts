import React from "react";
type SoftPhoneProviderTypes = {
    children: React.ReactNode;
    setTheme?: any;
};
declare const SoftPhoneProvider: React.FC<SoftPhoneProviderTypes>;
export default SoftPhoneProvider;
