import { UserAgent } from 'sip.js';
export type VideoLayoutType = {
    videoLayout: boolean;
    setVideoLayout: (layout: boolean) => void;
};
type sessionTypes = {
    refer: (target?: {}, options?: {}) => Promise<void>;
    request: any;
    info: (options: {
        requestOptions: {};
    }) => Promise<void>;
    remoteIdentity: {
        displayName: string;
        uri: {
            user: string;
        };
    };
};
export type InviterUserType = {
    inviterUser: {
        hangup: () => Promise<void>;
        mute: () => Promise<void>;
        unmute: () => Promise<void>;
        session: sessionTypes;
        hold: () => Promise<void>;
        unhold: () => Promise<void>;
        isHeld: () => boolean;
    };
};
export type SetInviterUserType = (inviterUser: InviterUserType['inviterUser']) => void;
export type SimpleUserType = {
    simpleUser: {
        unhold: () => Promise<void>;
        hangup: () => Promise<void>;
        decline: () => Promise<void>;
        mute: () => Promise<void>;
        unmute: () => Promise<void>;
        isHeld: () => Promise<void>;
        answer: (arg0: {
            sessionDescriptionHandlerOptions: {
                streams: MediaStream;
                constraints: {
                    audio: boolean;
                    video: boolean;
                };
            };
        }) => Promise<void>;
        userAgent: UserAgent;
        sendInvite: (inviter: {}, inviterOptions: {}, inviterInviteOptions: {}) => Promise<void>;
        hold: () => Promise<void>;
        session: sessionTypes;
    };
};
export type UuidType = {
    recentCallList: {
        transaction: (arg0: string, arg1: string) => Promise<IDBTransaction>;
        objectStore: (arg0: string) => IDBObjectStore;
    };
    setFetch: (arg0: boolean) => void;
    uuid: string;
    setUUID: (arg0: string) => void;
};
export type OnKeyPressType = {
    onKeyPress?: (value: string) => void;
};
export {};
