/// <reference types="react" />
export type PropsReact = {
    children: React.ReactNode;
};
