import { CallData, IndexedContactData } from "./transaction-data-type";
declare class CallManager {
    private recentCallsFetchFunction?;
    private contactFetchFunction?;
    setRecentCallsFetchFunction(fetchFunction: () => Promise<CallData[]>): void;
    setContactFetchFunction(fetchFunction: () => Promise<IndexedContactData[]>): void;
    onCallUpdate?: (data?: CallData) => void;
    onUpdateContact?: (data?: IndexedContactData) => void;
    onDeleteContact?: (id?: string) => void;
    onDeleteRecentCall?: (id?: string) => void;
    onStatusUpdate?: (statusPhone: {
        status: string;
    }) => void;
    constructor(onCallUpdate?: (data?: CallData) => void, onUpdateContact?: (data?: IndexedContactData) => void, onDeleteContact?: (id?: string) => void, onDeleteRecentCall?: (id?: string) => void, onStatusUpdate?: (statusPhone: {
        status: string;
    }) => void);
    onCall(callback: (data?: CallData) => void): void;
    onContactUpdate(callback: (data?: IndexedContactData) => void): void;
    onContactDelete(callback: (id?: string) => void): void;
    onRecentCallDelete(callback: (id?: string) => void): void;
    onSessionStatusUpdate(callback: (SessionStatus: {
        status: string;
    }) => void): void;
    triggerUpdate(data?: CallData): void;
    triggerContactUpdate(data?: IndexedContactData): void;
    triggerDelete(id?: string): void;
    triggerRecentCallDelete(id?: string): void;
    triggerStatusUpdate(statusPhone: {
        status: string;
    }): void;
    fetchExternalData(): Promise<CallData[]>;
    fetchExternalContactData(): Promise<IndexedContactData[]>;
}
export default CallManager;
