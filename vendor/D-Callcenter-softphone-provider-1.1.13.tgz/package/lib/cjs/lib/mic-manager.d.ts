/**
 * Manages microphone stream and audio context resources.
 *
 * @module micManager
 *
 * @remarks
 * This utility centralizes control of microphone-related resources such as `MediaStream` and `AudioContext`.
 * It ensures that previous streams and contexts are properly cleaned up before new ones are applied,
 * helping to prevent memory leaks or orphaned audio processing nodes.
 */
declare const micManager: {
    /**
     * Stops and cleans up the current microphone stream and audio context.
     *
     * @remarks
     * - Stops all audio tracks from the active `MediaStream`.
     * - Closes the `AudioContext` if it's open.
     * - Clears internal references to prevent leaks.
     */
    cleanupMic(): void;
    /**
     * Sets and stores the current microphone stream and audio context.
     *
     * @param stream - The active `MediaStream` obtained from `getUserMedia`.
     * @param context - The `AudioContext` used for gain or audio processing (can be null).
     *
     * @remarks
     * - Invokes `cleanupMic()` before setting new values.
     * - This ensures only one stream/context is held at a time.
     */
    setMicResources(stream: MediaStream, context: AudioContext | null): void;
};
export default micManager;
