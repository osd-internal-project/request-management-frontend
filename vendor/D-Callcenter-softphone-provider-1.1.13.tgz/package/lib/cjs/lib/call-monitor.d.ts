/**
 * Class for monitoring WebRTC call statistics and calculating MOS (Mean Opinion Score).
 */
export declare class CallMonitor {
    private onUpdate?;
    private peerConnection;
    private stopped;
    private updateIntervalId?;
    private logTimeoutId?;
    private lastStats?;
    /**
     * Initializes the CallMonitor with a given RTCPeerConnection.
     * @param pc - The RTCPeerConnection to monitor.
     */
    constructor(pc: RTCPeerConnection, onUpdate?: ((data: {
        mos: number;
        rtt: number;
        jitter: number;
        packetLoss: number;
    }) => void) | undefined);
    /**
     * Starts the monitoring process.
     */
    private startMonitoring;
    /**
     * Stops the ongoing monitoring loop.
     */
    stopMonitoring(): void;
    /**
     * Fetches the WebRTC stats and triggers the onUpdate callback.
     */
    private fetchAndUpdateStats;
    /**
     * Calculates the Mean Opinion Score (MOS) from a given RTCStatsReport.
     * @param stats - The WebRTC statistics report from RTCPeerConnection.
     * @returns Object containing MOS score, RTT, jitter, and packet loss. Returns null if insufficient data.
     */
    private calculateMos;
    /**
     * Computes the MOS score using the E-model formula.
     * @param latency - Effective latency in milliseconds.
     * @param loss - Packet loss ratio (0 to 1).
     * @returns MOS score ranging from 1 to 4.5.
     */
    private computeEModelMos;
    /**
     * Returns the current audio constraints being used.
     * @returns MediaTrackConstraints or undefined.
     */
    private checkAudioConstraints;
}
