import { ExternalDatabaseType } from "../context/update-data-transaction-context";
import { PhoneStatusType } from "../context/phone-status-context";
import { SetStateAction } from "./hook";
export declare const handleAnswer: (simpleUser: any, recentCallList: any, uuid: any, setPhoneStatus: any, setFetch: any, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const handleHangUp: (simpleUser: any, handleCancel: any, handleReset: any, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const handleMute: (simpleUser: any, setPhoneStatus: any) => Promise<void>;
export declare const handleUnMute: (simpleUser: any, setPhoneStatus: any) => Promise<void>;
export declare const handleHold: (simpleUser: any) => Promise<void>;
export declare const handleUnHold: (simpleUser: any) => Promise<void>;
export declare const handleDecline: (simpleUser: any, recentCallList: any, uuid: any, handleCancel: any, setPhoneStatus: any, handleReset: any, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const handleTransfer: (simpleUser: any, setPhoneStatus: any, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const handleCallConference: (simpleUser: any, setPhoneStatus: any, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const handleCheckPermission: () => Promise<boolean>;
export declare const callToAnother: (setPhoneStatus: (newState: SetStateAction<PhoneStatusType>) => void, setVideoLayout: (videoLayout: boolean) => void, numpadValue: string, Auth: any, recentCallList: any, setFetch: (fetch: boolean) => void, uuid: string, setUUID: (uuid: string) => void, callData: ExternalDatabaseType | null, simpleUser: any, setNumpadValue?: ((numpadValue: string) => void) | undefined) => Promise<void>;
export declare const callToAnotherVideo: (setPhoneStatus: (newState: SetStateAction<PhoneStatusType>) => void, setVideoLayout: (videoLayout: boolean) => void, numpadValue: string, Auth: any, recentCallList: any, setFetch: (fetch: boolean) => void, uuid: string, setUUID: (uuid: string) => void, callData: ExternalDatabaseType | null, simpleUser: any, setNumpadValue?: ((numpadValue: string) => void) | undefined) => Promise<void>;
export declare const inviterOptions: {
    alwaysAcquireMediaFirst: boolean;
    earlyMedia: boolean;
    sessionDescriptionHandlerOptions: {
        streams: MediaStream;
        constraints: {
            audio: boolean;
            video: boolean;
        };
    };
    sessionDescriptionHandlerModifiers: ((sd: RTCSessionDescriptionInit) => Promise<RTCSessionDescriptionInit>)[];
};
