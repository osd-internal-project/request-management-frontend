import { ExternalDatabaseType } from "../context/update-data-transaction-context";
import { CallStatus, ContactsData } from "./transaction-data-type";
export declare const CallTransaction: (displayName: string, uuid: string, status: CallStatus, recentCallList: IDBDatabase, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const DeleteFromStore: (id: string, storeName: string, db: IDBDatabase, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const UpdateFavoriteStatus: (id: string, favorite: boolean, db: IDBDatabase, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const checkDuplicateContact: (db: IDBDatabase, number: string) => Promise<boolean>;
export declare const AddContactToStore: (db: IDBDatabase, contactData: ContactsData, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const UpdateContact: (contactId: string, contactData: ContactsData, recentCallList: IDBDatabase, callData?: ExternalDatabaseType | null) => Promise<void>;
export declare const hangupWhenError: (error: any, displayName: any, uuid: string, status: CallStatus, recentCallList: IDBDatabase, callData: ExternalDatabaseType | null, setUUID: (uuid: string) => void, setFetch: (fetch: boolean) => void) => Promise<void>;
