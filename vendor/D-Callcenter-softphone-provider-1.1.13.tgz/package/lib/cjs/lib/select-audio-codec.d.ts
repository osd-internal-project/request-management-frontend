/**
 * ฟังก์ชันสำหรับปรับแต่ง SDP ให้ใช้โคเดกเสียงที่ต้องการพร้อมค่า ptime ที่เหมาะสม
 * @param sdp ข้อความ SDP ต้นฉบับ
 * @param codecType ประเภทของโคเดกที่ต้องการใช้ (เช่น "PCMA", "PCMU", "opus", "G722")
 * @param customPtime ค่า packet time ที่กำหนดเอง (ถ้าไม่ระบุจะใช้ค่าแนะนำของแต่ละโคเดก)
 * @returns ข้อความ SDP ที่ถูกปรับแต่งแล้ว
 */
export declare const selectAudioCodec: (sdp: string, codecType: string, customPtime?: number) => string;
