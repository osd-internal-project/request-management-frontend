export declare const showNotification: (type: "success" | "info" | "warning" | "error", message: string, description?: string) => void;
