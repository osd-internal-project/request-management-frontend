/**
 * Custom hook that handles the process of receiving a call in a SIP.js application.
 * It manages the phone status, video layout, and database transactions related to the call.
 *
 * @returns {{ callToReceive: (displayName: string) => Promise<void> }}
 * - `callToReceive`: A function to initiate a call to a specified user.
 */
export declare const useCallToReceive: () => {
    callToReceive: (displayName: string) => Promise<void>;
};
export default useCallToReceive;
