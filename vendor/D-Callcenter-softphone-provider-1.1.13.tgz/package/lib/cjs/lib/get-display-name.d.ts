export declare const GetDisplayName: (resultContact: any[], remoteUser: string | undefined) => string | undefined;
