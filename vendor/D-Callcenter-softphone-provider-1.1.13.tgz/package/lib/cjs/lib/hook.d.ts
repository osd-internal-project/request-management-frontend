import { useLayoutEffect } from "react";
export declare const useIsomorphicLayoutEffect: typeof useLayoutEffect;
export declare const useInterval: (callback: () => void, delay?: number | null) => void;
export type SetStateAction<S> = S | Partial<S> | ((prevState: S) => S | Partial<S>);
type InitStateObject<S> = {
    [K in keyof S]: S[K] | (() => S[K]);
};
export declare const useMultiState: <S extends object>(initState: InitStateObject<S>) => [S, (newState: SetStateAction<S>) => void];
export declare const usePrevious: (value: any) => undefined;
export declare const useScroll: () => {
    scrollY: number;
    scrollX: number;
    scrollDirection: "down" | "up" | undefined;
};
export declare const SetupUserSimple1: (Auth: any, setSimpleUser: any) => Promise<void>;
export declare const SetupUserAgent1: (Auth: any, setInviterUser: any) => Promise<void>;
export {};
