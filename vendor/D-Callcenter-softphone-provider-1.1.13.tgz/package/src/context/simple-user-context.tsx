import { createContext, useState, useContext } from "react";
import { PropsReact } from "../type/props";

type SimpleUserContextType = {
  simpleUser: any | null;
  setSimpleUser: (value: any | null) => void;
};
const SimpleUserContext = createContext<SimpleUserContextType>({
  simpleUser: null,
  setSimpleUser: () => {},
});

export const SimpleUserProvider = ({ children }: PropsReact) => {
  const [simpleUser, setSimpleUser] = useState<any | null>(null);
  // const beep = useMemo(
  //   () => new UIFx('/asset/simpleUsers/alarmsimpleUser3.mp3', {
  //     volume: 0.9,
  //     throttleMs: 50,
  //   }),
  //   [],
  // )

  // useEffect(() => {
  //     try {
  //         const localSimpleUser = JSON.parse(localStorage.getItem('simpleUser'))
  //         setSimpleUser(localSimpleUser)
  //     } catch (err) {
  //         console.error(err)
  //     }
  // }, [setSimpleUser])
  // const openSimpleUser = (e) => {
  //     if (e) {
  //         localStorage.setItem('simpleUser', JSON.stringify(e))
  //     } else {
  //         localStorage.removeItem('simpleUser')
  //     }
  //     setSimpleUser(e)
  // }
  return (
    <SimpleUserContext.Provider value={{ simpleUser, setSimpleUser }}>
      {children}
    </SimpleUserContext.Provider>
  );
};

export const SimpleUserConsumer = SimpleUserContext.Consumer;

export const useSimpleUser = () => useContext(SimpleUserContext);
