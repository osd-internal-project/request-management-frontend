import React, { createContext, useContext, useState } from 'react';

interface ThemeColorContextProps {
  buttonColor: string;
  backgroundColor: string;
  textColor: string;
  setThemeColor: (theme: Partial<ThemeColorContextProps>) => void;
}

const ThemeColorContext = createContext<ThemeColorContextProps>({
  buttonColor: '#1890ff',
  backgroundColor: '#ffffff',
  textColor: '#000000',
  setThemeColor: () => {},
});

export const ThemeColorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeColor, setThemeColor] = useState({
    buttonColor: '#1890ff',
    backgroundColor: '#ffffff',
    textColor: '#000000',
  });

  const updateTheme = (newTheme: Partial<ThemeColorContextProps>) => {
    setThemeColor((prevTheme) => ({ ...prevTheme, ...newTheme }));
  };

  return (
    <ThemeColorContext.Provider value={{ ...themeColor, setThemeColor: updateTheme }}>
      {children}
    </ThemeColorContext.Provider>
  );
};

export const useThemeColor = () => useContext(ThemeColorContext);
