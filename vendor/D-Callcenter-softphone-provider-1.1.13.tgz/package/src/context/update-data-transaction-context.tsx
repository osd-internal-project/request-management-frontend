import React, { createContext, useState, ReactNode } from 'react';
import CallManager from '../lib/call-manager';
import { CallData, ContactsData, IndexedContactData } from '../lib/transaction-data-type';

export interface ExternalDatabaseType {
  callManager: CallManager;
  callData: CallData | null;
  contact: ContactsData | null;
  setOnDelete: (callback: (id?: string) => void) => void;
  setOnFavoriteUpdate: (callback: (data?: IndexedContactData) => void) => void;
}

const ExternalDatabase = createContext<ExternalDatabaseType | null>(null);

interface ExternalDatabaseProviderProps {
  children: ReactNode;
}

export const ExternalDatabaseProvider: React.FC<ExternalDatabaseProviderProps> = ({ children }) => {
  const [callData, setCallData] = useState<CallData | null>(null);
  const [contact, setContact] = useState<ContactsData | null>(null);
  const [deletedIds, setDeletedIds] = useState<string | null>(null);

  const callManager = new CallManager(
    (data?: CallData) => {
      setCallData(data ?? null);
    },
    undefined,
    (id?: string) => {
      setDeletedIds(id ?? null);
    }
  );

  const setOnDelete = (callback: (id?: string) => void) => {
    callManager.onContactDelete(callback);
  };

  const setOnFavoriteUpdate = (callback: (data?: IndexedContactData) => void) => {
    callManager.onContactUpdate(callback);
  };

  return (
    <ExternalDatabase.Provider value={{ callData, callManager, contact, setOnDelete, setOnFavoriteUpdate }}>
      {children}
    </ExternalDatabase.Provider>
  );
};


export const ExternalContextConsumer = ExternalDatabase.Consumer;

 const useExternalDatabase = () => React.useContext(ExternalDatabase);

export default useExternalDatabase;