import React from "react";
import PropTypes from "prop-types";
import { PropsReact } from "../type/props";
type DetailBarContextType = {
  isDetailBarVisible: boolean;
  setIsDetailBarVisible: any;
};
const DetailBarContext = React.createContext<DetailBarContextType>({
  isDetailBarVisible: false,
  setIsDetailBarVisible: () => {},
});

export const DetailBarProvider = ({ children }: PropsReact) => {
  const [isDetailBarVisible, setIsDetailBarVisible] = React.useState(false);

  return (
    <DetailBarContext.Provider value={{ isDetailBarVisible, setIsDetailBarVisible }}>
      {children}
    </DetailBarContext.Provider>
  );
};
DetailBarProvider.propTypes = {
  children: PropTypes.node,
};

export const DetailBarContextConsumer = DetailBarContext.Consumer;
export const useDetailBar = () => React.useContext(DetailBarContext);
