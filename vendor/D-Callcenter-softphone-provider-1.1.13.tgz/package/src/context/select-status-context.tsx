import React from "react";
import {
  UserOutlined,
  CoffeeOutlined,
  TeamOutlined,
  ClockCircleOutlined,
  CalendarOutlined,
  UserDeleteOutlined,
} from "@ant-design/icons";

export type ListType = { [key: string]: any };
export type SelectionHandler = (selectedItem: ListType) => void;

interface SelectStatusContextProps {
  statusList: ListType[];
  setStatusList: (list: (ListType | string)[]) => void;
  selectedStatus: ListType | undefined;
  setSelectedStatus: (status: ListType) => void;
  onSelect: SelectionHandler;
  setOnSelect: (handler: SelectionHandler) => void;
  displayField: string;
  setDisplayField: (field: string) => void;
  placeholder: string;
  setPlaceholder: (customPlaceholder: string) => void;
}

const SelectStatusContext = React.createContext<SelectStatusContextProps>({
  statusList: [],
  setStatusList: () => {},
  selectedStatus: undefined,
  setSelectedStatus: () => {},
  onSelect: () => {},
  setOnSelect: () => {},
  displayField: "",
  setDisplayField: () => {},
  placeholder: "",
  setPlaceholder: () => {},
});

const defaultIcon = <UserOutlined />;
const defaultList: ListType[] = [
  { id: 1, name: "Ready", icon: <UserOutlined style={{ color: "green" }} /> },
  { id: 2, name: "Lunch", icon: <CoffeeOutlined style={{ color: "orange" }} /> },
  { id: 3, name: "Toilet", icon: <TeamOutlined style={{ color: "blue" }} /> },
  { id: 4, name: "Break", icon: <ClockCircleOutlined style={{ color: "red" }} /> },
  { id: 5, name: "Meeting", icon: <CalendarOutlined style={{ color: "purple" }} /> },
  { id: 6, name: "Not Ready", icon: <UserDeleteOutlined style={{ color: "gray" }} /> },
];

export const SelectStatusProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [statusList, setStatusList] = React.useState<ListType[]>(defaultList);
  const [selectedStatus, setSelectedStatus] = React.useState<ListType | undefined>(undefined);
  const [displayField, setDisplayField] = React.useState<string>("name");
  const [placeholder, setPlaceholder] = React.useState<string>("Select Status");
  const [onSelect, setOnSelect] = React.useState<SelectionHandler>(() => () => {});

  const ensureNameField = (items: (ListType | string)[]): ListType[] => {
    return items.map((item, index) => {
      if (typeof item === "string") {
        return { [displayField]: item, icon: defaultIcon };
      } else {
        const displayValue = item[displayField];
        return {
          ...item,
          [displayField]: typeof displayValue === "string" ? displayValue : `Unnamed Item ${index + 1}`,
          icon: item.icon || defaultIcon,
        };
      }
    });
  };
  

  const setListWithValidation = React.useCallback((items: (ListType | string)[]) => {
    setStatusList(ensureNameField(items).filter((item) => {
      const displayValue = item[displayField];
      return typeof displayValue === "string" && displayValue.trim() !== "";
    }));
  }, [displayField]);


  const contextValue = React.useMemo(() => ({
    statusList,
    setStatusList: setListWithValidation,
    selectedStatus,
    setSelectedStatus,
    onSelect,
    setOnSelect,
    displayField,
    setDisplayField,
    placeholder,
    setPlaceholder,
  }), [statusList, selectedStatus, onSelect, displayField, placeholder]);
  
  return (
    <SelectStatusContext.Provider
      value={contextValue}
    >
      {children}
    </SelectStatusContext.Provider>
  );
};



export const SelectStatusContextConsumer = SelectStatusContext.Consumer;

 const useSelectStatusContext = () => React.useContext(SelectStatusContext);

export default useSelectStatusContext;