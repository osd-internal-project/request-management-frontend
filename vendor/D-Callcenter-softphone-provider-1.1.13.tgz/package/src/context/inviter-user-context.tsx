import { createContext, useState, useContext } from "react";
import { PropsReact } from "../type/props";

type InviterUserContextType = {
  inviterUser: any | null;
  setInviterUser: (value: any | null) => void;
};
const InviterUserContext = createContext<InviterUserContextType>({
  inviterUser: null,
  setInviterUser: () => {},
});

export const InviterUserProvider = ({ children }: PropsReact) => {
  const [inviterUser, setInviterUser] = useState<any | null>(null);
  // const beep = useMemo(
  //   () => new UIFx('/asset/inviterUsers/alarminviterUser3.mp3', {
  //     volume: 0.9,
  //     throttleMs: 50,
  //   }),
  //   [],
  // )

  // useEffect(() => {
  //     try {
  //         const localInviterUser = JSON.parse(localStorage.getItem('inviterUser'))
  //         setInviterUser(localInviterUser)
  //     } catch (err) {
  //         console.error(err)
  //     }
  // }, [setInviterUser])
  // const openInviterUser = (e) => {
  //     if (e) {
  //         localStorage.setItem('inviterUser', JSON.stringify(e))
  //     } else {
  //         localStorage.removeItem('inviterUser')
  //     }
  //     setInviterUser(e)
  // }
  return (
    <InviterUserContext.Provider value={{ inviterUser, setInviterUser }}>
      {children}
    </InviterUserContext.Provider>
  );
};

export const InviterUserConsumer = InviterUserContext.Consumer;

export const useInviterUser = () => useContext(InviterUserContext);
