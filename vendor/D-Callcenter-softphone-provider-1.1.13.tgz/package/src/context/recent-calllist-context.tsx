import { createContext, useState, useContext } from "react";
import { v4 as uuidv4 } from "uuid";
import { PropsReact } from "../type/props";

type RecentCallListContextType = {
  recentCallList: any;
  setRecentCallList: (recentCallList: any) => void;
  fetch: boolean;
  setFetch: (fetch: boolean) => void;
  uuid: string;
  setUUID: (uuid: string) => void;
};
const RecentCallListContext = createContext<RecentCallListContextType>({
  recentCallList: null,
  setRecentCallList: () => {},
  fetch: true,
  setFetch: () => {},
  uuid: "",
  setUUID: () => {},
});

export const RecentCallListProvider = ({ children }: PropsReact) => {
  const [recentCallList, setRecentCallList] = useState(null);
  const [fetch, setFetch] = useState(true);
  const [uuid, setUUID] = useState(uuidv4());
  // const beep = useMemo(
  //   () => new UIFx('/asset/recentCallLists/alarmrecentCallList3.mp3', {
  //     volume: 0.9,
  //     throttleMs: 50,
  //   }),
  //   [],
  // )

  // useEffect(() => {
  //     try {
  //         const localRecentCallList = JSON.parse(localStorage.getItem('recentCallList'))
  //         setRecentCallList(localRecentCallList)
  //     } catch (err) {
  //         console.error(err)
  //     }
  // }, [setRecentCallList])
  // const openRecentCallList = (e) => {
  //     if (e) {
  //         localStorage.setItem('recentCallList', JSON.stringify(e))
  //     } else {
  //         localStorage.removeItem('recentCallList')
  //     }
  //     setRecentCallList(e)
  // }
  return (
    <RecentCallListContext.Provider
      value={{
        recentCallList,
        setRecentCallList,
        fetch,
        setFetch,
        uuid,
        setUUID,
      }}
    >
      {children}
    </RecentCallListContext.Provider>
  );
};

export const RecentCallListConsumer = RecentCallListContext.Consumer;

export const useRecentCallList = () => useContext(RecentCallListContext);
