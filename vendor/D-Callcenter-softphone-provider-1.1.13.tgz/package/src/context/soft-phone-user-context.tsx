import { createContext, useContext } from "react";
import { SetStateAction, useMultiState } from "../lib/hook";
import { PropsReact } from "../type/props";
import { MenuOutlined, UserDeleteOutlined } from "@ant-design/icons";
import Delegate from "../lib/call-manager";  // import your Delegate class

/**
 * @param socketServer Web Socket Server eg. wss://<host>/ws.
 * @param username Username Voip Server.
 * @param password Password Voip Server.
 * @param ipServer Username Voip Server eg. <host>.
 * @param displayName Display name .
 * @param organizeName Organize name .
 * @param iconOnline Icon online .
 * @param iconOffline Icon offline .
 * @param isUserFavoriteVisible Control visibility of the favorite button.
 * @param isUserRecentVisible Control visibility of the recent button.
 * @param isUserContactVisible Control visibility of the contact button.
 * @param isUserNumpadVisible Control visibility of the numpad button.
 * @param notificationVisible Control visibility of notifications.
 * - @param isBusy Indicates if the user is currently busy.
 * @param ringtoneCallUrl URL for the ringtone during an outgoing call.
 * @param ringtoneReceiveUrl URL for the ringtone during an incoming call.
 * @param externalRecentCallListDatabase use external Recent Call List or not.
 * @param externalContactCallListDatabase use external Contact Call ist or not.
 * @param limitDigit Limit digit for the phone number.  Default is 10.
 * @param duration Duration for DTMF signal transmission in milliseconds. Default is 2000.
 */

type SoftPhoneUserType = {
  socketServer: string;
  username: string;
  password: string;
  ipServer: string;
  displayName: string;
  organizeName: string;
  iconOnline?: React.ReactNode;
  iconOffline?: React.ReactNode;
  isUserFavoriteVisible: boolean;
  isUserRecentVisible: boolean;
  isUserContactVisible: boolean;
  isUserNumpadVisible: boolean;
  notificationVisible?: {
    isBusy?: boolean
  }
  ringtoneCallUrl: string;
  ringtoneReceiveUrl: string;
  externalRecentCallListDatabase?: boolean;
  externalContactCallListDatabase?: boolean;
  limitDigit?: number;
  duration?: number
};

type SoftPhoneUserContextType = {
  user: SoftPhoneUserType;
  /**
   * @param socketServer Web Socket Server eg. wss://<host>/ws.
   * @param username Username Voip Server.
   * @param password Password Voip Server.
   * @param ipServer Username Voip Server eg. <host>.
   * @param displayName Display name .
   * @param organizeName Organize name .
   * @param iconOnline Icon online .
   * @param iconOffline Icon offline .
   * @param isUserFavoriteVisible Control visibility of the favorite button.
   * @param isUserRecentVisible Control visibility of the recent button.
   * @param isUserContactVisible Control visibility of the contact button.
   * @param isUserNumpadVisible Control visibility of the numpad button.
   * @param notificationVisible Control visibility of notifications.
   * - @param isBusy Indicates if the user is currently busy.
   * @param ringtoneCallUrl URL for the ringtone during an outgoing call.
   * @param ringtoneReceiveUrl URL for the ringtone during an incoming call.
   * @param externalRecentCallListDatabase use external Recent Call List or not.
   * @param externalContactCallListDatabase use external Contact Call ist or not.
   * @param limitDigit Limit digit for the phone number.  Default is 10.
   * @param duration Duration for DTMF signal transmission in milliseconds. Default is 2000.
   */
  set: (newState: SetStateAction<SoftPhoneUserType>) => void;
  delegate: Delegate;
};

const SoftPhoneUserContext = createContext<SoftPhoneUserContextType | null>(null);

export const SoftPhoneUserProvider = ({ children }: PropsReact) => {
  const [user, set] = useMultiState<SoftPhoneUserType>({
    socketServer: "",
    username: "",
    password: "",
    ipServer: "",
    displayName: "",
    organizeName: "",
    iconOnline: <MenuOutlined />,
    iconOffline: <UserDeleteOutlined />,
    isUserFavoriteVisible: true,
    isUserRecentVisible: true,
    isUserContactVisible: true,
    isUserNumpadVisible: true,
    ringtoneCallUrl: "",
    ringtoneReceiveUrl: "",
    externalRecentCallListDatabase: false,
    externalContactCallListDatabase: false,
    limitDigit: 10,
    duration: 2000
  });

  const delegate = new Delegate();

  return (
    <SoftPhoneUserContext.Provider value={{ user, set, delegate }}>
      {children}
    </SoftPhoneUserContext.Provider>
  );
};

export const SoftPhoneUserConsumer = SoftPhoneUserContext.Consumer;

const useSoftPhoneUser = () => useContext(SoftPhoneUserContext);
export default useSoftPhoneUser;
