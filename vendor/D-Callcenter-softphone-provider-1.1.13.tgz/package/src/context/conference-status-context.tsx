import { createContext, useContext } from "react";
import { SetStateAction, useMultiState } from "../lib/hook";
import { PropsReact } from "../type/props";

type ConferenceStatusType = {
  created: boolean;
  answer: boolean;
  mute: boolean;
  hold: boolean;
  conference: boolean;
};
type ConferenceStatusContextType = {
  conferenceStatus: ConferenceStatusType;
  setConferenceStatus: (newState: SetStateAction<ConferenceStatusType>) => void;
};
const ConferenceStatusContext = createContext<ConferenceStatusContextType>({
  conferenceStatus: {
    created: false,
    answer: false,
    mute: false,
    hold: false,
    conference: false,
  },
  setConferenceStatus: () => {},
});

export const ConferenceStatusProvider = ({ children }: PropsReact) => {
  const [conferenceStatus, setConferenceStatus] =
    useMultiState<ConferenceStatusType>({
      created: false,
      answer: false,
      mute: false,
      hold: false,
      conference: false,
    });
  // const beep = useMemo(
  //   () => new UIFx('/asset/phoneStatuss/alarmphoneStatus3.mp3', {
  //     volume: 0.9,
  //     throttleMs: 50,
  //   }),
  //   [],
  // )

  // useEffect(() => {
  //     try {
  //         const localPhoneStatus = JSON.parse(localStorage.getItem('phoneStatus'))
  //         setPhoneStatus(localPhoneStatus)
  //     } catch (err) {
  //         console.error(err)
  //     }
  // }, [setPhoneStatus])
  // const openPhoneStatus = (e) => {
  //     if (e) {
  //         localStorage.setItem('phoneStatus', JSON.stringify(e))
  //     } else {
  //         localStorage.removeItem('phoneStatus')
  //     }
  //     setPhoneStatus(e)
  // }
  return (
    <ConferenceStatusContext.Provider
      value={{ conferenceStatus, setConferenceStatus }}
    >
      {children}
    </ConferenceStatusContext.Provider>
  );
};

export const ConferenceStatusConsumer = ConferenceStatusContext.Consumer;

export const useConferenceStatus = () => useContext(ConferenceStatusContext);
