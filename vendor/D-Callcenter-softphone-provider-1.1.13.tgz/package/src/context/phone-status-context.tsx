import { createContext, useContext } from "react";
import { SetStateAction, useMultiState } from "../lib/hook";
import { PropsReact } from "../type/props";

export type PhoneStatusType = {
  created: boolean;
  answer: boolean;
  mute: boolean;
  hold: boolean;
  conference: boolean;
};
type PhoneStatusContextType = {
  phoneStatus: PhoneStatusType;
  setPhoneStatus: (newState: SetStateAction<PhoneStatusType>) => void;
};

const PhoneStatusContext = createContext<PhoneStatusContextType>({
  phoneStatus: {
    created: false,
    answer: false,
    mute: false,
    hold: false,
    conference: false,
  },
  setPhoneStatus: () => {},
});

export const PhoneStatusProvider = ({ children }: PropsReact) => {
  const [phoneStatus, setPhoneStatus] = useMultiState({
    created: false,
    answer: false,
    mute: false,
    hold: false,
    conference: false,
  });
  // const beep = useMemo(
  //   () => new UIFx('/asset/phoneStatuss/alarmphoneStatus3.mp3', {
  //     volume: 0.9,
  //     throttleMs: 50,
  //   }),
  //   [],
  // )

  // useEffect(() => {
  //     try {
  //         const localPhoneStatus = JSON.parse(localStorage.getItem('phoneStatus'))
  //         setPhoneStatus(localPhoneStatus)
  //     } catch (err) {
  //         console.error(err)
  //     }
  // }, [setPhoneStatus])
  // const openPhoneStatus = (e) => {
  //     if (e) {
  //         localStorage.setItem('phoneStatus', JSON.stringify(e))
  //     } else {
  //         localStorage.removeItem('phoneStatus')
  //     }
  //     setPhoneStatus(e)
  // }
  return (
    <PhoneStatusContext.Provider value={{ phoneStatus, setPhoneStatus }}>
      {children}
    </PhoneStatusContext.Provider>
  );
};

export const PhoneStatusConsumer = PhoneStatusContext.Consumer;

export const usePhoneStatus = () => useContext(PhoneStatusContext);
