import React from "react";
import Draggable from "react-draggable";

import { Card, Avatar, Typography, Button, Space, Tooltip, theme, Row, Col, Divider } from "antd";
import { DownOutlined, MinusOutlined, PhoneFilled, UpOutlined, UserAddOutlined } from "@ant-design/icons";

import { useRecentCallList } from "../../context/recent-calllist-context";
import useSoftPhoneUser from "../../context/soft-phone-user-context";
import { useContainerLayout } from "../../context/video-context";
import { useDetailBar } from "../../context/detail-bar-context";

import Favorite from "./favorite";
import Recents from "./recents";
import Contacts from "./contact";
import NumpadCall from "./numpad-call";

import CardPhone from "./card-phone";
import CardPhoneCallCreated from "./card-phone-call-created";
import CardPhoneConference from "./card-phone-conference";
import { PhoneIncoming, PhoneOutgoing } from "react-feather";
import FloatButtonCardPhone from "./float-button-card-phone";

import "./detail-bar.css";
import SelectStatus from "./select-status-dropdown";
// import useSelectStatusContext from "../../context/select-status-context";
import NumpadDetailBar from "./numpad-detail-bar";
import { useSimpleUser } from "../../context/simple-user-context";
import { MediaControl } from "./media-control";

const DetailBar = ({
  handleCancel,
  isCardVisible,
  setTimeStatus,
  timeStatus,
  setSecondsRemaining,
  secondsRemaining,
  isCardPhoneConference,
  isCardPhoneConferenceShow,
  playCall,
  isCardVisibleCallCreated,
  setTimeConferenceStatus,
  timeConferenceStatus,
  setSecondsConferenceRemaining,
  secondsConferenceRemaining,
  isCallConference,
  setIsCallConference,
  isCallTransfer,
  setIsCallTransfer,
}: any) => {
  const { Title, Text } = Typography;

  type TrapezoidButtonProps = {
    onClick: () => void;
  };

  const nodeRef = React.useRef(null);
  const secondNodeRef = React.useRef(null);

  const [recents, setRecents] = React.useState(null);
  const [contacts, setContacts] = React.useState<any>(null);
  const [isFavoriteVisible, setIsFavoriteVisible] = React.useState(false);
  const [isRecentVisible, setIsRecentVisible] = React.useState(false);
  const [isContactVisible, setIsContactVisible] = React.useState(false);
  const [isNumpadCallVisible, setIsNumpadCallVisible] = React.useState(false);
  const [selectedButton, setSelectedButton] = React.useState<string | null>(null);
  const [, setInternetStatus] = React.useState<boolean>(navigator.onLine);
  const [isAddContact, setIsAddContact] = React.useState(false);
  const [isEditContact, setIsEditContact] = React.useState(false);
  const [currentContact, setCurrentContact] = React.useState(null);
  const [numpadValue, setNumpadValue] = React.useState("");
  // const { setSelectedStatus, statusList } = useSelectStatusContext();
  const { simpleUser } = useSimpleUser();

  const Auth = useSoftPhoneUser();
  const { recentCallList, fetch, setFetch } = useRecentCallList();
  const { videoLayout } = useContainerLayout();
  const { isDetailBarVisible, setIsDetailBarVisible } = useDetailBar();

  const { token } = theme.useToken(); // Extract theme token

  const displayName = Auth?.user?.displayName || "";

  React.useEffect(() => {
    if ((recents === null && recentCallList !== null) || fetch) {
      try {
        if (recentCallList) {
          const tx = recentCallList.transaction("RecentLists", "readwrite");
          const store = tx.objectStore("RecentLists");
          const getAll = store.getAll();
          const txContacts = recentCallList.transaction("ContactLists", "readwrite");
          const storeContacts = txContacts.objectStore("ContactLists");
          const getAllContacts = storeContacts.getAll();
          getAll.onsuccess = () => {
            const sortedRecents = getAll.result?.sort(
              (rowa: { name: { date: any } }, rowb: { name: { date: any } }) => {
                const a = new Date(`${rowa?.name?.date}`);
                const b = new Date(`${rowb?.name?.date}`);
                return b?.getTime() - a?.getTime();
              }
            );
            setRecents(sortedRecents);
          };
          getAllContacts.onsuccess = () => {
            const contactsObj = getAllContacts.result?.reduce((acc: any, c: any) => {
              const letter = `${c.name.displayName[0]}`.toLowerCase();
              acc[letter] = (acc[letter] || []).concat(c);
              return acc;
            }, {});
            const sortedContacts = Object.entries(contactsObj)
              .map(([letter, names]) => {
                return { letter, names };
              })
              .sort((a, b) => a.letter?.charCodeAt(0) - b.letter?.charCodeAt(0));
            setContacts(sortedContacts);
          };
        }
      } catch (e) {
        console.error("Error", e);
      } finally {
        setFetch(false);
      }
    }
  }, [recents, recentCallList, fetch, setFetch, contacts]);

  React.useEffect(() => {
    window.addEventListener("offline", handleOffline);
    window.addEventListener("online", handleOnline);
    return () => {
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("online", handleOnline);
    };
  });

  const handleOnline = () => {
    setInternetStatus(true);
  };

  const handleOffline = () => {
    setInternetStatus(false);
  };

  const tabList = [
    { key: "tab0", tab: "Favorite" },
    { key: "tab1", tab: "Recents" },
    { key: "tab2", tab: "Contacts" },
    { key: "tab3", tab: "Numpad" },
  ];

  const contentList = React.useMemo(
    () => ({
      tab0: (
        <Favorite
          key="contentList0"
          result={contacts}
          isEditContact={isEditContact}
          setIsEditContact={setIsEditContact}
          currentContact={currentContact}
          setCurrentContact={setCurrentContact}
        />
      ),
      tab1: (
        <Recents
          key="contentList1"
          result={recents}
          resultContact={contacts}
          isEditContact={isEditContact}
          setIsEditContact={setIsEditContact}
          currentContact={currentContact}
          setCurrentContact={setCurrentContact}
          numpadValue={numpadValue}
          setNumpadValue={setNumpadValue}
        />
      ),
      tab2: (
        <Contacts
          key="contentList2"
          result={contacts}
          isAddContact={isAddContact}
          setIsAddContact={setIsAddContact}
          isEditContact={isEditContact}
          setIsEditContact={setIsEditContact}
          currentContact={currentContact}
          setCurrentContact={setCurrentContact}
        />
      ),
      tab3: (
        <NumpadCall
          key="contentList3"
          isNumpadCallVisible={isNumpadCallVisible}
          isCardVisible={isCardVisible}
          isCardVisibleCallCreated={isCardVisibleCallCreated}
          isCardPhoneConference={isCardPhoneConference}
          isCardPhoneConferenceShow={isCardPhoneConferenceShow}
          playCall={playCall}
          numpadValue={numpadValue}
          setNumpadValue={setNumpadValue}
          isCallTransfer={isCallTransfer}
        />
      ),
      tab4: <NumpadDetailBar key="contentList3" numpadValue={numpadValue} setNumpadValue={setNumpadValue} />,
    }),
    [
      contacts,
      isEditContact,
      currentContact,
      recents,
      numpadValue,
      isAddContact,
      isNumpadCallVisible,
      isCardVisible,
      isCardVisibleCallCreated,
      isCardPhoneConference,
      isCardPhoneConferenceShow,
      playCall,
      isCallTransfer,
    ]
  );

  const cardPhoneTabList = [
    {
      key: "tab0",
      tab: [
        <PhoneIncoming key="phone-in" size={20} style={{ color: "green" }} />,
        <Typography.Text key="phone-in-text" style={{ fontSize: "7px", color: "green" }}>
          In
        </Typography.Text>,
      ],
    },
    {
      key: "tab1",
      tab: [
        <PhoneOutgoing key="phone-out" size={20} style={{ color: "green" }} />,
        <Typography.Text key="phone-out-text" style={{ fontSize: "7px", color: "green" }}>
          Out
        </Typography.Text>,
      ],
    },
  ];

  const cardPhoneContentList: any = React.useMemo(
    () => ({
      tab0: (
        <CardPhone
          key="cardPhoneContentList0"
          resultContact={contacts}
          handleCancel={handleCancel}
          isCardVisible={isCardVisible}
          setTimeStatus={setTimeStatus}
          timeStatus={timeStatus}
          setSecondsRemaining={setSecondsRemaining}
          secondsRemaining={secondsRemaining}
          setIsCallConference={setIsCallConference}
          isCallConference={isCallConference}
          setIsCallTransfer={setIsCallTransfer}
          isCallTransfer={isCallTransfer}
        />
      ),
      tab1: (
        <CardPhoneCallCreated
          key="cardPhoneContentList1"
          resultContact={contacts}
          isCardVisibleCallCreated={isCardVisibleCallCreated}
          setTimeStatus={setTimeStatus}
          timeStatus={timeStatus}
          setSecondsRemaining={setSecondsRemaining}
          secondsRemaining={secondsRemaining}
          setIsCallConference={setIsCallConference}
          isCallConference={isCallConference}
          setIsCallTransfer={setIsCallTransfer}
          isCallTransfer={isCallTransfer}
        />
      ),
      tab2: (
        <CardPhoneConference
          key="cardPhoneContentList2"
          resultContact={contacts}
          setTimeConferenceStatus={setTimeConferenceStatus}
          timeConferenceStatus={timeConferenceStatus}
          setSecondsConferenceRemaining={setSecondsConferenceRemaining}
          secondsConferenceRemaining={secondsConferenceRemaining}
          isCardPhoneConference={isCardPhoneConference}
          isCardPhoneConferenceShow={isCardPhoneConferenceShow}
          setIsCallConference={setIsCallConference}
          isCallConference={isCallConference}
          setIsCallTransfer={setIsCallTransfer}
          isCallTransfer={isCallTransfer}
        />
      ),
    }),
    [
      handleCancel,
      isCallConference,
      isCallTransfer,
      isCardPhoneConference,
      isCardPhoneConferenceShow,
      isCardVisible,
      isCardVisibleCallCreated,
      secondsConferenceRemaining,
      secondsRemaining,
      setIsCallConference,
      setIsCallTransfer,
      setSecondsConferenceRemaining,
      setSecondsRemaining,
      setTimeConferenceStatus,
      setTimeStatus,
      timeConferenceStatus,
      timeStatus,
      contacts,
    ]
  );

  const stringToColor = (string: string) => {
    let hash = 0;
    let i;
    for (i = 0; i < string.length; i += 1) {
      hash = string.charCodeAt(i) + ((hash << 5) - hash);
    }
    let color = "#";
    for (i = 0; i < 3; i += 1) {
      const value = (hash >> (i * 8)) & 0xff;
      color += `00${value.toString(16)}`.substr(-2);
    }
    return color;
  };
  const stringAvatar = (name: string) => {
    return {
      style: {
        backgroundColor: stringToColor(name),
      },
      children: `${name?.split(" ")[0][0]}`,
    };
  };
  const handleButtonClick = (tabKey: string) => {
    if (selectedButton === tabKey) {
      setSelectedButton(null);
      setIsFavoriteVisible(false);
      setIsRecentVisible(false);
      setIsContactVisible(false);
      setIsNumpadCallVisible(false);
      setCollapsed(false);
    } else {
      setSelectedButton(tabKey);
      setIsFavoriteVisible(tabKey === "favorite");
      setIsRecentVisible(tabKey === "recent");
      setIsContactVisible(tabKey === "contact");
      setIsNumpadCallVisible(tabKey === "numpad");
      setCollapsed(true);
    }
  };

  const TrapezoidButton: React.FC<TrapezoidButtonProps> = ({ onClick }) => {
    return (
      <div
        className="trapezoid"
        style={{
          color: token.colorBgContainer,
        }}
        onClick={() => {
          onClick();
        }}
      >
        <div
          style={{
            position: "absolute",
            bottom: 0,
            left: "50%",
            transform: "translateX(-50%)",
          }}
        >
          {collapsed ? (
            <UpOutlined style={{ color: token.colorPrimary }} />
          ) : (
            <DownOutlined style={{ color: token.colorPrimary }} />
          )}
        </div>
      </div>
    );
  };
  const [collapsed, setCollapsed] = React.useState(false);

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  const shouldHideCard =
    !Auth?.user?.isUserFavoriteVisible &&
    !Auth?.user?.isUserRecentVisible &&
    !Auth?.user?.isUserContactVisible &&
    !Auth?.user?.isUserNumpadVisible;

  // const isVisibleCount = [isFavoriteVisible, isRecentVisible, isContactVisible, isNumpadCallVisible].filter(
  //   Boolean
  // ).length;

  return (
    <React.Fragment>
      {isDetailBarVisible && simpleUser?.isConnected() ? (
        <Draggable
          nodeRef={nodeRef}
          bounds="parent"
          cancel=".ant-btn, .ant-select, .ant-input, .ant-picker, .ant-checkbox-wrapper, .ant-radio-wrapper, .ant-switch,.ant-collapse,.trapezoid"
        >
          <Card
            ref={nodeRef}
            size="small"
            bordered={false}
            style={{
              bottom: 0,
              right: 0,
              display: isDetailBarVisible ? "block" : "none",
              position: "fixed",
              width: window.innerWidth <= 600 ? window.innerWidth : "342px",
              background: videoLayout ? "rgba(0,0,0,0.1)" : "rgba(200,200,200,0.3)",
              transition: "height 0.3s ease-in-out",
              height: collapsed ? "auto" : "auto",
            }}
          >
            <Card
              styles={{ body: { padding: "10px", height: "auto", width: "100%", alignContent: "center" } }}
              style={{ boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.25)" }}
            >
              <Row justify="space-between">
                <Col>
                  {Auth?.user?.organizeName ? (
                    <Text type="secondary" style={{ lineHeight: "1.5" }}>
                      {Auth?.user?.organizeName}
                    </Text>
                  ) : (
                    <></>
                  )}
                </Col>
                <Col>
                  <Button
                    shape="round"
                    size="small"
                    type="text"
                    onClick={() => setIsDetailBarVisible(false)}
                    style={{ fontSize: "12px" }}
                  >
                    <MinusOutlined />
                  </Button>
                </Col>
                <Divider style={{ margin: "12px 0" }} />
              </Row>

              <Space
                direction="horizontal"
                align="center"
                style={
                  Auth?.user?.displayName
                    ? {
                        display: "flex",
                        justifyContent: "space-around",
                        alignItems: "start",
                        marginBottom: "10px",
                      }
                    : {
                        display: "flex",
                        justifyContent: "space-around",
                        alignItems: "center",
                        marginBottom: "10px",
                      }
                }
              >
                <Avatar
                  size={{ xs: 40, md: 40, lg: 52, xl: 52, xxl: 52 }}
                  {...stringAvatar(`${Auth?.user?.username}`)}
                />

                <Title level={3} style={{ margin: "2px" }}>
                  {Auth?.user?.displayName ? (
                    <Card.Meta
                      style={{ width: "85px" }}
                      title={
                        <Tooltip title={displayName}>
                          <Text
                            style={{
                              flexGrow: 1,
                              overflow: "hidden",
                              whiteSpace: "nowrap",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {displayName}
                          </Text>
                        </Tooltip>
                      }
                      description={
                        <>
                          <Button
                            ghost
                            type="primary"
                            style={{
                              pointerEvents: "none",
                              border: "none",
                              paddingLeft: 0,
                              paddingRight: 10,
                            }}
                          >
                            <PhoneFilled style={{ transform: "scaleX(-1)" }} />
                          </Button>
                          <Text style={{ fontSize: "16px" }}>{Auth?.user?.username}</Text>
                        </>
                      }
                    />
                  ) : (
                    <>
                      <Button size="large" ghost type="primary" style={{ pointerEvents: "none", border: "none" }}>
                        <PhoneFilled style={{ transform: "scaleX(-1)" }} />
                      </Button>
                      {Auth?.user?.username}
                    </>
                  )}
                </Title>
                <SelectStatus
                  styleSettings={{
                    maxWidth: window.innerWidth <= 600 ? "100px" : "140px",
                  }}
                />
              </Space>

              <Space
                direction="horizontal"
                align="center"
                style={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "center",
                  gap: 8,
                  flexWrap: "nowrap",
                }}
              >
                {Auth?.user?.isUserFavoriteVisible && (
                  <Button
                    key="favorite"
                    type={selectedButton === "favorite" ? "default" : "primary"}
                    disabled={selectedButton === "favorite"}
                    size={window.innerWidth <= 600 ? "middle" : "small"}
                    style={{ flex: 1, minWidth: 70, maxWidth: 100, textAlign: "center" }}
                    onClick={() => handleButtonClick("favorite")}
                  >
                    Favorite
                  </Button>
                )}

                {Auth?.user?.isUserRecentVisible && (
                  <Button
                    key="recent"
                    type={selectedButton === "recent" ? "default" : "primary"}
                    disabled={selectedButton === "recent"}
                    size={window.innerWidth <= 600 ? "middle" : "small"}
                    style={{ flex: 1, minWidth: 70, maxWidth: 100, textAlign: "center" }}
                    onClick={() => handleButtonClick("recent")}
                  >
                    Recent
                  </Button>
                )}

                {Auth?.user?.isUserContactVisible && (
                  <Button
                    key="contact"
                    type={selectedButton === "contact" ? "default" : "primary"}
                    disabled={selectedButton === "contact"}
                    size={window.innerWidth <= 600 ? "middle" : "small"}
                    style={{ flex: 1, minWidth: 70, maxWidth: 100, textAlign: "center" }}
                    onClick={() => handleButtonClick("contact")}
                  >
                    Contact
                  </Button>
                )}

                {Auth?.user?.isUserNumpadVisible && (
                  <Button
                    key="numpad"
                    type={selectedButton === "numpad" ? "default" : "primary"}
                    disabled={selectedButton === "numpad"}
                    size={window.innerWidth <= 600 ? "middle" : "small"}
                    style={{ flex: 1, minWidth: 70, maxWidth: 100, textAlign: "center" }}
                    onClick={() => handleButtonClick("numpad")}
                  >
                    Numpad
                  </Button>
                )}
              </Space>
            </Card>

            {!shouldHideCard && (
              <div
                style={{
                  height: "15px",
                  marginTop: "-5px",
                }}
              >
                <Card
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: "transparent",
                    border: "none",
                    height: "0px",
                  }}
                >
                  <TrapezoidButton onClick={toggleCollapse} />
                </Card>
              </div>
            )}

            <div
              style={{
                display: collapsed ? "block" : "none",
                paddingTop: "20px",
              }}
            >
              {isFavoriteVisible || isRecentVisible || isContactVisible || isNumpadCallVisible ? (
                <Card
                  tabBarExtraContent={
                    !isAddContact && !isEditContact && isContactVisible ? (
                      <Tooltip title="Add contact">
                        <Button
                          size="large"
                          onClick={() => setIsAddContact(true)}
                          icon={<UserAddOutlined />}
                          shape="circle"
                        />
                      </Tooltip>
                    ) : (
                      <></>
                    )
                  }
                  tabList={
                    isFavoriteVisible
                      ? [tabList[0]]
                      : isRecentVisible
                      ? [tabList[1]]
                      : isContactVisible
                      ? [tabList[2]]
                      : [tabList[3]]
                  }
                  activeTabKey={
                    isFavoriteVisible ? "tab0" : isRecentVisible ? "tab1" : isContactVisible ? "tab2" : "tab4"
                  }
                >
                  {isFavoriteVisible && contentList["tab0"]}
                  {isRecentVisible && contentList["tab1"]}
                  {isContactVisible && contentList["tab2"]}
                  {/* {isNumpadCallVisible && contentList["tab3"]} */}
                  {isNumpadCallVisible && contentList["tab4"]}
                </Card>
              ) : (
                <></>
              )}
            </div>
          </Card>
        </Draggable>
      ) : (
        <FloatButtonCardPhone />
      )}

      {isCardVisible || isCardVisibleCallCreated || isCardPhoneConference ? (
        <Draggable
          nodeRef={secondNodeRef}
          bounds="parent"
          cancel=".ant-btn, .ant-select, .ant-input, .ant-picker, .ant-checkbox-wrapper, .ant-radio-wrapper, .ant-switch,.ant-collapse,.trapezoid"
        >
          <Card
            ref={secondNodeRef}
            size="small"
            bordered={false}
            style={{
              bottom: 0,
              right: 0,
              display: "block",
              position: "fixed",
              width: window.innerWidth <= 600 ? window.innerWidth : "342px",
              background: videoLayout ? "rgba(0,0,0,0.1)" : "rgba(200,200,200,0.3)",
              transition: "height 0.3s ease-in-out",
              height: "auto",
            }}
          >
            <Card
              styles={{ body: { padding: "10px", height: "auto", alignContent: "center", width: "100%" } }}
              style={{ boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.25)" }}
              tabList={isCardVisible ? [cardPhoneTabList[0]] : [cardPhoneTabList[1]]}
              activeTabKey={isCardVisible ? "tab0" : "tab1"}
              tabBarExtraContent={<MediaControl />}
            >
              {isCardVisible
                ? [
                    isCardVisible && cardPhoneContentList["tab0"],
                    isCardPhoneConference && cardPhoneContentList["tab2"],
                    (isCallTransfer || isCallConference) && contentList["tab3"],
                  ]
                : [
                    isCardVisibleCallCreated && cardPhoneContentList["tab1"],
                    isCardPhoneConference && cardPhoneContentList["tab2"],
                    (isCallTransfer || isCallConference) && contentList["tab3"],
                  ]}
            </Card>
          </Card>
        </Draggable>
      ) : (
        <></>
      )}
    </React.Fragment>
  );
};
export default DetailBar;