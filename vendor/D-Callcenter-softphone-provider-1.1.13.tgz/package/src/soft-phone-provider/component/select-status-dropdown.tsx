import React from "react";
import { Dropdown, Button, Menu } from "antd";
import { DownOutlined } from "@ant-design/icons";
import useSelectStatusContext, { ListType } from "../../context/select-status-context";


interface SelectStatusProps {
  styleSettings?: React.CSSProperties;
  initialDisplayField?: string;
}

const SelectStatus: React.FC<SelectStatusProps> = ({ styleSettings, initialDisplayField = "name" }) => {
  const {
    statusList,
    selectedStatus,
    setSelectedStatus,
    displayField,
    placeholder,
    onSelect,
  } = useSelectStatusContext();

  const handleMenuClick = (e: any) => {
    const selectedItem = statusList.find((item, index) => getItemName(item, index) === e.key);
    if (selectedItem) {
      setSelectedStatus(selectedItem);
      onSelect(selectedItem); 
    }
  };


  const getItemName = (item: ListType, index: number): string => {
    const value = item[displayField];
    return typeof value === 'string' || typeof value === 'number' ? String(value) : `Unnamed Item ${index + 1}`;
  };


  const menuItems = statusList.map((item, index) => ({
    key: getItemName(item, index),
    label: (
      <div>
        <span style={{ marginRight: "8px" }}>{item.icon}</span>
        <span>{getItemName(item, index)}</span>
      </div>
    ),
  }));

  const menuProps = {
    items: menuItems,
    onClick: handleMenuClick,
  };

  return (
    <Dropdown menu={menuProps}>
      <Button
        style={{
          borderRadius: "25px",
          width: "auto",
          padding: "0 16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          ...styleSettings,
        }}
      >
        {selectedStatus?.icon ? <span style={{ marginRight: "4px" }}>{selectedStatus.icon}</span> : <span></span>}
        <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {selectedStatus ? getItemName(selectedStatus, statusList.indexOf(selectedStatus)) : placeholder}
        </span>
        <DownOutlined />
      </Button>
    </Dropdown>
  );
};


export default SelectStatus;