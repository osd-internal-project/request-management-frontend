import {
  AudioFilled,
  AudioMutedOutlined,
  PauseOutlined,
  PhoneFilled,
  PlayCircleOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { PhoneForwarded } from "react-feather";
import { Avatar, Button, Col, Row, Tooltip, Typography, notification } from "antd";
import React from "react";
import { useInviterUser } from "../../context/inviter-user-context";
import { useContainerLayout } from "../../context/video-context";
import { useSimpleUser } from "../../context/simple-user-context";
import { usePhoneStatus } from "../../context/phone-status-context";
import { useConferenceStatus } from "../../context/conference-status-context";
import { handleHangUp, handleMute, handleUnMute, handleHold, handleUnHold, handleTransfer, handleCallConference } from "../../lib/phone-call-handler";
import { GetDisplayName } from "../../lib/get-display-name";

import CheckLongText from "./check-long-text";

import  useExternalDatabase  from "../../context/update-data-transaction-context";

// Define the props interface
type timeStatus = string;
type settimeStatus = (timeStatus: Partial<timeStatus>) => void;
type secondsRemaining = number;
type setSecondsRemaining = (secondsRemaining: Partial<secondsRemaining>) => void;

interface Name {
  id: string;
  name: {
    displayName: string;
    number: string;
    favorite: boolean;
  };
}
interface resultContacts {
  letter: string;
  names: Name[];
}

type CardPhoneCallCreatedProps = {
  resultContact: resultContacts[];
  isCardVisibleCallCreated: boolean;
  setTimeStatus: settimeStatus;
  timeStatus: timeStatus;
  setSecondsRemaining: setSecondsRemaining;
  secondsRemaining: secondsRemaining;
  setIsCallConference: (value: boolean | ((prevState: boolean) => boolean)) => void;
  setIsCallTransfer: (value: boolean | ((prevState: boolean) => boolean)) => void;
  isCallConference: boolean;
  isCallTransfer: boolean;
};

// Define the component
const CardPhoneCallCreated: React.FC<CardPhoneCallCreatedProps> = ({
  resultContact,
  isCardVisibleCallCreated,
  setTimeStatus,
  timeStatus,
  setSecondsRemaining,
  secondsRemaining,
  setIsCallConference,
  isCallConference,
  setIsCallTransfer,
  isCallTransfer,
}) => {
  const { Text } = Typography;

  const { videoLayout } = useContainerLayout();
  const STATUS = {
    STARTED: "Started",
    STOPPED: "Stopped",
  };

  const INITIAL_COUNT = 0;
  const { simpleUser } = useSimpleUser();
  const { inviterUser } = useInviterUser();
  const callData = useExternalDatabase();

  const remoteUser = simpleUser?.session?.remoteIdentity?.uri?.user;
  const displayName = GetDisplayName(resultContact || [], remoteUser);

  const secondsToDisplay = secondsRemaining % 60;
  const minutesRemaining = (secondsRemaining - secondsToDisplay) / 60;
  const minutesToDisplay = minutesRemaining % 60;
  const hoursToDisplay = (minutesRemaining - minutesToDisplay) / 60;
  const { phoneStatus, setPhoneStatus } = usePhoneStatus();
  const { conferenceStatus } = useConferenceStatus();

  const handleHangUpWrapper = async () => {
    await handleHangUp(simpleUser, () => handleResetTime(), () => handleResetTime(), callData);
  };

  const handleMuteWrapper = async () => {
    await handleMute(simpleUser, setPhoneStatus);
  };

  const handleUnMuteWrapper = async () => {
    await handleUnMute(simpleUser, setPhoneStatus);
  };

  const handleHoldWrapper = async () => {
    await handleHold(simpleUser);
  };

  const handleUnHoldWrapper = async () => {
    await handleUnHold(simpleUser);
  };

  const handleTransferWrapper = async () => {
    await handleTransfer(simpleUser, setPhoneStatus, callData);
    setIsCallConference(false);
    setIsCallTransfer((prevState: any) => !prevState);
  };

  const handleCallConferenceWrapper = async () => {
    await handleCallConference(simpleUser, setPhoneStatus, callData);
    setIsCallTransfer(false);
    setIsCallConference((prevState: any) => !prevState);
  };

  const handleResetTime = () => {
    setTimeStatus(STATUS.STOPPED);
    setSecondsRemaining(INITIAL_COUNT);
    setIsCallConference(false);
    setIsCallTransfer(false);
  };

  const useInterval = (callback: any, delay: any) => {
    const savedCallback = React.useRef<() => void>();

    React.useEffect(() => {
      savedCallback.current = callback;
    }, [callback]);

    React.useEffect(() => {
      const tick = () => {
        if (savedCallback.current) {
          savedCallback.current();
        }
      };
      if (delay !== null) {
        const id = setInterval(tick, delay);
        return () => clearInterval(id);
      } else {
        return undefined; // Explicitly return undefined when delay is null
      }
    }, [delay]);
  };

  const twoDigits = (num: number) => String(num).padStart(2, "0");

  useInterval(
    () => {
      if (secondsRemaining >= 0) {
        setSecondsRemaining(secondsRemaining + 1);
      } else {
        setTimeStatus(STATUS.STOPPED);
      }
    },
    timeStatus === STATUS.STARTED ? 1000 : null
  );

  return isCardVisibleCallCreated ? (
    <>
      <Row style={{ marginBottom: "10px" }}>
        <Col span={5}>
          <Avatar size="large" icon={<UserOutlined />} />
        </Col>
        <Col span={14}>
          <Text strong>{<CheckLongText text={displayName} maxWidth={150} maxLength={20}/>}</Text>
          {phoneStatus?.answer === false ? (
            <Text
              type="success"
              style={{
                display: !inviterUser?.session ? "flex" : "none",
              }}
            >
              Calling
            </Text>
          ) : (
            <Text
              type="success"
              style={{
                display: !inviterUser?.session ? "flex" : "none",
              }}
            >
              Talking
            </Text>
          )}
          {!conferenceStatus?.answer === false ? (
            <Text
              type="success"
              style={{
                display: inviterUser?.session ? "flex" : "none",
              }}
            >
              Meeting
            </Text>
          ) : (
            <Text
              type="success"
              style={{
                display: inviterUser?.session ? "flex" : "none",
              }}
            >
              Talking
            </Text>
          )}
          <Text>
            {twoDigits(hoursToDisplay)}:{twoDigits(minutesToDisplay)}:{twoDigits(secondsToDisplay)}
          </Text>
        </Col>
        <Col span={5} style={{ alignContent: "center", justifyContent: "center" }}>
          <Tooltip title="HangUp">
            <Button
              danger
              shape="circle"
              type="primary"
              onClick={handleHangUpWrapper}
              icon={<PhoneFilled rotate={225} />}
              size="large"
            />
          </Tooltip>
        </Col>
      </Row>

      <Row style={{ marginBottom: "10px" }}>
        {phoneStatus?.answer !== false ? (
          <>
            <Col span={5} offset={4}>
              <Tooltip title={!phoneStatus?.mute ? "Mute" : "Unmute"}>
                <Button
                  shape="circle"
                  onClick={() => {
                    if (!phoneStatus?.mute) {
                      handleMuteWrapper();
                    } else {
                      handleUnMuteWrapper();
                    }
                  }}
                  icon={!phoneStatus?.mute ? <AudioFilled /> : <AudioMutedOutlined />}
                  danger={phoneStatus?.mute}
                  type="primary"
                  size="large"
                />
              </Tooltip>
            </Col>

            <Col span={5}>
              {!simpleUser?.isHeld() ? (
                <Tooltip title="Hold">
                  <Button type="primary" shape="circle" icon={<PauseOutlined />} onClick={handleHoldWrapper} size="large" />
                </Tooltip>
              ) : (
                <Tooltip title="Unhold">
                  <Button
                    type="primary"
                    shape="circle"
                    icon={<PlayCircleOutlined />}
                    onClick={handleUnHoldWrapper}
                    size="large"
                  />
                </Tooltip>
              )}
            </Col>

            <Col span={5}>
              <Tooltip title="Transfer">
                <Button
                  shape="circle"
                  type={isCallTransfer ? "default" : "primary"}
                  onClick={handleTransferWrapper}
                  icon={<PhoneForwarded size={20} style={{ marginTop: "3px" }} />}
                  size="large"
                />
              </Tooltip>
            </Col>

            <Col span={5} style={{ display: videoLayout ? "none" : "flex" }}>
              <Tooltip title="Conference">
                <Button
                  type={isCallConference ? "default" : "primary"}
                  shape="circle"
                  onClick={handleCallConferenceWrapper}
                  icon={<TeamOutlined size={20} />}
                  size="large"
                />
              </Tooltip>
            </Col>
          </>
        ) : (
          <></>
        )}
      </Row>
    </>
  ) : (
    <></>
  );
};

export default CardPhoneCallCreated;
