import React from "react";
import { Grid, notification, FloatButton, Menu } from "antd";
import { useDetailBar } from "../../context/detail-bar-context";
import { MenuOutlined, UserDeleteOutlined } from "@ant-design/icons";
import useSoftPhoneUser from "../../context/soft-phone-user-context";
import { useSimpleUser } from "../../context/simple-user-context";

interface FloatButtonCardPhoneProps {
  icon?: React.ReactNode;
}

const FloatButtonCardPhone: React.FC<FloatButtonCardPhoneProps> = ({ icon }) => {
  const Auth = useSoftPhoneUser();
  const screens = Grid.useBreakpoint();
  const [internetStatus, setInternetStatus] = React.useState<boolean>(navigator.onLine);
  const { isDetailBarVisible, setIsDetailBarVisible } = useDetailBar();
  // const [authStatus, setAuthStatus] = React.useState<boolean>();
  const { simpleUser } = useSimpleUser();

  const showNotification = (title: string, message: string, type: "success" | "info" | "warning" | "error") => {
    notification[type]({
      message: title,
      description: message,
    });
  };

  const handleOnline = () => {
    setInternetStatus(true);
    showNotification("Internet Status", "Internet is back online!", "success");
  };

  const handleOffline = () => {
    setInternetStatus(false);
    showNotification("Internet Status", "Internet connection lost!", "error");
  };

  const toggleDetailBarVisible = () => {
    setIsDetailBarVisible((prevState: any) => !prevState);
  };

  // React.useEffect(() => {
  //   if (simpleUser === null) {
  //     setAuthStatus(false);
  //   } else {
  //     simpleUser.delegate = {
  //       onReject: async () => {
  //         const username = Auth?.user?.username;
  //         showNotification(
  //           "Authentication Status",
  //           `Login attempt with the phone number "${username}" was rejected. Please verify your number and try again or contact support for assistance.`,
  //           "error"
  //         );
  //         setAuthStatus(false);
  //       },
  //       onRegistered: async () => {
  //         showNotification("Authentication Status", "You have successfully logged in.", "success");
  //         setAuthStatus(true);
  //       },
  //     };
  //   }
  // }, [simpleUser, Auth?.user?.username]);

  React.useEffect(() => {
    window.addEventListener("offline", handleOffline);
    window.addEventListener("online", handleOnline);
    return () => {
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("online", handleOnline);
    };
  }, []);

  return (
    <>
      {simpleUser?.isConnected() ? (
        <FloatButton
          icon={internetStatus ? Auth?.user?.iconOnline : Auth?.user?.iconOffline}
          type={internetStatus ? "primary" : "default"}
          shape="circle"
          tooltip={!screens.xs && internetStatus && Auth?.user?.username ? Auth.user.username : ""}
          onClick={toggleDetailBarVisible}
          badge={{
            dot: true,
            style: {
              boxShadow: "none",
              backgroundColor: internetStatus ? "green" : "grey",
            },
          }}
        />
      ) : (
        <FloatButton
          icon={Auth?.user?.iconOffline}
          type={"default"}
          shape="circle"
          tooltip="Unregistered"
          badge={{
            dot: true,
            style: {
              boxShadow: "none",
              backgroundColor: "red",
            },
          }}
        />
      )}
    </>
  );
};

export default FloatButtonCardPhone;
