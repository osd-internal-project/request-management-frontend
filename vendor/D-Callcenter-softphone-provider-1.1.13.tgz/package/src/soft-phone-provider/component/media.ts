export function getVideo(id: string): Promise<HTMLElement> {
  return new Promise((resolve, reject) => {
    try {
      const el = document.getElementById(id);
      if (!el) {
        reject(`cannot get ${id}`);
      } else {
        resolve(el);
      }
    } catch (e) {
      console.error(e);
      reject(e);
    }
  });
}
