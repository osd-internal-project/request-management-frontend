import React from "react";
import { Delete } from "react-feather";

import { Button, Input, Space, Tooltip } from "antd";
import { VideoCameraFilled } from "@ant-design/icons";

import useSound from "use-sound";
import NoZero from "../../sound/no-zero.mp3";
import NoOne from "../../sound/no-one.mp3";
import NoTwo from "../../sound/no-two.mp3";
import NoThree from "../../sound/no-three.mp3";
import NoFour from "../../sound/no-four.mp3";
import NoFive from "../../sound/no-five.mp3";
import NoSix from "../../sound/no-six.mp3";
import NoSeven from "../../sound/no-seven.mp3";
import NoEight from "../../sound/no-eight.mp3";
import NoNine from "../../sound/no-nine.mp3";

import "./numpad.css";
import useSoftPhoneUser from "../../context/soft-phone-user-context";
import { useSimpleUser } from "../../context/simple-user-context";
import { SessionState } from "sip.js";

const Numpad = (props: any) => {
  const Auth = useSoftPhoneUser();
  const limitDigit = Auth?.user?.limitDigit || 10;
  const duration = Auth?.user.duration || 2000;

  const {
    onChange,
    onKeyPress,
    setInputValue,
    inputValue,
    callToAnotherVideo,
    callToAnother,
    iconphone,
    iconphoneshape,
    titlephone,
    disabledphone,
  } = props;
  const [Number0] = useSound(NoZero);
  const [Number1] = useSound(NoOne);
  const [Number2] = useSound(NoTwo);
  const [Number3] = useSound(NoThree);
  const [Number4] = useSound(NoFour);
  const [Number5] = useSound(NoFive);
  const [Number6] = useSound(NoSix);
  const [Number7] = useSound(NoSeven);
  const [Number8] = useSound(NoEight);
  const [Number9] = useSound(NoNine);
  const { simpleUser } = useSimpleUser();

  const onButtonPress = React.useCallback(
    async (_value: any) => {
      // ตรวจสอบก่อนเพิ่มค่าลงใน inputValue
      if (inputValue.length < limitDigit) {
        const handleOnChange = (_value: any) => {
          const newValue = inputValue.concat(_value);
          setInputValue(newValue);
          onChange(newValue);
        };
        if (onChange) handleOnChange(_value);
        if (onKeyPress) onKeyPress(_value);
      }
      const body = {
        contentDisposition: "render",
        contentType: "application/dtmf-relay",
        content: "Signal=" + _value + "\r\nDuration=" + duration,
      };

      const requestOptions = { body };
      if (simpleUser?.session && simpleUser?.session?.state === SessionState?.Established && !simpleUser?.isHeld()) {
        await simpleUser?.session?.info({ requestOptions });
      }

      switch (_value) {
        case 0:
          return Number0();
        case 1:
          return Number1();
        case 2:
          return Number2();
        case 3:
          return Number3();
        case 4:
          return Number4();
        case 5:
          return Number5();
        case 6:
          return Number6();
        case 7:
          return Number7();
        case 8:
          return Number8();
        case 9:
          return Number9();
        case "*":
          return Number1();
        case "#":
          return Number3();
        default:
          return null;
      }
    },
    [Number0, Number1, Number2, Number3, Number4, Number5, Number6, Number7, Number8, Number9, duration, inputValue, limitDigit, onChange, onKeyPress, setInputValue, simpleUser]
  );

  const buttonStyle = {
    fontFamily: "Roboto",
    fontStyle: "normal",
    fontWeight: "400",
    fontSize: "1.2rem",
    border: "none",
  };

  const spaceStyle = {
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    marginBottom: "1.1rem",
  };

  const renderButton = (value: any, size: "large" | "middle" = "large") => (
    <Button key={value} onClick={() => onButtonPress(value)} shape="circle" style={buttonStyle} size={size}>
      {value}
    </Button>
  );

  const handleChange = (event: any) => {
    const value = event.target.value;
    const regex = /^[0-9*#]*$/;

    // ตรวจสอบว่าเป็นตัวเลข/สัญลักษณ์ที่อนุญาตและไม่เกิน limitDigit
    if (regex.test(value) && value.length <= limitDigit) {
      setInputValue(value); // อัปเดตค่าใน state
      onChange(value); // หากต้องการส่งค่าไปยัง Parent Component
    }
  };

  const handleClear = () => {
    const newString = inputValue.substring(0, inputValue.length - 1);
    setInputValue(newString);
    onChange(newString);
  };

  return (
    <>
      <Space style={{ ...spaceStyle, justifyContent: "center" }}>
        <Input
          style={buttonStyle}
          value={inputValue}
          type="tel"
          onChange={handleChange}
          size="large"
          pattern="[0-9*#]*"
          className="centered-input"
          variant="filled"
        />
      </Space>
      {[
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
        ["*", 0, "#"],
      ].map((group, index) => (
        <Space key={index} style={spaceStyle}>
          {group.map((value) => renderButton(value))}
        </Space>
      ))}
      <Space style={spaceStyle}>
        <Tooltip title="Video Call">
          <Button
            type="primary"
            ghost
            style={buttonStyle}
            onClick={callToAnotherVideo}
            shape="circle"
            icon={<VideoCameraFilled />}
            size="middle"
            disabled={disabledphone}
          />
        </Tooltip>
        <Tooltip title={titlephone}>
          <Button
            type="primary"
            shape={iconphoneshape}
            onClick={callToAnother}
            style={buttonStyle}
            icon={iconphone}
            size="large"
            disabled={disabledphone}
          />
        </Tooltip>
        <Button
          type="text"
          disabled={!inputValue.length}
          onClick={handleClear}
          style={buttonStyle}
          size="middle"
          icon={<Delete />}
        />
      </Space>
    </>
  );
};

export default Numpad;
