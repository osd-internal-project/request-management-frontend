import React from "react";

import { Button, Col, Row, Typography, notification, Tooltip, Avatar } from "antd";

import {
  UserOutlined,
  AudioMutedOutlined,
  AudioFilled,
  PauseOutlined,
  PhoneFilled,
  PlayCircleOutlined,
  TeamOutlined,
} from "@ant-design/icons";

import { PhoneForwarded } from "react-feather";

import { useInviterUser } from "../../context/inviter-user-context";
import { useSimpleUser } from "../../context/simple-user-context";
import { usePhoneStatus } from "../../context/phone-status-context";
import { useConferenceStatus } from "../../context/conference-status-context";
import { GetDisplayName } from "../../lib/get-display-name";
import CheckLongText from "./check-long-text";

type TimeConferenceStatusType = string;
type SettimeConferenceStatusType = (timeConferenceStatus: TimeConferenceStatusType) => void;

type SecondsConferenceRemainingType = number;
type SetsecondsConferenceRemainingType = (secondsConferenceRemaining: SecondsConferenceRemainingType) => void;

interface Name {
  id: string;
  name: {
    displayName: string;
    number: string;
    favorite: boolean;
  };
}
interface resultContacts {
  letter: string;
  names: Name[];
}

type CardPhoneConferenceTypes = {
  resultContact: resultContacts[];
  isCardPhoneConference: boolean;
  setTimeConferenceStatus: SettimeConferenceStatusType;
  timeConferenceStatus: TimeConferenceStatusType;
  setSecondsConferenceRemaining: SetsecondsConferenceRemainingType;
  secondsConferenceRemaining: SecondsConferenceRemainingType;
  isCardPhoneConferenceShow: any;
  setIsCallConference: (value: boolean | ((prevState: boolean) => boolean)) => void;
  setIsCallTransfer: (value: boolean | ((prevState: boolean) => boolean)) => void;
  isCallConference: boolean;
  isCallTransfer: boolean;
};

const CardPhoneConference: React.FC<CardPhoneConferenceTypes> = ({
  resultContact,
  isCardPhoneConference,
  setTimeConferenceStatus,
  timeConferenceStatus,
  setSecondsConferenceRemaining,
  secondsConferenceRemaining,
  setIsCallConference,
  isCallConference,
  setIsCallTransfer,
  isCallTransfer,
}) => {
  const { Text } = Typography;
  const { phoneStatus } = usePhoneStatus();
  const { conferenceStatus, setConferenceStatus } = useConferenceStatus();
  const STATUS = {
    STARTED: "Started",
    STOPPED: "Stopped",
  };
  const INITIAL_COUNT = 0;
  const { inviterUser } = useInviterUser();
  const { simpleUser } = useSimpleUser();

  const remoteUser = inviterUser?.session?.remoteIdentity?.uri?.user;
  const displayName = GetDisplayName(resultContact || [], remoteUser);

  const secondsToDisplay = secondsConferenceRemaining % 60;
  const minutesRemaining = (secondsConferenceRemaining - secondsToDisplay) / 60;
  const minutesToDisplay = minutesRemaining % 60;
  const hoursToDisplay = (minutesRemaining - minutesToDisplay) / 60;

  const handleHangUp = async () => {
    try {
      await inviterUser?.hangup();
      setConferenceStatus({ created: false, answer: false });
      handleResetTime();
    } catch (error) {
      console.error("Error in CardPhoneConference handleHangUp:", error);
      notification.error({
        message: "An error occurred during CardPhoneConference handleHangUp",
        description: `${error}`,
      });
    }
  };
  const handleMute = async () => {
    await inviterUser?.mute();
    setConferenceStatus({ mute: true });
  };
  const handleUnMute = async () => {
    await inviterUser?.unmute();
    setConferenceStatus({ mute: false });
  };
  const handleTransfer = async () => {
    setIsCallConference(false);
    setIsCallTransfer((prevState: any) => !prevState);
  };
  const handleHold = async () => {
    await inviterUser?.hold().catch(() => {
      notification.error({
        message: "Unable to place the call on hold.",
      });
    });
  };
  const handleUnHold = async () => {
    await inviterUser?.unhold().catch(() => {
      notification.error({
        message: "Unable to resume the call from hold.",
      });
    });
  };
  const handleCallConference = async () => {
    setIsCallTransfer(false);
    setIsCallConference((prevState: any) => !prevState);
  };
  const handleResetTime = () => {
    setTimeConferenceStatus(STATUS.STOPPED);
    setSecondsConferenceRemaining(INITIAL_COUNT);
    setIsCallConference(false);
    setIsCallTransfer(false);
  };
  // source: https://overreacted.io/making-setinterval-declarative-with-react-hooks/
  const useInterval = (callback: any, delay: any) => {
    const savedCallback = React.useRef<() => void>();

    // Remember the latest callback.
    React.useEffect(() => {
      savedCallback.current = callback;
    }, [callback]);

    // Set up the interval.
    React.useEffect(() => {
      const tick = () => {
        savedCallback.current?.();
      };

      if (delay !== null) {
        const id = setInterval(tick, delay);
        return () => clearInterval(id);
      } else {
        return () => {};
      }
    }, [delay]);
  };
  // https://stackoverflow.com/a/2998874/1673761
  const twoDigits = (num: number) => String(num).padStart(2, "0");
  useInterval(
    () => {
      if (secondsConferenceRemaining >= 0) {
        setSecondsConferenceRemaining(secondsConferenceRemaining + 1);
      } else {
        setTimeConferenceStatus(STATUS.STOPPED);
      }
    },
    timeConferenceStatus === STATUS.STARTED ? 1000 : null
    // passing null stops the interval
  );

  return isCardPhoneConference ? (
    <>
      <Row style={{ marginBottom: "10px" }}>
        <Col span={5}>
          <Avatar size="large" icon={<UserOutlined />} />
        </Col>
        <Col span={14}>
          <Text strong>{<CheckLongText text={displayName} maxWidth={150} maxLength={20}/>}</Text>
          {!conferenceStatus?.answer ? (
            <Text type="success" style={{ display: simpleUser?.session ? "flex" : "none" }}>
              Invite meeting
            </Text>
          ) : (
            <Text type="success" style={{ display: simpleUser?.session ? "flex" : "none" }}>
              Meeting
            </Text>
          )}
          {!phoneStatus?.answer ? (
            <Text
              type="success"
              style={{
                display: !simpleUser?.session ? "flex" : "none",
              }}
            >
              talking
            </Text>
          ) : null}
          <Text>
            {twoDigits(hoursToDisplay)}:{twoDigits(minutesToDisplay)}:{twoDigits(secondsToDisplay)}
          </Text>
        </Col>
        <Col span={5} style={{ alignContent: "center", justifyContent: "center" }}>
          <Tooltip title="HangUp">
            <Button
              danger
              shape="circle"
              type="primary"
              onClick={handleHangUp}
              icon={<PhoneFilled rotate={225} />}
              size="large"
            />
          </Tooltip>
        </Col>
      </Row>
      <Row style={{ marginBottom: "10px" }}>
        {conferenceStatus?.answer !== false ? (
          <>
            <Col span={5} offset={4}>
              <Tooltip title={!conferenceStatus?.mute ? "Mute" : "Unmute"}>
                <Button
                  shape="circle"
                  onClick={() => {
                    if (!conferenceStatus?.mute) {
                      handleMute();
                    } else {
                      handleUnMute();
                    }
                  }}
                  icon={!conferenceStatus?.mute ? <AudioFilled /> : <AudioMutedOutlined />}
                  danger={conferenceStatus?.mute}
                  type="primary"
                  size="large"
                />
              </Tooltip>
            </Col>

            <Col span={5}>
              {!inviterUser?.isHeld() ? (
                <Tooltip title="Hold">
                  <Button type="primary" shape="circle" icon={<PauseOutlined />} onClick={handleHold} size="large" />
                </Tooltip>
              ) : (
                <Tooltip title="Unhold">
                  <Button
                    type="primary"
                    shape="circle"
                    icon={<PlayCircleOutlined />}
                    onClick={handleUnHold}
                    size="large"
                  />
                </Tooltip>
              )}
            </Col>

            <Col span={5}>
              <Tooltip title="Transfer">
                <Button
                  shape="circle"
                  type={isCallTransfer ? "default" : "primary"}
                  onClick={handleTransfer}
                  icon={<PhoneForwarded size={20} style={{ marginTop: "3px" }} />}
                  size="large"
                />
              </Tooltip>
            </Col>

            <Col>
              <Tooltip title="Conference">
                <Button
                  type={isCallConference ? "default" : "primary"}
                  shape="circle"
                  onClick={handleCallConference}
                  icon={<TeamOutlined size={20} />}
                  size="large"
                />
              </Tooltip>
            </Col>
          </>
        ) : (
          <></>
        )}
      </Row>
    </>
  ) : (
    <></>
  );
};

export default CardPhoneConference;
