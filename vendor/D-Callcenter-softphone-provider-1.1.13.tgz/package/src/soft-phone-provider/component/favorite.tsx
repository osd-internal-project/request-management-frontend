import React from "react";

import { Avatar, Button, Popconfirm, Tooltip, Collapse, Space, Row, Col, Card, Spin, List, Divider, Empty } from "antd";
import {
  UserDeleteOutlined,
  EditOutlined,
  VideoCameraFilled,
  PhoneFilled,
  StarFilled,
  StarOutlined,
  CaretDownOutlined,
} from "@ant-design/icons";

import { usePhoneStatus } from "../../context/phone-status-context";
import { useContainerLayout } from "../../context/video-context";
import useSoftPhoneUser from "../../context/soft-phone-user-context";
import { useSimpleUser } from "../../context/simple-user-context";
import { useRecentCallList } from "../../context/recent-calllist-context";
import { useInviterUser } from "../../context/inviter-user-context";

import EditContact from "./edit-contact";
import { showNotification } from "../../lib/notification-handler";

import CheckLongText from "./check-long-text";

import { UpdateFavoriteStatus } from "../../lib/transaction-handler";
import useExternalDatabase from "../../context/update-data-transaction-context";
import { callToAnother, callToAnotherVideo } from "../../lib/phone-call-handler";

const Favorite = ({ result, isEditContact, setIsEditContact, currentContact, setCurrentContact }: any) => {
  const { setPhoneStatus } = usePhoneStatus();
  const { setVideoLayout } = useContainerLayout();
  const Auth = useSoftPhoneUser();
  const { simpleUser } = useSimpleUser();
  const { inviterUser } = useInviterUser();
  const { recentCallList, setFetch, setUUID, uuid } = useRecentCallList();
  const [loading, setLoading] = React.useState(false);
  const [visibleFavorite, setVisibleFavorite] = React.useState(5);
  const session = simpleUser?.session ? true : false || inviterUser?.session ? true : false;
  const callData = useExternalDatabase();

  const stringToColor = (string: string) => {
    let hash = 0;
    let i;
    for (i = 0; i < string.length; i += 1) {
      hash = string.charCodeAt(i) + ((hash << 5) - hash);
    }
    let color = "#";
    for (i = 0; i < 3; i += 1) {
      const value = (hash >> (i * 8)) & 0xff;
      color += `00${value.toString(16)}`.substr(-2);
    }
    return color;
  };
  const stringAvatar = (name: string) => {
    return {
      style: {
        backgroundColor: stringToColor(name),
      },
      children: `${name?.split(" ")[0][0]}`,
    };
  };

  const handleDelete = (id: any) => async () => {
    try {
      const txContacts = await recentCallList.transaction("ContactLists", "readwrite");
      await txContacts.objectStore("ContactLists").delete(id);
      txContacts.oncomplete = () => {
        setFetch(true);
        showNotification("success", "Deleted successfully.");
      };
    } catch (e) {
      console.error("Error", e);
    }
  };

  const handleFavorite = (id: any, favorite: boolean) => async () => {
    try {
      await UpdateFavoriteStatus(id, favorite, recentCallList, callData);
      setFetch(true);
      showNotification("success", "Updated successfully.");
    } catch (e) {
      console.error("Error", e);
      showNotification("error", "Failed to update favorite status.", "An error occurred while updating.");
    }
  };

  const loadMoreItems = () => {
    if (!result) return;
    const allFavorite = result.length;
    const favoriteShowAll = visibleFavorite <= allFavorite;

    if (favoriteShowAll) {
      setVisibleFavorite((prev) => prev + 5);
    } else if (!favoriteShowAll) {
      setLoading(false);
    }
  };

  const handleScroll = (event: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, clientHeight, scrollHeight } = event.currentTarget;

    if (scrollTop + clientHeight >= scrollHeight - 50 && !loading) {
      setLoading(true);
      loadMoreItems();
      setTimeout(() => setLoading(false), 1000);
    }
  };

  const favoriteContacts = result?.flatMap((row: any) => row?.names?.filter((rowData: any) => rowData?.name?.favorite));

  return (
    <Space direction="vertical" style={{ width: "100%" }}>
      {isEditContact ? (
        <EditContact setIsEditContact={setIsEditContact} contact={currentContact} />
      ) : (
        <Card
          style={{
            maxHeight: "35vh",
            overflowY: "auto",
            scrollbarWidth: "none",
            msOverflowStyle: "none",
          }}
          onScroll={handleScroll}
          size="small"
        >
          {favoriteContacts && favoriteContacts.length > 0 ? (
            favoriteContacts?.map((rowData: any) => {
              const displayName = rowData?.name?.displayName || "";
              const items = [
                {
                  key: `${rowData?.id}`,
                  label: (
                    <List
                      itemLayout="vertical"
                      dataSource={[rowData]}
                      renderItem={(rowData: any) => (
                        <List.Item key={`${rowData?.id}`}>
                          <List.Item.Meta
                            style={{ marginBlockEnd: "0px", width: "250px" }}
                            avatar={<Avatar {...stringAvatar(`${rowData?.name?.displayName}`)} size="large" />}
                            title={<CheckLongText text={displayName} maxWidth={200} maxLength={20} />}
                            description={rowData?.name?.number}
                          />
                        </List.Item>
                      )}
                    />
                  ),
                  children: (
                    <Row align="middle" justify="center" gutter={[16, 16]}>
                      <Col>
                        <Tooltip title="Favorite">
                          <Button
                            type="text"
                            icon={
                              rowData?.name?.favorite ? (
                                <StarFilled style={{ color: "#fadb14", fontSize: "24px" }} />
                              ) : (
                                <StarOutlined style={{ fontSize: "24px" }} />
                              )
                            }
                            onClick={handleFavorite(rowData?.id, !rowData?.name?.favorite)}
                            shape="circle"
                          />
                        </Tooltip>
                      </Col>
                      <Col>
                        <Tooltip title="Video Call">
                          <Button
                            type="primary"
                            onClick={(e) => {
                              e.preventDefault();
                              callToAnotherVideo(
                                setPhoneStatus,
                                setVideoLayout,
                                rowData?.name?.number,
                                Auth,
                                recentCallList,
                                setFetch,
                                uuid,
                                setUUID,
                                callData,
                                simpleUser
                              );
                            }}
                            icon={<VideoCameraFilled />}
                            size="large"
                            shape="circle"
                            disabled={session}
                          />
                        </Tooltip>
                      </Col>
                      <Col>
                        <Tooltip title="Call">
                          <Button
                            type="primary"
                            onClick={(e) => {
                              e.preventDefault();
                              callToAnother(
                                setPhoneStatus,
                                setVideoLayout,
                                rowData?.name?.number,
                                Auth,
                                recentCallList,
                                setFetch,
                                uuid,
                                setUUID,
                                callData,
                                simpleUser
                              );
                            }}
                            icon={<PhoneFilled />}
                            size="large"
                            shape="circle"
                            disabled={session}
                          />
                        </Tooltip>
                      </Col>
                      <Col>
                        <Tooltip title="Edit Number">
                          <Button
                            type="primary"
                            onClick={() => {
                              setIsEditContact(true);
                              setCurrentContact(rowData);
                            }}
                            icon={<EditOutlined />}
                            size="large"
                            shape="circle"
                          />
                        </Tooltip>
                      </Col>
                      <Col>
                        <Popconfirm
                          title="Are you sure to delete this task?"
                          onConfirm={handleDelete(rowData?.id)}
                          okText="Delete"
                          cancelText="Cancel"
                        >
                          <Tooltip title="Delete Number">
                            <Button danger type="primary" icon={<UserDeleteOutlined />} size="large" shape="circle" />
                          </Tooltip>
                        </Popconfirm>
                      </Col>
                    </Row>
                  ),
                },
              ];
              const visibleItems = items.slice(0, visibleFavorite);

              return (
                <React.Fragment key={rowData?.id}>
                  <Collapse
                    expandIcon={({ isActive }) => (
                      <CaretDownOutlined rotate={isActive ? 180 : 0} style={{ paddingTop: "12px" }} />
                    )}
                    expandIconPosition="end"
                    ghost
                    items={visibleItems}
                  />
                  <Divider style={{ margin: 0 }} />
                </React.Fragment>
              );
            })
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={"No Favorite"} />
          )}

          {loading && (
            <Card className="loading" style={{ textAlign: "center", padding: "10px" }} bordered={false}>
              <Spin />
            </Card>
          )}
        </Card>
      )}
    </Space>
  );
};

export default Favorite;
