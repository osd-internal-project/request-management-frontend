import { Avatar, Col, Row, Button, Input, Card, notification } from "antd";

import { useMultiState } from "../../lib/hook";

import { useRecentCallList } from "../../context/recent-calllist-context";
import { PhoneOutlined, UserOutlined } from "@ant-design/icons";
import { showNotification } from "../../lib/notification-handler";

import { AddContactToStore, checkDuplicateContact } from "../../lib/transaction-handler";
import  useExternalDatabase  from "../../context/update-data-transaction-context";

const AddContact = ({ setIsAddContact }: any) => {
  const [contactsData, setContactsData] = useMultiState({ displayName: "", number: "", favorite: Boolean });
  const { recentCallList, fetch, setFetch } = useRecentCallList();

  const callData = useExternalDatabase();
  const stringToColor = (string: string) => {
    let hash = 0;
    let i;
    for (i = 0; i < string.length; i += 1) {
      hash = string.charCodeAt(i) + ((hash << 5) - hash);
    }
    let color = "#";
    for (i = 0; i < 3; i += 1) {
      const value = (hash >> (i * 8)) & 0xff;
      color += `00${value.toString(16)}`.substr(-2);
    }
    return color;
  };
  const stringAvatar = (name: string) => {
    return {
      style: {
        backgroundColor: stringToColor(name),
      },
      children: `${name?.split(" ")[0][0]}`,
    };
  };
  const handleCancel = () => {
    setContactsData({ displayName: "", number: "" });
    setIsAddContact(false);
  };

  const handleAddContact = async (e: any) => {
    e.preventDefault();

    if (!contactsData?.displayName) {
      showNotification("warning", "Please enter your name.");
    } else if (!contactsData?.number) {
      showNotification("warning", "Please enter your phone number.");
    } else {
      try {
        const isDuplicate = await checkDuplicateContact(recentCallList, contactsData.number);
        if (isDuplicate) {
          showNotification("warning", "This contact already exists.");
          return;
        }
        await AddContactToStore(recentCallList, contactsData, callData);
        setFetch(true);
        showNotification("success", "Added successfully.");
        setContactsData({ displayName: "", number: "" });
        setIsAddContact(false);
      } catch (error) {
        console.error("Error in handleAddContact:", error);
        showNotification("error", "An error occurred while adding contact");
      }
    }
  };

  const handleKeyPress = (event: any) => {
    const charCode = event.which ? event.which : event.keyCode;
    if (!(charCode >= 48 && charCode <= 57) && charCode !== 42 && charCode !== 35) {
      event.preventDefault();
    }
  };

  // console.log("contactsData", fetch);
  return (
    <Card title="Add Contact" bordered={false} style={{ height: "100%", width: "100%" }}>
      <Row gutter={[16, 24]} align="middle" justify="center">
        <Avatar
          size={{ xs: 32, sm: 40, md: 64, lg: 80, xl: 100, xxl: 100 }}
          {...stringAvatar(`${contactsData?.displayName ? contactsData?.displayName : "."}`)}
        ></Avatar>
        <Col span={24}>
          <Row gutter={[16, 24]} align="middle" justify="center" style={{ marginBottom: "8px" }}>
            <Col span={12}>
              <Input
                prefix={<UserOutlined />}
                value={contactsData?.displayName ? contactsData?.displayName : ""}
                onChange={(e) => {
                  setContactsData({ displayName: e?.target?.value });
                }}
              />
            </Col>
          </Row>
          <Row gutter={[16, 24]} align="middle" justify="center">
            <Col span={12}>
              <Input
                prefix={<PhoneOutlined />}
                value={contactsData?.number || ""}
                onChange={(e) => {
                  setContactsData({ number: e?.target?.value });
                }}
                onKeyPress={handleKeyPress}
              />
            </Col>
          </Row>
          <Row gutter={[16, 24]} align="middle" justify="center" style={{ marginTop: "16px" }}>
            <Col style={{ display: "flex", justifyContent: "center" }} span={24}>
              <Button type="primary" onClick={handleAddContact}>
                Add Contact
              </Button>
              <Button onClick={handleCancel} htmlType="reset" style={{ margin: "0 8px" }}>
                Cancel
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
    </Card>
  );
};
export default AddContact;
