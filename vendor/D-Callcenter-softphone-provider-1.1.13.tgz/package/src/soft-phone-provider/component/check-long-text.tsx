import React from "react";
import { Tooltip, Typography } from "antd";

const { Text } = Typography;

interface CheckLongTextProps {
  text?: string | undefined;
  maxWidth?: number;
  maxLength?: number;
}

const CheckLongText: React.FC<CheckLongTextProps> = ({ text="", maxWidth = 200, maxLength = 20 }) => {
  const isLongText = text.length > maxLength;
  const truncatedText = isLongText ? `${text.slice(0, maxLength)}...` : text;

  return (
    <Tooltip title={isLongText ? text : ""}>
      <Text
        style={{
          maxWidth,
          display: "inline-block",
          overflow: "hidden",
          whiteSpace: "nowrap",
          textOverflow: "ellipsis",
        }}
      >
        {truncatedText}
      </Text>
    </Tooltip>
  );
};

export default CheckLongText;
