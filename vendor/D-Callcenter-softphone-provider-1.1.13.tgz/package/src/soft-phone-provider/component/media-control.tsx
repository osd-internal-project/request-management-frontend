import { Select, Slider, Tooltip, Typography, Space, Button, Popover, Spin } from "antd";
import { useState, useEffect, useRef } from "react";
import { useSimpleUser } from "../../context/simple-user-context";
import { getVideo } from "./media";
import { ControlFilled } from "@ant-design/icons";
import micManager from "../../lib/mic-manager";
import { CallMonitor } from "../../lib/call-monitor";

const { Text } = Typography;
const { Option } = Select;

/**
 * `MediaControl` is a wrapper component that displays a settings popover for managing audio input and output.
 * It contains the `SpeakerControl` and `MicrophoneControl` components.
 *
 * @component
 * @returns {JSX.Element} A button with a popover for media settings.
 *
 * @remarks
 * - Uses Ant Design's `Popover` for dropdown display.
 * - Toggles visibility via internal `open` state.
 */
export const MediaControl = (): JSX.Element => {
  const [open, setOpen] = useState(false);

  /**
   * Toggles the visibility of the media settings popover.
   */
  const toggleOpen = () => setOpen(!open);

  const content = (
    <Space direction="vertical" size="small" style={{ width: 220 }}>
      <SpeakerControl />
      <MicrophoneControl />
    </Space>
  );

  return (
    <>
      <Popover
        content={content}
        title="Media"
        trigger="click"
        open={open}
        onOpenChange={toggleOpen}
        placement="bottomRight"
      >
        <Tooltip title="Media Settings">
          <Button type="text" icon={<ControlFilled />} />
        </Tooltip>
      </Popover>
      <MediaMonitor />
    </>
  );
};

/**
 * `MicrophoneControl` allows users to:
 * - Select a microphone device (audio input).
 * - Adjust microphone gain (input volume).
 * - Apply microphone settings to the SIP.js `SimpleUser` media stream.
 *
 * @component
 * @returns {JSX.Element} UI for selecting input device and adjusting gain.
 *
 * @remarks
 * - Requires microphone permissions.
 * - Applies gain using Web Audio API.
 * - Calls `replaceTrack` on the active SIP session.
 */
export const MicrophoneControl = (): JSX.Element => {
  const [audioInputDevices, setAudioInputDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedInputDevice, setSelectedInputDevice] = useState<string>("default");
  const [micGain, setMicGain] = useState<number>(1);
  const { simpleUser } = useSimpleUser();

  /**
   * Fetch and list available audio input devices.
   */
  useEffect(() => {
    const initDevices = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        const devices = await navigator.mediaDevices.enumerateDevices();
        setAudioInputDevices(devices.filter((d) => d.kind === "audioinput"));
      } catch (err) {
        console.warn("Permission denied or error fetching devices:", err);
      }
    };
    initDevices();
  }, []);

  /**
   * Applies microphone gain to the audio stream using the Web Audio API.
   *
   * @param stream - The raw input MediaStream from the microphone.
   * @param micGain - Gain multiplier to apply to the audio (e.g., 1 = normal volume).
   * @param constraints - The media track constraints to associate with the output track.
   * @returns A new MediaStream with applied gain, or `null` if processing fails.
   */
  const applyMicGain = (
    stream: MediaStream,
    micGain: number,
    constraints: MediaTrackConstraints
  ): MediaStream | null => {
    try {
      const audioContext = new AudioContext();
      const source = audioContext.createMediaStreamSource(stream);
      const gainNode = audioContext.createGain();
      gainNode.gain.value = micGain;

      const destination = audioContext.createMediaStreamDestination();
      source.connect(gainNode);
      gainNode.connect(destination);

      const track = destination.stream.getAudioTracks()[0];

      if (track && constraints) {
        track.getConstraints = () => constraints;
      }

      micManager.setMicResources(stream, audioContext);
      return destination.stream;
    } catch (error) {
      console.warn("⚠️ Web Audio API failed or not supported", error);
      return null;
    }
  };

  /**
   * Apply the selected microphone and gain setting to the active media stream.
   */
  useEffect(() => {
    /**
     * Applies selected microphone input and gain settings to the SIP media stream.
     *
     * @param selectedInputDevice - Device ID of selected microphone or "default".
     * @param micGain - Gain multiplier (1 = normal).
     * @param simpleUser - The SIP.js SimpleUser instance.
     */
    const applyMicrophone = async (selectedInputDevice: string, micGain: number, simpleUser: any): Promise<void> => {
      try {
        const sender = simpleUser?.session?.sessionDescriptionHandler?.peerConnection
          ?.getSenders()
          .find((s: RTCRtpSender) => s.track?.kind === "audio");
        const oldConstraints = sender.track?.getConstraints?.() || {};
        const audioConstraints: MediaTrackConstraints = {
          ...oldConstraints,
        };

        if (selectedInputDevice !== "default") {
          audioConstraints.deviceId = { exact: selectedInputDevice };
        }
        const stream = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints });
        const processedStream = applyMicGain(stream, micGain, audioConstraints) || stream;
        const processedAudioTrack = processedStream.getAudioTracks()[0];

        if (sender?.track && typeof sender.track.stop === "function") {
          sender.track.stop();
        }

        if (sender && processedAudioTrack) {
          await sender.replaceTrack(processedAudioTrack);
        }

        simpleUser?.delegate?.onCallStream?.(processedStream);
      } catch (err) {
        console.error("❌ Failed to set microphone:", err);
      }
    };
    applyMicrophone(selectedInputDevice, micGain, simpleUser);
  }, [selectedInputDevice, micGain, simpleUser]);

  return (
    <Space direction="vertical" size="small" style={{ width: "100%" }}>
      <Text style={{ fontSize: 12 }} strong>
        Input Device
      </Text>
      <Select size="small" value={selectedInputDevice} onChange={setSelectedInputDevice} style={{ width: "100%" }}>
        {!audioInputDevices.some((d) => d.deviceId === "default") && (
          <Option key="default" value="default">
            Default Input
          </Option>
        )}
        {audioInputDevices.map((d) => (
          <Option key={d.deviceId} value={d.deviceId}>
            {d.label || `Input (${d.deviceId.slice(0, 6)}...)`}
          </Option>
        ))}
      </Select>

      <Text style={{ fontSize: 12 }} strong>
        Input Volume
      </Text>
      <Slider
        min={0}
        max={2}
        step={0.01}
        value={micGain}
        onChange={setMicGain}
        marks={{
          0: "0%",
          1: "100%",
          1.5: "Boost",
          2: "200%",
        }}
        tooltip={{ formatter: (val) => `${Math.round((val as number) * 100)}%` }}
      />

      <Text type="secondary" style={{ fontSize: 11 }}>
        Adjust mic input volume (100% = normal, anything above is boosted)
      </Text>
    </Space>
  );
};

declare global {
  interface HTMLMediaElement {
    /**
     * Sets the audio output device (sink) for the media element.
     *
     * @param sinkId - The ID of the audio output device (e.g., "default" or a specific device ID).
     * @returns A promise that resolves when the sink is successfully set.
     *
     * @remarks
     * - This method is only supported in certain browsers such as **Chrome**, **Edge**, and **Opera**.
     * - It is **not supported** in **Firefox** and **Safari** as of current browser versions.
     * - Always check for the existence of `setSinkId` before calling it to avoid runtime errors.
     *
     * @example
     * ```ts
     * if (typeof audioElement.setSinkId === "function") {
     *   await audioElement.setSinkId("default");
     * }
     * ```
     */
    setSinkId(sinkId: string): Promise<void>;
  }
}

/**
 * `SpeakerControl` allows users to:
 * - Select an audio output device (e.g., speaker).
 * - Adjust output volume for media elements.
 *
 * @component
 * @returns {JSX.Element} UI for selecting output device and adjusting volume.
 *
 * @remarks
 * - Applies selected output device using `setSinkId` on media elements.
 * - Targets elements returned by `getVideo("remote_audio_softphone")` and `getVideo("remote_video_softphone")`.
 */
export const SpeakerControl = (): JSX.Element => {
  const [volume, setVolume] = useState(1);
  const [audioOutputDevices, setAudioOutputDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedOutputDevice, setSelectedOutputDevice] = useState<string>("default");

  useEffect(() => {
    const initDevices = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        const devices = await navigator.mediaDevices.enumerateDevices();
        setAudioOutputDevices(devices.filter((d) => d.kind === "audiooutput"));
      } catch (err) {
        console.warn("Permission denied or error fetching devices:", err);
      }
    };
    initDevices();
  }, []);

  useEffect(() => {
    const applyVolumeAndSink = async () => {
      const elements = await Promise.all([getVideo("remote_audio_softphone"), getVideo("remote_video_softphone")]);

      elements.forEach((ele) => {
        const mediaElement = ele as HTMLMediaElement;
        if (mediaElement) {
          mediaElement.volume = volume;
          if (typeof mediaElement.setSinkId === "function") {
            mediaElement.setSinkId(selectedOutputDevice).catch((err) => console.warn(`⚠️ Failed to set sinkId:`, err));
          }
        }
      });
    };

    applyVolumeAndSink();
  }, [volume, selectedOutputDevice]);

  return (
    <Space direction="vertical" size="small" style={{ width: "100%" }}>
      <Text style={{ fontSize: 12 }} strong>
        Output Device
      </Text>
      <Select size="small" value={selectedOutputDevice} onChange={setSelectedOutputDevice} style={{ width: "100%" }}>
        {!audioOutputDevices.some((d) => d.deviceId === "default") && (
          <Option key="default" value="default">
            Default Output
          </Option>
        )}
        {audioOutputDevices.map((d) => (
          <Option key={d.deviceId} value={d.deviceId}>
            {d.label || `Output (${d.deviceId.slice(0, 6)}...)`}
          </Option>
        ))}
      </Select>
      <Text style={{ fontSize: 12 }} strong>
        Output Volume
      </Text>
      <Slider
        min={0}
        max={1}
        step={0.01}
        value={volume}
        onChange={setVolume}
        tooltip={{ formatter: (val) => `${Math.round((val as number) * 100)}%` }}
      />
    </Space>
  );
};

/**
 * `MediaMonitor` is a React component that displays a real-time signal strength indicator
 * based on the current Media Quality metrics of an ongoing SIP call.
 *
 * It uses a `CallMonitor` utility to observe metrics such as:
 * - Mean Opinion Score (MOS)
 * - Round Trip Time (RTT)
 * - Jitter
 * - Packet Loss
 *
 * These metrics are visualized with a colored signal bar UI and are also shown in a tooltip.
 *
 * @returns JSX.Element representing a signal strength button with tooltip info.
 */
export const MediaMonitor = (): JSX.Element => {
  const monitorRef = useRef<CallMonitor | null>(null);
  const { simpleUser } = useSimpleUser();

  const [mosData, setMosData] = useState({
    mos: 0,
    rtt: 0,
    jitter: 0,
    packetLoss: 0,
  });

  useEffect(() => {
    const peerConnection = simpleUser?.session?.sessionDescriptionHandler?.peerConnection;

    if (peerConnection) {
      // Start monitoring when PeerConnection is available
      monitorRef.current = new CallMonitor(peerConnection, (data) => {
        setMosData(data);
      });
    }

    // Cleanup on unmount or when peerConnection changes
    return () => {
      monitorRef.current?.stopMonitoring();
      monitorRef.current = null;
    };
  }, [simpleUser?.session?.sessionDescriptionHandler?.peerConnection]);

  const { mos, rtt, jitter, packetLoss } = mosData;

  const isLoading = mos === 0 && rtt === 0 && jitter === 0 && packetLoss === 0;

  /**
   * Tooltip content displaying detailed media metrics.
   */
  const tooltipText = `
MOS: ${mos.toFixed(2)}
RTT: ${(rtt * 1000).toFixed(2)} ms
Jitter: ${(jitter * 1000).toFixed(2)} ms
Packet Loss: ${(packetLoss * 100).toFixed(2)} %
  `;

  /**
   * Returns a color based on the MOS score.
   *
   * @param mos - Mean Opinion Score (1.0 to 5.0)
   * @returns A color string (green/yellow/red) representing quality
   */
  const getColor = (mos: number) => {
    if (mos >= 4) return "#52c41a"; // green
    if (mos >= 3) return "#faad14"; // yellow
    return "#ff4d4f"; // red
  };

  /**
   * Renders signal bars based on the MOS level.
   *
   * @param level - Signal level (1 to 4)
   * @param color - Bar color
   * @returns JSX for signal bars
   */
  const renderSignalBars = (level: number, color: string) => {
    const totalBars = 4;
    const bars = Array.from({ length: totalBars }, (_, i) => i + 1);

    return (
      <div style={{ display: "flex", gap: 2, alignItems: "end", height: 20 }}>
        {bars.map((barIndex) => {
          const fullHeight = barIndex * 4 + 4;
          const isFilled = level >= barIndex;
          const isPartial = level > barIndex - 1 && level < barIndex;
          const fillRatio = isPartial ? level - (barIndex - 1) : isFilled ? 1 : 0;
          const height = fullHeight * fillRatio;

          return (
            <div
              key={barIndex}
              style={{
                width: 4,
                height,
                backgroundColor: fillRatio > 0 ? color : "#d9d9d9",
                borderRadius: 1,
                transition: "all 0.3s ease-in-out",
              }}
            />
          );
        })}
      </div>
    );
  };

  const signalLevel = Math.max(1, Math.min(mos, 4));
  const color = getColor(mos);

  return (
    <Tooltip title={<pre>{tooltipText}</pre>}>
      <Button type="text" icon={isLoading ? <Spin size="small" /> : renderSignalBars(signalLevel, color)} />
    </Tooltip>
  );
};
