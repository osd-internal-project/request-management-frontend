import { notification, Space } from "antd";
import { useSimpleUser } from "../../context/simple-user-context";
import { usePhoneStatus } from "../../context/phone-status-context";
import { useContainerLayout } from "../../context/video-context";
import { useRecentCallList } from "../../context/recent-calllist-context";
import { v4 as uuidv4 } from "uuid";
import { Inviter, UserAgent } from "sip.js";
import useSoftPhoneUser from "../../context/soft-phone-user-context";
import Numpad from "./numpad";
import { useConferenceStatus } from "../../context/conference-status-context";
import { useInviterUser } from "../../context/inviter-user-context";
import { PhoneFilled, TeamOutlined } from "@ant-design/icons";
import { PhoneForwarded } from "react-feather";
import React from "react";
import useExternalDatabase from "../../context/update-data-transaction-context";
import { IncomingResponse } from "sip.js/lib/core";
import { showNotification } from "../../lib/notification-handler";
import { CallTransaction, hangupWhenError } from "../../lib/transaction-handler";
import { callToAnother, callToAnotherVideo, inviterOptions } from "../../lib/phone-call-handler";

const NumpadCall = ({
  isNumpadCallVisible,
  isCardVisible,
  isCardVisibleCallCreated,
  isCardPhoneConference,
  isCardPhoneConferenceShow,
  playCall,
  numpadValue,
  setNumpadValue,
  isCallTransfer,
}: any) => {
  const Auth = useSoftPhoneUser();
  const { simpleUser } = useSimpleUser();
  const { setPhoneStatus } = usePhoneStatus();
  const { recentCallList, setFetch, uuid, setUUID } = useRecentCallList();
  const { setVideoLayout, videoLayout } = useContainerLayout();
  const { conferenceStatus, setConferenceStatus } = useConferenceStatus();
  const { inviterUser } = useInviterUser();
  const [isTransferring, setIsTransferring] = React.useState(false);
  const callData = useExternalDatabase();
  const handleTransferClick = () => {
    setIsTransferring((prevState: any) => !prevState);
  };

  const onChange = (_value: any) => {
    setNumpadValue(_value);
  };
  const callConference = async () => {
    setVideoLayout(false);
    setConferenceStatus({ conference: true });
    if (isCardPhoneConference !== true) {
      isCardPhoneConferenceShow();
      playCall();
    }

    const target = UserAgent.makeURI(`sip:${numpadValue}@${Auth?.user?.ipServer}`);
    if (!target) {
      console.error("Invalid target URI");
      return;
    }
    const inviterInviteOptions = {
      requestDelegate: {
        onReject: async (response: IncomingResponse) => {
          await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
          setUUID(uuidv4());
          setFetch(true);
          if (response.message.statusCode === 486 && Auth?.user.notificationVisible?.isBusy) {
            console.warn(`[${numpadValue}] Call is busy`);
            showNotification("warning", `"${numpadValue}" is currently busy`);
          } else {
            console.warn(`[${numpadValue}] INVITE rejected`);
          }
          // notification.error({
          //   message: `"${numpadValue}" Missed your call.\n`,
          // });
        },
      },
    };

    const inviter = new Inviter(inviterUser?.userAgent, target, inviterOptions);

    inviterUser
      .sendInvite(inviter, inviterOptions, inviterInviteOptions)
      .then(async () => {
        await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
        setFetch(true);
        setNumpadValue("");
      })
      .catch(async (error: any) => {
        await hangupWhenError(error, numpadValue, uuid, "call", recentCallList, callData, setUUID, setFetch);
      });
  };
  const callVideoConference = async () => {
    setVideoLayout(true);
    setConferenceStatus({ conference: true });
    if (isCardPhoneConference !== true) {
      isCardPhoneConferenceShow();
      playCall();
    }

    const target = UserAgent.makeURI(`sip:${numpadValue}@${Auth?.user?.ipServer}`);
    if (!target) {
      console.error("Invalid target URI");
      return;
    }
    const inviterOptions = {
      sessionDescriptionHandlerOptions: {
        streams: new MediaStream(),
        constraints: {
          audio: true,
          video: true,
        },
      },
    };
    const inviterInviteOptions = {
      requestDelegate: {
        onReject: async (response: IncomingResponse) => {
          await CallTransaction(numpadValue, uuid, "videoMissed", recentCallList, callData);
          setUUID(uuidv4());
          setFetch(true);
          if (response.message.statusCode === 486 && Auth?.user.notificationVisible?.isBusy) {
            console.warn(`[${numpadValue}] Call is busy`);
            showNotification("warning", `"${numpadValue}" is currently busy`);
          } else {
            console.warn(`[${numpadValue}] INVITE rejected`);
          }
          // notification.error({
          //   message: `"${numpadValue}" Missed your video call.\n`,
          // });
        },
      },
    };

    const inviter = new Inviter(inviterUser?.userAgent, target, inviterOptions);

    inviterUser
      .sendInvite(inviter, inviterOptions, inviterInviteOptions)
      .then(async () => {
        await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
        setFetch(true);
        setNumpadValue("");
      })
      .catch(async (error: any) => {
        await hangupWhenError(error, numpadValue, uuid, "call", recentCallList, callData, setUUID, setFetch);
      });
  };
  const isCardPhoneConferencecallConference = async () => {
    setVideoLayout(false);
    setConferenceStatus({ conference: true });

    if (isCardPhoneConference !== true) {
      isCardPhoneConferenceShow();
      playCall();
    }

    const target = UserAgent.makeURI(`sip:${numpadValue}@${Auth?.user?.ipServer}`);
    const inviterInviteOptions = {
      // An example of how to get access to a SIP response message for custom handling
      requestDelegate: {
        onReject: async (response: IncomingResponse) => {
          await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
          setUUID(uuidv4());
          setFetch(true);
          if (response.message.statusCode === 486 && Auth?.user.notificationVisible?.isBusy) {
            console.warn(`[${numpadValue}] Call is busy`);
            showNotification("warning", `"${numpadValue}" is currently busy`);
          } else {
            console.warn(`[${numpadValue}] INVITE rejected`);
          }
          // notification.error({
          //   message: `"${numpadValue}" Missed your call.\n`,
          // });
        },
      },
    };
    const inviter = new Inviter(simpleUser?.userAgent, target!, inviterOptions);

    simpleUser
      .sendInvite(inviter, inviterOptions, inviterInviteOptions)
      .then(async () => {
        await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
        setFetch(true);
        setNumpadValue("");
      })
      .catch(async (error: any) => {
        await hangupWhenError(error, numpadValue, uuid, "call", recentCallList, callData, setUUID, setFetch);
      });
  };
  const isCardPhoneConferencecallVideoConference = async () => {
    setVideoLayout(true);
    setConferenceStatus({ conference: true });

    if (isCardPhoneConference !== true) {
      isCardPhoneConferenceShow();
      playCall();
    }

    const target = UserAgent.makeURI(`sip:${numpadValue}@${Auth?.user?.ipServer}`);
    const inviterOptions = {
      alwaysAcquireMediaFirst: true,
      earlyMedia: true,
      sessionDescriptionHandlerOptions: {
        streams: new MediaStream(),
        constraints: {
          audio: true,
          video: false,
        },
      },
    };
    const inviterInviteOptions = {
      // An example of how to get access to a SIP response message for custom handling
      requestDelegate: {
        onReject: async (response: IncomingResponse) => {
          await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
          setUUID(uuidv4());
          setFetch(true);
          if (response.message.statusCode === 486 && Auth?.user.notificationVisible?.isBusy) {
            console.warn(`[${numpadValue}] Call is busy`);
            showNotification("warning", `"${numpadValue}" is currently busy`);
          } else {
            console.warn(`[${numpadValue}] INVITE rejected`);
          }
          // notification.error({
          //   message: `"${numpadValue}" Missed your video call.\n`,
          // });
        },
      },
    };
    const inviter = new Inviter(simpleUser?.userAgent, target!, inviterOptions);

    simpleUser
      .sendInvite(inviter, inviterOptions, inviterInviteOptions)
      .then(async () => {
        await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
        setFetch(true);
        setNumpadValue("");
      })
      .catch(async (error: any) => {
        await hangupWhenError(error, numpadValue, uuid, "call", recentCallList, callData, setUUID, setFetch);
      });
  };

  const cardPhoneTransfer = async () => {
    try {
      const currentTarget = simpleUser?.session?.remoteIdentity?.uri?.normal?.user;
      const currentUser = Auth?.user?.username;

      if (numpadValue === currentTarget || numpadValue === currentUser) {
        notification.error({
          message: `"${numpadValue}" Unable to transfer the call.\n`,
        });
        setIsTransferring(false);
        return;
      }
      const options = {
        onNotify: (noti: { request: { body: string } }) => {
          const message = noti?.request?.body;
          if (/404 Not Found\r\n/.test(message)) {
            notification.error({
              message: `"${numpadValue}" Unable to transfer the call.\n`,
            });
            setIsTransferring(false);
            console.error("Transfer aborted due to 404 Not Found");
          }
        },
        requestDelegate: {
          onReject: (response: string) => {
            notification.error({
              message: `Call transfer is currently in progress. Please hold on.`,
            });
          },
        },
      };

      const target = await UserAgent?.makeURI(`sip:${numpadValue}@${Auth?.user?.ipServer}`);
      await simpleUser?.session?.refer(target, options);
      simpleUser.hangup();
    } catch (error) {
      console.error("Error in cardPhone handleTransfer:", error);
      notification.error({
        message: "An error occurred during cardPhone handleTransfer",
        description: `${error}`,
      });
    }
  };

  return isCardVisible || isCardVisibleCallCreated || isCardPhoneConference ? (
    isCardVisibleCallCreated ? (
      <Numpad
        onChange={onChange}
        callToAnotherVideo={callVideoConference}
        callToAnother={isCallTransfer ? cardPhoneTransfer : callConference}
        inputValue={numpadValue}
        setInputValue={setNumpadValue}
        iconphone={
          isCallTransfer ? (
            <Space onClick={handleTransferClick}>
              <PhoneForwarded size={20} style={{ marginTop: "3px" }} />
              {isTransferring ? "Transferring" : "Transfer"}
            </Space>
          ) : (
            <Space>
              <TeamOutlined size={20} />
              {inviterUser?.session ? "Conferencing" : "Conference"}
            </Space>
          )
        }
        iconphoneshape="round"
        titlephone={isCallTransfer ? "Transfer" : "Conference"}
        disabledphone={
          isCallTransfer
            ? !numpadValue
              ? true
              : false || isTransferring
              ? true
              : false
            : !numpadValue
            ? true
            : false && !videoLayout
            ? true
            : false || inviterUser?.session
            ? true
            : false
        }
      />
    ) : isCardVisible ? (
      <Numpad
        onChange={onChange}
        callToAnotherVideo={callVideoConference}
        callToAnother={isCallTransfer ? cardPhoneTransfer : callConference}
        inputValue={numpadValue}
        setInputValue={setNumpadValue}
        iconphone={
          isCallTransfer ? (
            <Space onClick={handleTransferClick}>
              <PhoneForwarded size={20} style={{ marginTop: "3px" }} />
              {isTransferring ? "Transferring" : "Transfer"}
            </Space>
          ) : (
            <Space>
              <TeamOutlined size={20} />
              {inviterUser?.session ? "Conferencing" : "Conference"}
            </Space>
          )
        }
        iconphoneshape="round"
        titlephone={isCallTransfer ? "Transfer" : "Conference"}
        disabledphone={
          isCallTransfer
            ? !numpadValue
              ? true
              : false || isTransferring
              ? true
              : false
            : !numpadValue
            ? true
            : false && !videoLayout
            ? true
            : false || conferenceStatus?.conference
            ? true
            : false
        }
      />
    ) : (
      <Numpad
        onChange={onChange}
        callToAnotherVideo={isCardPhoneConferencecallVideoConference}
        callToAnother={isCallTransfer ? cardPhoneTransfer : isCardPhoneConferencecallConference}
        inputValue={numpadValue}
        setInputValue={setNumpadValue}
        iconphone={
          isCallTransfer ? (
            <Space>
              <PhoneForwarded size={20} style={{ marginTop: "3px" }} />
              Transfer
            </Space>
          ) : (
            <Space>
              <TeamOutlined size={20} />
              Conference
            </Space>
          )
        }
        iconphoneshape="round"
        titlephone={isCallTransfer ? "Transfer" : "Conference"}
        disabledphone={
          isCallTransfer
            ? !numpadValue
              ? true
              : false || simpleUser?.session
              ? true
              : false
            : !numpadValue
            ? true
            : false && !videoLayout
            ? true
            : false || simpleUser?.session
            ? true
            : false
        }
      />
    )
  ) : (
    isNumpadCallVisible && (
      <Numpad
        onChange={onChange}
        callToAnotherVideo={() =>
          callToAnotherVideo(
            setPhoneStatus,
            setVideoLayout,
            numpadValue,
            Auth,
            recentCallList,
            setFetch,
            uuid,
            setUUID,
            callData,
            simpleUser,
            setNumpadValue
          )
        }
        callToAnother={() =>
          callToAnother(
            setPhoneStatus,
            setVideoLayout,
            numpadValue,
            Auth,
            recentCallList,
            setFetch,
            uuid,
            setUUID,
            callData,
            simpleUser,
            setNumpadValue
          )
        }
        inputValue={numpadValue}
        setInputValue={setNumpadValue}
        iconphone={<PhoneFilled style={{ transform: "scaleX(-1)" }} />}
        iconphoneshape="circle"
        titlephone="Call"
        disabledphone={!numpadValue}
      />
    )
  );
};

export default NumpadCall;
