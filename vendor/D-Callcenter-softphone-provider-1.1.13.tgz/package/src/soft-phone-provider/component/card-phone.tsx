import React from "react";
import { useSimpleUser } from "../../context/simple-user-context";
import { Avatar, Button, Col, Row, Tooltip, Typography, notification } from "antd";
import { PhoneForwarded } from "react-feather";
import { useRecentCallList } from "../../context/recent-calllist-context";
import { useContainerLayout } from "../../context/video-context";
import {
  AudioFilled,
  AudioMutedOutlined,
  PauseOutlined,
  PhoneFilled,
  PlayCircleOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { usePhoneStatus } from "../../context/phone-status-context";
import { GetDisplayName } from "../../lib/get-display-name";

import CheckLongText from "./check-long-text";
import { handleAnswer, handleHangUp, handleMute, handleUnMute, handleHold, handleUnHold, handleDecline } from "../../lib/phone-call-handler";
import { CardPhoneTypes } from "../../lib/transaction-data-type";
import  useExternalDatabase  from "../../context/update-data-transaction-context";

const CardPhone: React.FC<CardPhoneTypes> = ({
  resultContact,
  isCardVisible,
  handleCancel,
  setTimeStatus,
  timeStatus,
  setSecondsRemaining,
  secondsRemaining,
  setIsCallConference,
  isCallConference,
  setIsCallTransfer,
  isCallTransfer,
}) => {
  const STATUS = {
    STARTED: "Started",
    STOPPED: "Stopped",
  };
  const { Text } = Typography;

  const INITIAL_COUNT = 0;
  const { simpleUser } = useSimpleUser();
  const { videoLayout } = useContainerLayout();
  const remoteUser = simpleUser?.session?.remoteIdentity?.uri?.user;
  const displayName = GetDisplayName(resultContact || [], remoteUser);

  const secondsToDisplay = secondsRemaining % 60;
  const minutesRemaining = (secondsRemaining - secondsToDisplay) / 60;
  const minutesToDisplay = minutesRemaining % 60;
  const hoursToDisplay = (minutesRemaining - minutesToDisplay) / 60;
  const { recentCallList, setFetch, uuid } = useRecentCallList();
  const { phoneStatus, setPhoneStatus } = usePhoneStatus();
  const callData = useExternalDatabase();

  const handleReset = () => {
    setTimeStatus(STATUS.STOPPED);
    setSecondsRemaining(INITIAL_COUNT);
    setIsCallConference(false);
    setIsCallTransfer(false);
  };

  // Updated handlers
  const handleAnswerClick = async () => {
    await handleAnswer(simpleUser, recentCallList, uuid, setPhoneStatus, setFetch, callData);
    // Additional logic if needed
    setTimeStatus(STATUS.STARTED);
  };

  const handleHangUpClick = async () => {
    await handleHangUp(simpleUser, handleCancel, handleReset, callData);
  };

  const handleMuteClick = async () => {
    await handleMute(simpleUser, setPhoneStatus);
  };

  const handleUnMuteClick = async () => {
    await handleUnMute(simpleUser, setPhoneStatus);
  };

  const handleHoldClick = async () => {
    await handleHold(simpleUser);
  };

  const handleUnHoldClick = async () => {
    await handleUnHold(simpleUser);
  };

  const handleDeclineClick = async () => {
    await handleDecline(simpleUser, recentCallList, uuid, handleCancel, setPhoneStatus, handleReset, callData);
  };

  const handleTransferClick = () => {
    setIsCallConference(false);
    setIsCallTransfer(prevState => !prevState);
  };

  const handleCallConferenceClick = () => {
    setIsCallTransfer(false);
    setIsCallConference(prevState => !prevState);
  };

  const useInterval = (callback: any, delay: any) => {
    const savedCallback = React.useRef<() => void>();

    React.useEffect(() => {
      savedCallback.current = callback;
    }, [callback]);

    React.useEffect(() => {
      const tick = () => {
        if (savedCallback.current) {
          savedCallback.current();
        }
      };
      if (delay !== null) {
        const id = setInterval(tick, delay);
        return () => clearInterval(id);
      }
      return undefined;
    }, [delay]);
  };

  const twoDigits = (num: number) => String(num).padStart(2, "0");
  useInterval(
    () => {
      if (secondsRemaining >= 0) {
        setSecondsRemaining(secondsRemaining + 1);
      } else {
        setTimeStatus(STATUS.STOPPED);
      }
    },
    timeStatus === STATUS.STARTED ? 1000 : null
  );

  return isCardVisible ? (
    <>
      <Row style={{ marginBottom: "10px" }}>
        <Col span={5}>
          <Avatar size="large" icon={<UserOutlined />} />
        </Col>
        {phoneStatus?.answer === false ? (
          <>
            <Col span={11}>
              <Text type="success" style={{ display: "flex" }}>
                Incoming call from
              </Text>
              <Text strong>{<CheckLongText text={displayName} maxWidth={100} maxLength={20} />}</Text>
              <div>
                {twoDigits(hoursToDisplay)}:{twoDigits(minutesToDisplay)}:{twoDigits(secondsToDisplay)}
              </div>
            </Col>
            <>
              <Col span={5} style={{ alignContent: "center", justifyContent: "center" }}>
                <Tooltip title="Accept">
                  <Button shape="circle" type="primary" onClick={handleAnswerClick} icon={<PhoneFilled />} size="large" />
                </Tooltip>
              </Col>
              <Col span={3} style={{ alignContent: "center", justifyContent: "center" }}>
                <Tooltip title="Decline">
                  <Button
                    shape="circle"
                    type="primary"
                    danger
                    onClick={handleDeclineClick}
                    icon={<PhoneFilled rotate={225} />}
                    size="large"
                  />
                </Tooltip>
              </Col>
            </>
          </>
        ) : (
          <>
            <Col span={14}>
              <Text strong>{<CheckLongText text={displayName} maxWidth={100} maxLength={20} />}</Text>
              <div>
                <Text type="success">Talking</Text>
              </div>
              <div>
                {twoDigits(hoursToDisplay)}:{twoDigits(minutesToDisplay)}:{twoDigits(secondsToDisplay)}
              </div>
            </Col>
            <Col span={5} style={{ alignContent: "center", justifyContent: "center" }}>
              <Tooltip title="Hang Up">
                <Button
                  shape="circle"
                  type="primary"
                  danger
                  onClick={handleHangUpClick}
                  icon={<PhoneFilled rotate={225} />}
                  size="large"
                />
              </Tooltip>
            </Col>
          </>
        )}
      </Row>
      <Row style={{ marginBottom: "10px" }}>
        {phoneStatus?.answer !== false ? (
          <>
            <Col span={5} offset={4}>
              <Tooltip title={!phoneStatus?.mute ? "Mute" : "Unmute"}>
                <Button
                  shape="circle"
                  onClick={() => {
                    if (!phoneStatus?.mute) {
                      handleMuteClick();
                    } else {
                      handleUnMuteClick();
                    }
                  }}
                  icon={!phoneStatus?.mute ? <AudioFilled /> : <AudioMutedOutlined />}
                  danger={phoneStatus?.mute}
                  type="primary"
                  size="large"
                />
              </Tooltip>
            </Col>

            <Col span={5}>
              {!simpleUser?.isHeld() ? (
                <Tooltip title="Hold">
                  <Button type="primary" shape="circle" icon={<PauseOutlined />} onClick={handleHoldClick} size="large" />
                </Tooltip>
              ) : (
                <Tooltip title="Unhold">
                  <Button
                    type="primary"
                    shape="circle"
                    icon={<PlayCircleOutlined />}
                    onClick={handleUnHoldClick}
                    size="large"
                  />
                </Tooltip>
              )}
            </Col>

            <Col span={5}>
              <Tooltip title="Transfer">
                <Button
                  shape="circle"
                  type={isCallTransfer ? "default" : "primary"}
                  onClick={handleTransferClick}
                  icon={<PhoneForwarded size={20} style={{ marginTop: "3px" }} />}
                  size="large"
                />
              </Tooltip>
            </Col>

            <Col span={5} style={{ display: videoLayout ? "none" : "flex" }}>
              <Tooltip title="Conference">
                <Button
                  type={isCallConference ? "default" : "primary"}
                  shape="circle"
                  onClick={handleCallConferenceClick}
                  icon={<TeamOutlined size={20} />}
                  size="large"
                />
              </Tooltip>
            </Col>
          </>
        ) : (
          <></>
        )}
      </Row>
    </>
  ) : (
    <></>
  );
};

export default CardPhone;
