import React from "react";
import {
  Avatar,
  List,
  Tooltip,
  Divider,
  Button,
  Row,
  Col,
  Typography,
  Spin,
  Card,
  Collapse,
  Popconfirm,
  Empty,
} from "antd";
import { VideoCameraFilled, PhoneFilled, DeleteOutlined, UserAddOutlined, CaretDownOutlined } from "@ant-design/icons";
import { PhoneOutgoing, PhoneIncoming, Video } from "react-feather";
import { useSimpleUser } from "../../context/simple-user-context";
import { useRecentCallList } from "../../context/recent-calllist-context";
import dayjs from "dayjs";

import { usePhoneStatus } from "../../context/phone-status-context";
import { useContainerLayout } from "../../context/video-context";
import { useInviterUser } from "../../context/inviter-user-context";
import useSoftPhoneUser from "../../context/soft-phone-user-context";
import localizedFormat from "dayjs/plugin/localizedFormat";
import isYesterday from "dayjs/plugin/isYesterday";
import EditContact from "./edit-contact";

import CheckLongText from "./check-long-text";

import { showNotification } from "../../lib/notification-handler";
import { DeleteFromStore } from "../../lib/transaction-handler";

import useExternalDatabase from "../../context/update-data-transaction-context";
import { callToAnother, callToAnotherVideo } from "../../lib/phone-call-handler";

import("dayjs/locale/th");

dayjs.extend(isYesterday);
dayjs.extend(localizedFormat);

interface ContactData {
  name?: {
    displayName: string;
    status: string;
    date: string;
  };
  id?: string;
}

type recentListItemProps = {
  row: any;
  index: number;
  expandedIndex: number | null;
  onExpandToggle: (index: number) => void;
  onVideoCall: (name: string) => void;
  onCall: (name: string) => void;
  session: boolean;
  title: string;
  contactData: ContactData[];
};
type recentListProps = {
  title: string;
  data: any[];
  expandedIndex: number | null;
  setExpandedIndex: (index: number) => void;
  onVideoCall: (name: string) => void;
  onCall: (name: string) => void;
  session: boolean;
};

const Recents = ({
  resultContact,
  result,
  isEditContact,
  setIsEditContact,
  currentContact,
  setCurrentContact,
}: any) => {
  const { setVideoLayout } = useContainerLayout();
  const { setPhoneStatus } = usePhoneStatus();
  const { recentCallList, setFetch, setUUID, uuid } = useRecentCallList();
  const Auth = useSoftPhoneUser();
  const { simpleUser } = useSimpleUser();
  const { inviterUser } = useInviterUser();
  const { Text } = Typography;
  const [expandedTodayIndex, setExpandedTodayIndex] = React.useState<number | null>(null);
  const [expandedYesterdayIndex, setExpandedYesterdayIndex] = React.useState<number | null>(null);
  const [expandedOlderIndex, setExpandedOlderIndex] = React.useState<number | null>(null);
  const [visibleToday, setVisibleToday] = React.useState(5);
  const [visibleYesterday, setVisibleYesterday] = React.useState(5);
  const [visibleOlder, setVisibleOlder] = React.useState(5);
  const [loading, setLoading] = React.useState(false);
  const session = simpleUser?.session ? true : false || inviterUser?.session ? true : false;
  // const { callToReceive } = useCallToReceive();
  const callData = useExternalDatabase();

  const handleExpandToggle = (setExpandedIndex: React.Dispatch<React.SetStateAction<number | null>>, index: number) => {
    setExpandedIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  const showIcon = (status: any) => {
    switch (status) {
      case "call":
        return [
          <PhoneOutgoing key="phone-out" size={20} style={{ color: "green" }} />,
          <Text key="phone-out-text" style={{ fontSize: "7px", color: "green" }}>
            Out
          </Text>,
        ];
      case "received":
        return [
          <PhoneIncoming key="phone-in" size={20} style={{ color: "green" }} />,
          <Text key="phone-in-text" style={{ fontSize: "7px", color: "green" }}>
            In
          </Text>,
        ];
      case "declined": {
        return [
          <PhoneIncoming key="phone-declined" size={20} style={{ color: "red" }} />,
          <Text key="phone-declined-text" style={{ fontSize: "7px", color: "red" }}>
            In
          </Text>,
        ];
      }
      case "missed":
        return [
          <PhoneOutgoing key="phone-out" size={20} style={{ color: "red" }} />,
          <Text key="phone-out-text" style={{ fontSize: "7px", color: "red" }}>
            Out
          </Text>,
        ];
      case "videoMissed":
        return [
          <Video key="video-missed" size={20} style={{ color: "red" }} />,
          <Text key="video-missed-text" style={{ fontSize: "7px", color: "red" }}>
            Missed
          </Text>,
        ];
      case "videoCall":
        return [
          <Video key="video-call" size={20} style={{ color: "green" }} />,
          <Text key="video-call-text" style={{ fontSize: "7px", color: "green" }}>
            Out
          </Text>,
        ];
      case "videoReceived ":
        return [
          <Video key="video-received" size={20} style={{ color: "green" }} />,
          <Text key="video-received-text" style={{ fontSize: "7px", color: "green" }}>
            In
          </Text>,
        ];
      case "videoDeclined":
        return [
          <Video key="video-declined" size={20} style={{ color: "red" }} />,
          <Text key="video-declined-text" style={{ fontSize: "7px", color: "red" }}>
            In
          </Text>,
        ];
      default:
        return null;
    }
  };

  const callToReceive = async (displayName: any) => {
    callToAnother(
      setPhoneStatus,
      setVideoLayout,
      displayName,
      Auth,
      recentCallList,
      setFetch,
      uuid,
      setUUID,
      callData,
      simpleUser
    );
  };

  const callToVideoReceive = async (displayName: any) => {
    callToAnotherVideo(
      setPhoneStatus,
      setVideoLayout,
      displayName,
      Auth,
      recentCallList,
      setFetch,
      uuid,
      setUUID,
      callData,
      simpleUser
    );
  };

  const stringToColor = (string: string) => {
    let hash = 0;
    let i;

    /* eslint-disable no-bitwise */
    for (i = 0; i < string.length; i += 1) {
      hash = string.charCodeAt(i) + ((hash << 5) - hash);
    }

    let color = "#";

    for (i = 0; i < 3; i += 1) {
      const value = (hash >> (i * 8)) & 0xff;
      color += `00${value.toString(16)}`.substr(-2);
    }
    /* eslint-enable no-bitwise */

    return color;
  };
  const stringAvatar = (name: string) => {
    return {
      style: {
        backgroundColor: stringToColor(name),
      },
      children: `${name?.split(" ")[0][0]}`,
    };
  };
  const loadMoreItems = () => {
    if (!result) return;

    const todayLength = todayData.length;
    const yesterdayLength = yesterdayData.length;
    const olderLength = olderData.length;

    const todayFull =
      todayLength >=
      result.filter((rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        dayjs().isSame(rowa?.name?.date, "day")
      ).length;
    const yesterdayFull =
      yesterdayLength >=
      result.filter((rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        dayjs(rowa?.name?.date).isYesterday()
      ).length;
    const olderFull =
      olderLength >=
      result.filter(
        (rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
          !dayjs().isSame(rowa?.name?.date, "day") && !dayjs(rowa?.name?.date).isYesterday()
      ).length;

    if (!todayFull) {
      setVisibleToday((prev) => prev + 3);
    } else if (!yesterdayFull) {
      setVisibleYesterday((prev) => prev + 3);
    } else if (!olderFull) {
      setVisibleOlder((prev) => prev + 3);
    }
  };

  const [recentCallDataFromExternalDB, setRecentCallDataFromExternalDB] = React.useState<any[] | null>(null);

  React.useEffect(() => {
    const fetchData = async () => {
      if (Auth?.user?.externalRecentCallListDatabase && callData?.callManager?.fetchExternalData) {
        const externalData = await callData.callManager.fetchExternalData();
        setRecentCallDataFromExternalDB(externalData);
      } else {
        setRecentCallDataFromExternalDB(result);
      }
    };
    fetchData();
  }, [result, Auth?.user?.externalRecentCallListDatabase, callData?.callManager]);

  const contactData = React.useMemo(() => {
    if (!resultContact) return [];
    return resultContact.flatMap((row: any) => row?.names?.map((rowData: any) => rowData) || []);
  }, [resultContact]);

  const todayData = React.useMemo(() => {
    const data = recentCallDataFromExternalDB || result;
    if (!data) return [];

    // Sort data by date first
    const sortedData = [...data].sort((a, b) => dayjs(b.name.date).valueOf() - dayjs(a.name.date).valueOf());

    const filteredData = sortedData.filter(
      (rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        dayjs().isSame(rowa?.name?.date, "day")
    );

    return filteredData.length > 0 ? filteredData.slice(0, visibleToday) : [];
  }, [recentCallDataFromExternalDB, result, visibleToday]);

  const yesterdayData = React.useMemo(() => {
    const data = recentCallDataFromExternalDB || result;
    if (!data) return [];

    // Sort data by date first
    const sortedData = [...data].sort((a, b) => dayjs(b.name.date).valueOf() - dayjs(a.name.date).valueOf());

    if (
      todayData.length <
      sortedData.filter((rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        dayjs().isSame(rowa?.name?.date, "day")
      ).length
    ) {
      return [];
    }

    const filteredData = sortedData.filter(
      (rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        dayjs(rowa?.name?.date).isYesterday()
    );

    return filteredData.length > 0 ? filteredData.slice(0, visibleYesterday) : [];
  }, [recentCallDataFromExternalDB, result, visibleYesterday, todayData]);

  const olderData = React.useMemo(() => {
    const data = recentCallDataFromExternalDB || result;
    if (!data) return [];

    // Sort data by date first
    const sortedData = [...data].sort((a, b) => dayjs(b.name.date).valueOf() - dayjs(a.name.date).valueOf());

    if (
      todayData.length <
      sortedData.filter((rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        dayjs().isSame(rowa?.name?.date, "day")
      ).length ||
      yesterdayData.length <
      sortedData.filter((rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        dayjs(rowa?.name?.date).isYesterday()
      ).length
    ) {
      return [];
    }

    const filteredData = sortedData.filter(
      (rowa: { name: { date: string | number | dayjs.Dayjs | Date | null | undefined } }) =>
        !dayjs().isSame(rowa?.name?.date, "day") && !dayjs(rowa?.name?.date).isYesterday()
    );

    return filteredData.length > 0 ? filteredData.slice(0, visibleOlder) : [];
  }, [recentCallDataFromExternalDB, result, visibleOlder, todayData, yesterdayData]);

  const handleScroll = (e: any) => {
    const { scrollTop, clientHeight, scrollHeight } = e.currentTarget;
    const todayFull = todayData.length >= result.filter((rowa: any) => dayjs().isSame(rowa?.name?.date, "day")).length;
    const yesterdayFull =
      yesterdayData.length >= result.filter((rowa: any) => dayjs(rowa?.name?.date).isYesterday()).length;
    const olderFull =
      olderData.length >=
      result.filter((rowa: any) => !dayjs().isSame(rowa?.name?.date, "day") && !dayjs(rowa?.name?.date).isYesterday())
        .length;
    if (scrollTop + clientHeight >= scrollHeight - 50 && !loading && (!todayFull || !yesterdayFull || !olderFull)) {
      setLoading(true);
      loadMoreItems();
      setTimeout(() => setLoading(false), 1000);
    }
  };
  React.useEffect(() => {
    const container = document.getElementById("scrollable-container");
    container?.addEventListener("scroll", handleScroll as EventListener);

    return () => container?.removeEventListener("scroll", handleScroll as EventListener);
  });

  const handleDelete = async (id: any) => {
    try {
      await DeleteFromStore(id, "RecentLists", recentCallList, callData);
      setFetch(true);
      showNotification("success", "Deleted successfully.");
    } catch (e) {
      console.error("Error", e);
      showNotification("error", "Failed to delete.", "An error occurred while deleting.");
    }
  };

  const RecentListItem: React.FC<recentListItemProps> = ({
    contactData,
    row,
    index,
    onVideoCall,
    onCall,
    session,
    title,
  }) => {
    let avatar = <Avatar {...stringAvatar(`${row?.name?.displayName}`)} size="large" />;
    let contactName = (
      <Row align="top" justify="space-between">
        <Col style={{}}>{row?.name?.displayName || row?.target}</Col>
        <Col>{showIcon(row?.name?.status)}</Col>
      </Row>
    );
    let buttonAddContact = (
      <Tooltip title="Add contact">
        <Button
          type="primary"
          shape="circle"
          onClick={() => {
            setIsEditContact(true);
            setCurrentContact(row);
          }}
          icon={<UserAddOutlined />}
          size="large"
        />
      </Tooltip>
    );
    contactData?.map((rowData: any) => {
      const displayName = rowData?.name?.displayName || "";

      if (row?.target === rowData?.name?.number) {
        avatar = <Avatar {...stringAvatar(`${rowData?.name?.displayName}`)} size="large" />;
        contactName = (
          <>
            <Row align="top" justify="space-between">
              <Col>{<CheckLongText text={displayName} maxLength={20} />}</Col>
              <Col>{showIcon(row?.name?.status)}</Col>
            </Row>
            <Row align="top">
              <Col>
                <Text type="secondary">{rowData?.name?.number}</Text>
              </Col>
            </Row>
          </>
        );
        buttonAddContact = (
          <Tooltip title="Already have a contact">
            <Button
              type="primary"
              shape="circle"
              onClick={() => {
                setIsEditContact(true);
                setCurrentContact(row);
              }}
              icon={<UserAddOutlined />}
              size="large"
              disabled
            />
          </Tooltip>
        );
      }
    });

    const items = [
      {
        key: `${title}-${index}`,
        label: (
          <List.Item key={`${title}-${index}`}>
            <List.Item.Meta
              style={{ marginBlockEnd: "0px" }}
              avatar={avatar}
              title={contactName}
              description={dayjs(`${row?.name?.date}`).locale("th").format("dddd, HH:mm")}
            />
          </List.Item>
        ),
        children: (
          <Row align="middle" justify="space-around">
            <Col>
              <Tooltip title="Video Call">
                <Button
                  type="primary"
                  onClick={() => onVideoCall(row?.name?.displayName)}
                  shape="circle"
                  icon={<VideoCameraFilled />}
                  size="large"
                  disabled={session}
                />
              </Tooltip>
            </Col>
            <Col>
              <Tooltip title="Call">
                <Button
                  type="primary"
                  shape="circle"
                  onClick={() => onCall(row?.name?.displayName)}
                  icon={<PhoneFilled />}
                  size="large"
                  disabled={session}
                />
              </Tooltip>
            </Col>
            <Col>{buttonAddContact}</Col>
            <Col>
              <Popconfirm
                title="Are you sure to delete this task?"
                onConfirm={() => {
                  handleDelete(row?.id);
                }}
                okText="Delete"
                cancelText="Cancel"
              >
                <Tooltip title="Delete Number">
                  <Button danger type="primary" icon={<DeleteOutlined />} size="large" shape="circle" />
                </Tooltip>
              </Popconfirm>
            </Col>
          </Row>
        ),
      },
    ];

    return (
      <React.Fragment>
        <Collapse
          expandIcon={({ isActive }) => (
            <CaretDownOutlined rotate={isActive ? 180 : 0} style={{ paddingTop: "12px" }} />
          )}
          expandIconPosition="end"
          ghost
          items={items}
          size="small"
        />
        <Divider style={{ margin: 0 }} />
      </React.Fragment>
    );
  };

  const RecentList: React.FC<recentListProps> = ({
    title,
    data,
    expandedIndex,
    setExpandedIndex,
    onVideoCall,
    onCall,
    session,
  }) => (
    <>
      {data.length > 0 && (
        <React.Fragment>
          <Divider orientation="left" style={{ fontSize: "14px", opacity: 0.6 }}>
            {title}
          </Divider>
          <List
            itemLayout="vertical"
            dataSource={data}
            renderItem={(row, index) => (
              <RecentListItem
                contactData={contactData}
                row={row}
                index={index}
                expandedIndex={expandedIndex}
                onExpandToggle={(index) => setExpandedIndex(index)}
                onVideoCall={onVideoCall}
                onCall={onCall}
                session={session}
                title={title}
              />
            )}
          />
        </React.Fragment>
      )}
    </>
  );

  return (
    <React.Fragment>
      {isEditContact ? (
        <EditContact setIsEditContact={setIsEditContact} contact={currentContact} />
      ) : (
        <Card
          style={{
            maxHeight: "35vh",
            overflowY: "auto",
            scrollbarWidth: "none",
            msOverflowStyle: "none",
          }}
          onScroll={handleScroll}
          size="small"
        >
          {recentCallDataFromExternalDB && recentCallDataFromExternalDB.length > 0 ? (
            <>
              <RecentList
                title="Today"
                data={todayData}
                expandedIndex={expandedTodayIndex}
                setExpandedIndex={(index) => handleExpandToggle(setExpandedTodayIndex, index)}
                onVideoCall={callToVideoReceive}
                onCall={callToReceive}
                session={session}
              />
              {todayData.length >=
                (recentCallDataFromExternalDB
                  ? recentCallDataFromExternalDB.filter((rowa: any) => dayjs().isSame(rowa?.name?.date, "day")).length
                  : 0) && (
                  <RecentList
                    title="Yesterday"
                    data={yesterdayData}
                    expandedIndex={expandedYesterdayIndex}
                    setExpandedIndex={(index) => handleExpandToggle(setExpandedYesterdayIndex, index)}
                    onVideoCall={callToVideoReceive}
                    onCall={callToReceive}
                    session={session}
                  />
                )}
              {todayData.length >=
                (recentCallDataFromExternalDB
                  ? recentCallDataFromExternalDB.filter((rowa: any) => dayjs().isSame(rowa?.name?.date, "day")).length
                  : 0) &&
                yesterdayData.length >=
                (recentCallDataFromExternalDB
                  ? recentCallDataFromExternalDB.filter((rowa: any) => dayjs(rowa?.name?.date).isYesterday()).length
                  : 0) && (
                  <RecentList
                    title="Older"
                    data={olderData}
                    expandedIndex={expandedOlderIndex}
                    setExpandedIndex={(index) => handleExpandToggle(setExpandedOlderIndex, index)}
                    onVideoCall={callToVideoReceive}
                    onCall={callToReceive}
                    session={session}
                  />
                )}
            </>
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={"No Recent"} />
          )}

          {loading ? (
            <Card className="loading" style={{ textAlign: "center", padding: "10px" }} bordered={false}>
              <Spin />
            </Card>
          ) : null}
        </Card>
      )}
    </React.Fragment>
  );
};
export default Recents;
