import { useSimpleUser } from "../../context/simple-user-context";
import { usePhoneStatus } from "../../context/phone-status-context";
import { useContainerLayout } from "../../context/video-context";
import { useRecentCallList } from "../../context/recent-calllist-context";
import Numpad from "./numpad";
import { PhoneFilled } from "@ant-design/icons";
import useSoftPhoneUser from "../../context/soft-phone-user-context";
import useExternalDatabase from "../../context/update-data-transaction-context";
import { callToAnother, callToAnotherVideo } from "../../lib/phone-call-handler";
const NumpadDetailBar = ({ numpadValue, setNumpadValue }: any) => {
  const Auth = useSoftPhoneUser();
  const { simpleUser } = useSimpleUser();
  const { phoneStatus, setPhoneStatus } = usePhoneStatus();
  const { recentCallList, setFetch, uuid, setUUID } = useRecentCallList();
  const { setVideoLayout } = useContainerLayout();

  const callData = useExternalDatabase();
  const onChange = (_value: any) => {
    setNumpadValue(_value);
  };

  return (
    <Numpad
      onChange={onChange}
      callToAnother={() =>
        callToAnother(
          setPhoneStatus,
          setVideoLayout,
          numpadValue,
          Auth,
          recentCallList,
          setFetch,
          uuid,
          setUUID,
          callData,
          simpleUser,
          setNumpadValue
        )
      }
      callToAnotherVideo={() =>
        callToAnotherVideo(
          setPhoneStatus,
          setVideoLayout,
          numpadValue,
          Auth,
          recentCallList,
          setFetch,
          uuid,
          setUUID,
          callData,
          simpleUser,
          setNumpadValue
        )
      }
      inputValue={numpadValue}
      setInputValue={setNumpadValue}
      iconphone={<PhoneFilled style={{ transform: "scaleX(-1)" }} />}
      iconphoneshape="circle"
      titlephone="Call"
      disabledphone={!numpadValue || phoneStatus.created || phoneStatus.answer || phoneStatus.conference}
    />
  );
};
export default NumpadDetailBar;
