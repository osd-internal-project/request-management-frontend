import React, { useEffect, useRef, useState } from "react";

import { notification } from "antd";

import RingtoneCall from "../../sound/sound-call.m4a";
import RingtoneReceive from "../../sound/sound-call.m4a";

import { useConferenceStatus } from "../../context/conference-status-context";
import { useDetailBar } from "../../context/detail-bar-context";
import { useInviterUser } from "../../context/inviter-user-context";
import { usePhoneStatus } from "../../context/phone-status-context";
import { useRecentCallList } from "../../context/recent-calllist-context";
import { useSimpleUser } from "../../context/simple-user-context";
import { useContainerLayout } from "../../context/video-context";
import useSoftPhoneUser from "../../context/soft-phone-user-context";

import { SetupUserAgent1, SetupUserSimple1, useInterval } from "../../lib/hook";

import { SessionState } from "sip.js";
import { v4 as uuidv4 } from "uuid";

import DetailBar from "./detail-bar";
import dayjs from "dayjs";
import useExternalDatabase from "../../context/update-data-transaction-context";
import { Howl } from "howler";
import micManager from "../../lib/mic-manager";

export type LayoutLandingTypes = {
  children: React.ReactNode;
};

let useEffectCallCount = 0;

export const LayoutLanding: React.FC<LayoutLandingTypes> = ({ children }) => {
  const STATUS = {
    STARTED: "Started",
    STOPPED: "Stopped",
  };
  const INITIAL_COUNT = 0;

  const [secondsRemaining, setSecondsRemaining] = React.useState(INITIAL_COUNT);
  const [secondsConferenceRemaining, setSecondsConferenceRemaining] = React.useState(INITIAL_COUNT);
  const [isCardVisible, setIsCardVisible] = React.useState(false);
  const [isCardPhoneConference, setIsCardPhoneConference] = React.useState(false);
  const [isCardVisibleCallCreated, setIsCardVisibleCallCreated] = React.useState(false);
  const [timeStatus, setTimeStatus] = React.useState(STATUS.STOPPED);
  const [timeConferenceStatus, setTimeConferenceStatus] = React.useState(STATUS.STOPPED);
  const [openDb, setOpenDb] = React.useState<any>(null);
  const [isCallAnswered, setIsCallAnswered] = React.useState(false);
  const [isCallConference, setIsCallConference] = React.useState<any>(false);
  const [isCallTransfer, setIsCallTransfer] = React.useState<any>(false);

  const { simpleUser, setSimpleUser } = useSimpleUser();
  const { videoLayout, setVideoLayout } = useContainerLayout();
  const { inviterUser, setInviterUser } = useInviterUser();
  const { phoneStatus, setPhoneStatus } = usePhoneStatus();
  const { conferenceStatus, setConferenceStatus } = useConferenceStatus();
  const { recentCallList, setRecentCallList, setFetch, setUUID, uuid, fetch } = useRecentCallList();
  const { isDetailBarVisible, setIsDetailBarVisible } = useDetailBar();

  const Auth = useSoftPhoneUser();
  var mediaElement = document.getElementById("remote_audio_softphone") as HTMLAudioElement;
  const remoteStream = new MediaStream();

  const [isSoundLoaded, setIsSoundLoaded] = useState(false);

  const callSoundRef = useRef<Howl | null>(null);
  const receiveSoundRef = useRef<Howl | null>(null);
  const timeoutIdRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const validateAudioUrl = (
      audioUrl: string | undefined,
      fallbackUrl: string | undefined,
      ref: React.MutableRefObject<Howl | null>,
      onLoad: () => void
    ) => {
      const audio = new Howl({
        loop: true,
        src: [audioUrl!],
        onloaderror: () => {
          console.warn(`Unable to load audio from ${audioUrl}. Using fallback.`);
          ref.current = new Howl({
            src: [fallbackUrl!],
            onload: () => onLoad(),
          });
        },
        onload: () => {
          ref.current = audio;
          onLoad(); // Mark sound as loaded when it's ready
        },
      });
    };

    let soundsLoaded = 0;

    const handleSoundLoaded = () => {
      soundsLoaded += 1;
      if (soundsLoaded === 2) {
        setIsSoundLoaded(true); // Mark as loaded when both sounds are ready
      }
    };

    const callUrl = Auth?.user?.ringtoneCallUrl || RingtoneCall;
    validateAudioUrl(callUrl, RingtoneCall, callSoundRef, handleSoundLoaded);

    const receiveUrl = Auth?.user?.ringtoneReceiveUrl || RingtoneReceive;
    validateAudioUrl(receiveUrl, RingtoneReceive, receiveSoundRef, handleSoundLoaded);
  }, [Auth?.user?.ringtoneCallUrl, Auth?.user?.ringtoneReceiveUrl]);

  const playCall = React.useCallback(() => {
    if (!isSoundLoaded) {
      console.warn("Sounds are not fully loaded yet.");
      return;
    }

    if (receiveSoundRef.current) {
      receiveSoundRef.current.stop(); // Stop the receive sound if it's playing
    }

    if (callSoundRef.current) {
      // Clear previous timeout if it exists
      if (timeoutIdRef.current) {
        clearTimeout(timeoutIdRef.current);
        timeoutIdRef.current = null;
      }

      // Set new timeout for playing call sound after 1 second
      timeoutIdRef.current = setTimeout(() => {
        callSoundRef.current?.play();
      }, 2000);
    }
  }, [isSoundLoaded]);

  const playReceive = React.useCallback(() => {
    if (!isSoundLoaded) {
      console.warn("Sounds are not fully loaded yet.");
      return;
    }

    // Clear the timeout for playCall to prevent it from playing
    if (timeoutIdRef.current) {
      clearTimeout(timeoutIdRef.current);
      timeoutIdRef.current = null;
    }

    if (callSoundRef.current) {
      callSoundRef.current.stop(); // Stop the call sound if it's playing
    }

    if (receiveSoundRef.current) {
      receiveSoundRef.current.play();
    }
  }, [isSoundLoaded]);

  const stop = React.useCallback(() => {
    // Clear the timeout if it exists to prevent the call sound from playing
    if (timeoutIdRef.current) {
      clearTimeout(timeoutIdRef.current);
      timeoutIdRef.current = null;
    }

    if (callSoundRef.current) {
      callSoundRef.current.stop();
    }

    if (receiveSoundRef.current) {
      receiveSoundRef.current.stop();
    }
  }, []);

  const indexedDB = window.indexedDB;

  const handleCancel = () => {
    setIsCardVisible(false);
  };
  const handleCancelCallCreated = () => {
    setIsCardVisibleCallCreated(false);
  };
  const showCard = () => {
    setIsCardVisible(true);
  };
  const callData = useExternalDatabase();

  React.useEffect(() => {
    const initializeDatabase = async () => {
      if (openDb && openDb.result.name !== `MyDatabase${Auth?.user.username}` && !simpleUser?.session) {
        openDb.result.close();
        setOpenDb(null);
        setFetch(true);
      }
      if (Auth && Auth.user.username && fetch && !simpleUser?.session) {
        try {
          // console.log("Initializing IndexedDB...");
          const open = indexedDB.open(`MyDatabase${Auth.user.username}`, 2);

          open.onupgradeneeded = async () => {
            const db = open.result;
            try {
              if (!db.objectStoreNames.contains("RecentLists")) {
                const store = db.createObjectStore("RecentLists", { keyPath: "id" });
                store.createIndex("NameIndex", ["name.displayName", "name.date", "name.status"]);
              }
              if (!db.objectStoreNames.contains("ContactLists")) {
                const store = db.createObjectStore("ContactLists", { keyPath: "id" });

                store.createIndex("number", "name.number", { unique: true });
              }
            } catch (error) {
              console.error("Error in openDb onupgradeneeded:", error);
              notification.error({
                message: "An error occurred during openDb onupgradeneeded",
                description: `${error}`,
              });
            }
          };

          open.onsuccess = async () => {
            const db = open.result;
            const tx = db.transaction("RecentLists", "readwrite");
            try {
              const store = tx.objectStore("RecentLists");
              store.index("NameIndex");
              setRecentCallList(db);
              setFetch(false);
              setOpenDb(open);
            } catch (error) {
              console.error("Error in openDb onsuccess:", error);
              notification.error({
                message: "An error occurred during openDb onsuccess",
                description: `${error}`,
              });
            }
          };

          open.onerror = (event: Event) => {
            const target = event.target as IDBOpenDBRequest;
            if (target) {
              console.error("Error in opening IndexedDB:", target.error);
              notification.error({
                message: "An error occurred during opening IndexedDB",
                description: `${target.error}`,
              });
            } else {
              console.error("Error in opening IndexedDB: unknown error");
              notification.error({
                message: "An unknown error occurred during opening IndexedDB",
                description: "An unknown error occurred.",
              });
            }
          };
        } catch (error) {
          console.error("Error in openDb initializing IndexedDB:", error);
          notification.error({
            message: "An error occurred during openDb initializing IndexedDB",
            description: `${error}`,
          });
        }
      }
    };
    initializeDatabase();
  }, [Auth, fetch]);

  React.useEffect(() => {
    const initializeUsers = async () => {
      if (Auth && Auth.user.username && useEffectCallCount < 4 && !simpleUser?.session) {
        try {
          if (simpleUser || inviterUser) {
            await simpleUser?.disconnect();
            await inviterUser?.disconnect();
            setSimpleUser(null);
            setInviterUser(null);
          }
          await SetupUserAgent1(Auth, setInviterUser);
          await SetupUserSimple1(Auth, setSimpleUser);
          setUUID(uuidv4());
          handleCancel();
          handleCancelCallCreated();
          setPhoneStatus({ created: false, answer: false, mute: false });
          stop();
          setIsDetailBarVisible(!isDetailBarVisible);
          setIsCallConference(false);
          setIsCallTransfer(false);
          console.log("Running in version 1.1.13");
        } catch (error) {
          setSimpleUser(null);
          useEffectCallCount += 1;
          console.error("Error in initializing initializeUsers:", error);
          notification.error({
            message: "An error occurred during initializing initializeUsers",
            description: `${error}`,
          });
        }
      }
    };
    initializeUsers();
  }, [Auth]);

  useInterval(async () => {
    try {
      if (simpleUser && !simpleUser.session) {
        await SetupUserSimple1(Auth, setSimpleUser);
      }
    } catch (error) {
      setSimpleUser(null);
      console.error("Error in Layout Landing useInterval:", error);
      notification.error({
        message: "An error occurred during Layout Landing useInterval",
        description: `${error}`,
      });
    }
  }, 3600000);

  function setupRemoteMedia(sessionSimple: any) {
    //function to create conference by mixing audio
    //sessions => array with JsSIP.RTCSessions calls
    //mediaElementId => the ID of your <audio> element to play the received streams
    //take all received tracks from the sessions you want to merge
    var receivedTracks: any[] = [];
    [sessionSimple, simpleUser?.session].forEach(function (session) {
      if (session !== null && session !== undefined) {
        session?.sessionDescriptionHandler?.peerConnection.getReceivers().forEach(function (receiver: any) {
          receivedTracks.push(receiver.track);
        });
      }
    });

    //use the Web Audio API to mix the received tracks
    var context = new AudioContext();
    var allReceivedMediaStreams = new MediaStream();

    [sessionSimple, simpleUser?.session].forEach(function (session) {
      if (session !== null && session !== undefined) {
        var mixedOutput = context.createMediaStreamDestination();

        session?.sessionDescriptionHandler?.peerConnection.getReceivers().forEach(function (receiver: any) {
          receivedTracks.forEach(function (track) {
            allReceivedMediaStreams.addTrack(receiver.track);
            if (receiver.track.id !== track.id) {
              var sourceStream = context.createMediaStreamSource(new MediaStream([track]));
              sourceStream.connect(mixedOutput);
            }
          });
        });
        //mixing your voice with all the received audio
        session?.sessionDescriptionHandler?.peerConnection.getSenders().forEach(function (sender: any) {
          var sourceStream = context.createMediaStreamSource(new MediaStream([sender.track]));
          sourceStream.connect(mixedOutput);
        });
        session?.sessionDescriptionHandler?.peerConnection
          .getSenders()[0]
          .replaceTrack(mixedOutput.stream.getTracks()[0]);
      }
    });

    //play all received stream to you
    mediaElement.srcObject = allReceivedMediaStreams;
    var promiseRemote = mediaElement.play();
    if (promiseRemote !== undefined) {
      promiseRemote
        .then((_) => {
          // console.log("playing all received streams to you kkk");
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }
  function setupRemoteMediaSimpleUser(session: any) {
    session.sessionDescriptionHandler.peerConnection.getReceivers().forEach((receiver: any) => {
      if (receiver.track) {
        remoteStream.addTrack(receiver.track);
      }
    });
    mediaElement.srcObject = remoteStream;
    mediaElement.play();
  }

  function cleanupMedia() {
    mediaElement.srcObject = null;
    mediaElement.pause();
  }

  const isCardPhoneConferenceShow = React.useCallback(() => {
    setIsCardPhoneConference(true);
  }, []);

  if (inviterUser !== null) {
    const remoteUser = inviterUser?.session?.remoteIdentity?.uri?.user;
    inviterUser.delegate = {
      onCallAnswered: async () => {
        if (isCardPhoneConference !== true) {
          isCardPhoneConferenceShow();
        }
        setConferenceStatus({ answer: true });
        stop();
        setupRemoteMedia(inviterUser?.session);
        setTimeConferenceStatus(STATUS.STARTED);
      },
      onCallCreated: async () => {
        if (conferenceStatus.created !== true) {
          isCardPhoneConferenceShow();
          playCall();
          const status = {
            // target : inviterUser?.session?.remoteIdentity?.uri?.user,
            status: "Calling",
          };

          callData?.callManager.triggerStatusUpdate(status);
        }
      },
      onCallHangup: async () => {
        const status = {
          // target : remoteUser,
          status: "Hangup",
        };

        callData?.callManager.triggerStatusUpdate(status);
        setIsCardPhoneConference(false);
        setUUID(uuidv4());
        setVideoLayout(false);
        setConferenceStatus({
          created: false,
          answer: false,
          mute: false,
          hold: false,
          conference: false,
        });
        setTimeConferenceStatus(STATUS.STOPPED);
        setSecondsConferenceRemaining(INITIAL_COUNT);
        stop();
        cleanupMedia();
        setIsCallConference(false);
        setIsCallTransfer(false);
        if (simpleUser?.session) {
          setupRemoteMediaSimpleUser(simpleUser?.session);
        }
      },
      onUnregistered: async () => {
        setInviterUser(null);
      },
      onServerDisconnect: async () => {
        setInviterUser(null);
      },
    };
    inviterUser?.session?.stateChange?.addListener((state: any) => {
      if (state === SessionState.Terminated) {
        setIsCardPhoneConference(false);
      }
    });
  }

  function setupRemoteMediaSimpleUserRingBackTone(session: any) {
    try {
      stop();
      var pc = session?._sessionDescriptionHandler?._peerConnection;
      // console.log("fff-inringback", pc);
      var remoteStream: any = null;
      if (pc?.getReceivers) {
        remoteStream = new window.MediaStream();
        pc?.getReceivers()?.forEach(function (receiver: any) {
          var track = receiver?.track;
          if (track) {
            remoteStream.addTrack(track);
          }
        });
      } else {
        remoteStream = pc?.getRemoteStreams()[0];
      }
      mediaElement.srcObject = remoteStream;
      mediaElement.play().catch((error) => {
        console.warn("Play request interrupted, retrying...");
        setTimeout(() => {
          mediaElement.play().catch((error) => {
            console.error("Error in playing media:", error);
          });
        }, 1000);
      });
    } catch (error) {
      console.error("Error in setupRemoteMediaSimpleUserRingBackTone:", error);
    }
  }
  if (simpleUser !== null) {
    // console.log("fff-ses0", simpleUser?.session);
    if (simpleUser?.session?.earlyMedia) {
      // console.log("fff-sesss", simpleUser?.session);
      setupRemoteMediaSimpleUserRingBackTone(simpleUser?.session);
    }
    simpleUser.delegate = {
      onCallAnswered: async () => {
        try {
          const voiceonly =
            simpleUser?.session?._sessionDescriptionHandler?._remoteMediaStream?.getVideoTracks()?.length === 0;
          setPhoneStatus({ answer: true });
          stop();
          setTimeStatus(STATUS.STARTED);
          if (voiceonly !== undefined) {
            setVideoLayout(!voiceonly);
          }
          setIsCallAnswered(true);
        } catch (error) {
          console.error("Error in Layout Landing simpleUser onCallAnswered:", error);
          notification.error({
            message: "An error occurred during Layout Landing simpleUser onCallAnswered",
            description: `${error}`,
          });
        }
      },
      onCallReceived: async () => {
        try {
          const sdp = simpleUser?.session?.request?.body;
          const offeredVideo = /\r\nm=video /.test(sdp) ? true : false;
          const tx = await recentCallList.transaction("RecentLists", "readwrite");
          const store = await tx.objectStore("RecentLists");
          await store.put({
            id: `${uuid}`,
            name: {
              displayName: `${
                simpleUser?.session?.remoteIdentity?.displayName
                  ? simpleUser?.session?.remoteIdentity?.displayName
                  : simpleUser?.session?.remoteIdentity?.uri?.user
              }`,
              date: dayjs().format(),
              status: offeredVideo ? "videoReceived" : "received",
            },
            target: `${simpleUser?.session?.remoteIdentity?.uri?.user}`,
          });

          setFetch(true);
          showCard();
          setIsCardVisibleCallCreated(false);
          playReceive();
        } catch (error) {
          console.error("Error in Layout Landing simpleUser onCallReceived:", error);
          notification.error({
            message: "An error occurred during Layout Landing simpleUser onCallReceived",
            description: `${error}`,
          });
        }
      },
      onCallCreated: async () => {
        try {
          if (phoneStatus.created !== true) {
            setIsCardVisibleCallCreated(true);
            playCall();
            const _constraints = simpleUser?.session?.sessionDescriptionHandlerOptions?.constraints;
            if (
              _constraints &&
              typeof _constraints === "object" &&
              _constraints.video &&
              typeof _constraints.video === "object"
            ) {
              setVideoLayout(true);
            }
          }
          const status = {
            // target : simpleUser?.session?.remoteIdentity?.uri?.user,
            status: "Calling",
          };

          callData?.callManager.triggerStatusUpdate(status);
        } catch (error) {
          console.error("Error in Layout Landing simpleUser onCallCreated:", error);
          notification.error({
            message: "An error occurred during Layout Landing simpleUser onCallCreated",
            description: `${error}`,
          });
        }
      },
      onCallHold: () => {},

      onCallHangup: async () => {
        try {
          if (!isCallAnswered) {
            const sdp = simpleUser?.session?.request?.body;
            const offeredVideo = /\r\nm=video /.test(sdp) ? true : false;
            const tx = await recentCallList.transaction("RecentLists", "readwrite");
            const store = await tx.objectStore("RecentLists");
            const getRequest = store.get(uuid);

            getRequest.onsuccess = async (event: any) => {
              const existingRecord = event.target.result;
              if (existingRecord) {
                const updatedRecord = {
                  ...existingRecord,
                  name: {
                    ...existingRecord.name,
                    status: offeredVideo ? "videoDeclined" : "declined",
                  },
                };
                await store.put(updatedRecord);

                const status = {
                  // target: existingRecord.name.displayName,
                  status: "Hangup",
                };
                callData?.callManager.triggerUpdate(updatedRecord);
                callData?.callManager.triggerStatusUpdate(status);
              }
            };
          } else {
            // else block
            const sdp = simpleUser?.session?.request?.body;
            const offeredVideo = /\r\nm=video /.test(sdp) ? true : false;
            const tx = await recentCallList.transaction("RecentLists", "readwrite");
            const store = await tx.objectStore("RecentLists");
            const getRequest = store.get(uuid);

            getRequest.onsuccess = async (event: any) => {
              const existingRecord = event.target.result;
              if (existingRecord) {
                const updatedRecord = {
                  ...existingRecord,
                  name: {
                    ...existingRecord.name,
                    status: offeredVideo ? "videoDeclined" : "declined",
                  },
                };
                const status = {
                  // target: existingRecord.name.displayName,
                  status: "Hangup",
                };
                callData?.callManager.triggerStatusUpdate(status);
              }
            };
          }
          // Fetch
          setFetch(true);
          setUUID(uuidv4());
          handleCancel();
          handleCancelCallCreated();
          setVideoLayout(false);
          setPhoneStatus({
            created: false,
            answer: false,
            mute: false,
            hold: false,
            conference: false,
          });
          setIsCallAnswered(false);
          setTimeStatus(STATUS.STOPPED);
          setSecondsRemaining(INITIAL_COUNT);
          stop();
          cleanupMedia();
          setIsCallConference(false);
          setIsCallTransfer(false);
          micManager.cleanupMic();
          if (inviterUser?.session) {
            setupRemoteMediaSimpleUser(inviterUser?.session);
          }
        } catch (error) {
          console.error("Error in Layout Landing simpleUser onCallHangup:", error);
          notification.error({
            message: "An error occurred during Layout Landing simpleUser onCallHangup",
            description: `${error}`,
          });
        }
      },

      onServerDisconnect: async () => {
        if (navigator.onLine) {
          await SetupUserSimple1(Auth, setSimpleUser);
          setUUID(uuidv4());
          handleCancel();
          handleCancelCallCreated();
          setPhoneStatus({ created: false, answer: false, mute: false });
          stop();
          setIsCallConference(false);
          setIsCallTransfer(false);
        }
      },
      onUnregistered: async () => {
        if (navigator.onLine) {
          await SetupUserSimple1(Auth, setSimpleUser);
          setUUID(uuidv4());
          handleCancel();
          handleCancelCallCreated();
          setPhoneStatus({ created: false, answer: false, mute: false });
          stop();
          setIsCallConference(false);
          setIsCallTransfer(false);
        }
      },
    };
  }

  return (
    <>
      <div
        id="divshowvideo"
        style={{
          display: "none",
          bottom: "0px",
          right: "0px",
          width: "100%",
          height: "100%",
          position: "fixed",
          zIndex: videoLayout ? 1 : -1,
          background: videoLayout ? "rgba(0,0,0,0.7)" : "rgba(0,0,0,0)",
        }}
      >
        <video
          id="remote_video_softphone"
          style={{
            bottom: "0px",
            right: "0px",
            position: "relative",
            width: "100%",
            height: "100%",
          }}
          autoPlay
        ></video>
        <video
          id="local_video_softphone"
          style={{
            position: "absolute",
            bottom: "0px",
            right: "0px",
            width: "30%",
          }}
          autoPlay
        ></video>
      </div>
      {children}
      {(Auth && Auth.user && Auth.user.username && openDb) || simpleUser?.session ? (
        <DetailBar
          handleCancel={handleCancel}
          isCardVisible={isCardVisible}
          setTimeStatus={setTimeStatus}
          timeStatus={timeStatus}
          setSecondsRemaining={setSecondsRemaining}
          secondsRemaining={secondsRemaining}
          isCardPhoneConference={isCardPhoneConference}
          isCardPhoneConferenceShow={isCardPhoneConferenceShow}
          playCall={playCall}
          isCardVisibleCallCreated={isCardVisibleCallCreated}
          setTimeConferenceStatus={setTimeConferenceStatus}
          timeConferenceStatus={timeConferenceStatus}
          setSecondsConferenceRemaining={setSecondsConferenceRemaining}
          secondsConferenceRemaining={secondsConferenceRemaining}
          isCallConference={isCallConference}
          setIsCallConference={setIsCallConference}
          isCallTransfer={isCallTransfer}
          setIsCallTransfer={setIsCallTransfer}
        />
      ) : (
        <></>
      )}
    </>
  );
};

export default LayoutLanding;
