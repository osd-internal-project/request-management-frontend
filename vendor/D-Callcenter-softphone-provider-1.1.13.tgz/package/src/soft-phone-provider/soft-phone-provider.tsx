import React from "react";
import { ConferenceStatusProvider } from "../context/conference-status-context";
import { InviterUserProvider } from "../context/inviter-user-context";
import { PhoneStatusProvider } from "../context/phone-status-context";
import { RecentCallListProvider } from "../context/recent-calllist-context";
import { SimpleUserProvider } from "../context/simple-user-context";
import { SoftPhoneUserProvider } from "../context/soft-phone-user-context";
import { VideoLayoutProvider } from "../context/video-context";
import LayoutLanding from "./component/layout-landing";
import { DetailBarProvider } from "../context/detail-bar-context";
import { ConfigProvider } from "antd";
import { SelectStatusProvider } from "../context/select-status-context";
import { ExternalDatabaseProvider } from "../context/update-data-transaction-context";

type SoftPhoneProviderTypes = {
  children: React.ReactNode;
  setTheme?: any;
};

const SoftPhoneProvider: React.FC<SoftPhoneProviderTypes> = ({ children, setTheme }) => {
  const defaultTheme = {
    components: {
      Card: {
        zIndexPopup: 2000,
      },
    },
  };
  return (
    <>
      <SoftPhoneUserProvider>
        <SimpleUserProvider>
          <VideoLayoutProvider>
            <InviterUserProvider>
              <RecentCallListProvider>
                <PhoneStatusProvider>
                  <ConferenceStatusProvider>
                    <ExternalDatabaseProvider>
                      <SelectStatusProvider>
                        <DetailBarProvider>
                          <ConfigProvider theme={setTheme || defaultTheme}>
                            <LayoutLanding>{children}</LayoutLanding>
                          </ConfigProvider>
                        </DetailBarProvider>
                      </SelectStatusProvider>
                    </ExternalDatabaseProvider>
                  </ConferenceStatusProvider>
                </PhoneStatusProvider>
              </RecentCallListProvider>
            </InviterUserProvider>
          </VideoLayoutProvider>
        </SimpleUserProvider>
      </SoftPhoneUserProvider>
      <audio id="remote_audio_softphone" autoPlay></audio>
    </>
  );
};
export default SoftPhoneProvider;
