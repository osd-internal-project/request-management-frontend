// src/lib/useCallToReceive.ts
import { usePhoneStatus } from "../context/phone-status-context";
import { useContainerLayout } from "../context/video-context";
import useSoftPhoneUser from "../context/soft-phone-user-context";
import { useRecentCallList } from "../context/recent-calllist-context";
import { useSimpleUser } from "../context/simple-user-context";
import useExternalDatabase from "../context/update-data-transaction-context";
import { callToAnother } from "./phone-call-handler";

/**
 * Custom hook that handles the process of receiving a call in a SIP.js application.
 * It manages the phone status, video layout, and database transactions related to the call.
 *
 * @returns {{ callToReceive: (displayName: string) => Promise<void> }}
 * - `callToReceive`: A function to initiate a call to a specified user.
 */
export const useCallToReceive = (): { callToReceive: (displayName: string) => Promise<void> } => {
  const Auth = useSoftPhoneUser();
  const { setPhoneStatus } = usePhoneStatus();
  const { setVideoLayout } = useContainerLayout();
  const { simpleUser } = useSimpleUser();
  const { recentCallList, setFetch, setUUID, uuid } = useRecentCallList();
  const callData = useExternalDatabase();

  /**
   * Initiates a call to the specified user.
   * It sets the initial phone status, configures the video layout, and handles call transactions.
   *
   * @async
   * @param {string} displayName - The display name of the user to call.
   * @returns {Promise<void>} - A promise that resolves when the call has been handled.
   */

  const callToReceive = async (displayName: string): Promise<void> => {
    callToAnother(
      setPhoneStatus,
      setVideoLayout,
      displayName,
      Auth,
      recentCallList,
      setFetch,
      uuid,
      setUUID,
      callData,
      simpleUser
    );
  };

  return { callToReceive };
};
export default useCallToReceive;
