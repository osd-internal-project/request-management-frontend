import { notification } from "antd";
import { showNotification } from "./notification-handler";
import { CallTransaction, hangupWhenError } from "./transaction-handler";
import { ExternalDatabaseType } from "../context/update-data-transaction-context";
import { PhoneStatusType } from "../context/phone-status-context";
import { SetStateAction } from "./hook";
import { Inviter, UserAgent } from "sip.js";
import { IncomingResponse } from "sip.js/lib/core";
import { v4 as uuidv4 } from "uuid";
import { selectAudioCodec } from "./select-audio-codec";
// import * as SIP from "sip.js";\

// const audio = { noiseSuppression: false, echoCancellation: true, autoGainControl: false };

// answer
export const handleAnswer = async (
  simpleUser: any,
  recentCallList: any,
  uuid: any,
  setPhoneStatus: any,
  setFetch: any,
  callData?: ExternalDatabaseType | null
) => {
  try {
    if (!(await handleCheckPermission())) return;
    const sdp = simpleUser?.session?.request?.body;
    const offeredVideo = /\r\nm=video /.test(sdp) ? true : false;
    const tx = await recentCallList.transaction("RecentLists", "readwrite");
    const store = await tx.objectStore("RecentLists");
    const getRequest = store.get(uuid);
    getRequest.onsuccess = async (event: any) => {
      const existingRecord = event.target.result;
      if (existingRecord) {
        const updatedRecord = {
          ...existingRecord,
          name: {
            ...existingRecord.name,
            status: offeredVideo ? "videoReceived" : "received",
          },
        };
        await store.put(updatedRecord);

        callData?.callManager.triggerUpdate(updatedRecord);
      }
    };
    setFetch(true);
    if (sdp) {
      simpleUser?.answer({
        sessionDescriptionHandlerOptions: {
          constraints: {
            audio: true,
            video: offeredVideo,
          },
        },
      });
      setPhoneStatus({ answer: true });
    } else {
      simpleUser?.answer({
        sessionDescriptionHandlerOptions: {
          constraints: {
            audio: true,
            video: false,
          },
        },
      });
      setPhoneStatus({ answer: true });
    }
  } catch (error) {
    console.error("Error in handleAnswer:", error);
    notification.error({
      message: "An error occurred during handleAnswer",
      description: `${error}`,
    });
  }
};

// hangup
export const handleHangUp = async (
  simpleUser: any,
  handleCancel: any,
  handleReset: any,
  callData?: ExternalDatabaseType | null
) => {
  try {
    await simpleUser?.hangup();
    handleCancel();
    handleReset();
    callData?.callManager.triggerUpdate();
  } catch (error) {
    console.error("Error in handleHangUp:", error);
    notification.error({
      message: "An error occurred during handleHangUp",
      description: `${error}`,
    });
  }
};

// mute
export const handleMute = async (simpleUser: any, setPhoneStatus: any) => {
  try {
    await simpleUser?.mute();
    setPhoneStatus({ mute: true });
  } catch (error) {
    console.error("Error in handleMute:", error);
  }
};

// unmute
export const handleUnMute = async (simpleUser: any, setPhoneStatus: any) => {
  try {
    await simpleUser?.unmute();
    setPhoneStatus({ mute: false });
  } catch (error) {
    console.error("Error in handleUnMute:", error);
  }
};

// hold
export const handleHold = async (simpleUser: any) => {
  try {
    await simpleUser?.hold();
  } catch (error) {
    notification.error({
      message: "Unable to place the call on hold.",
    });
  }
};

// unhold
export const handleUnHold = async (simpleUser: any) => {
  try {
    await simpleUser?.unhold();
  } catch (error) {
    notification.error({
      message: "Unable to resume the call from hold.",
    });
  }
};

// decline
export const handleDecline = async (
  simpleUser: any,
  recentCallList: any,
  uuid: any,
  handleCancel: any,
  setPhoneStatus: any,
  handleReset: any,
  callData?: ExternalDatabaseType | null
) => {
  try {
    await simpleUser?.decline();
    const sdp = simpleUser?.session?.request?.body;
    const offeredVideo = /\r\nm=video /.test(sdp) ? true : false;
    const tx = await recentCallList.transaction("RecentLists", "readwrite");
    const store = await tx.objectStore("RecentLists");
    const getRequest = store.get(uuid);
    getRequest.onsuccess = async (event: any) => {
      const existingRecord = event.target.result;
      if (existingRecord) {
        const updatedRecord = {
          ...existingRecord,
          name: {
            ...existingRecord.name,
            status: offeredVideo ? "videoDeclined" : "declined",
          },
        };
        await store.put(updatedRecord);

        callData?.callManager.triggerUpdate(updatedRecord);
      }
    };
    handleCancel();
    setPhoneStatus({ created: false, answer: false, mute: false });
    handleReset();
  } catch (error) {
    console.error("Error in handleDecline:", error);
  }
};

export const handleTransfer = async (simpleUser: any, setPhoneStatus: any, callData?: ExternalDatabaseType | null) => {
  try {
    await setPhoneStatus({ transfer: true });
    callData?.callManager.triggerUpdate();
  } catch (error) {
    console.error("Error in handleTransfer:", error);
    notification.error({
      message: "An error occurred during handleTransfer",
      description: `${error}`,
    });
  }
};

// call conference
export const handleCallConference = async (
  simpleUser: any,
  setPhoneStatus: any,
  callData?: ExternalDatabaseType | null
) => {
  try {
    await setPhoneStatus({ conference: true });
    callData?.callManager.triggerUpdate();
  } catch (error) {
    console.error("Error in handleCallConference:", error);
    notification.error({
      message: "An error occurred during handleCallConference",
      description: `${error}`,
    });
  }
};

export const handleCheckPermission = async (): Promise<boolean> => {
  try {
    await navigator.mediaDevices.getUserMedia({ audio: true });
    return true;
  } catch (error) {
    console.error("Microphone permission error:", error);
    showNotification("error", "No permission to access the microphone or no microphone available");
    return false;
  }
};

export const callToAnother = async (
  setPhoneStatus: (newState: SetStateAction<PhoneStatusType>) => void,
  setVideoLayout: (videoLayout: boolean) => void,
  numpadValue: string,
  Auth: any,
  recentCallList: any,
  setFetch: (fetch: boolean) => void,
  uuid: string,
  setUUID: (uuid: string) => void,
  callData: ExternalDatabaseType | null,
  simpleUser: any,
  setNumpadValue?: (numpadValue: string) => void
) => {
  try {
    if (!(await handleCheckPermission())) return;
    setPhoneStatus({ created: true, answer: false });
    setVideoLayout(false);

    if (!numpadValue || !Auth || !Auth.user || !Auth.user.ipServer) {
      console.error("Missing required data for making the call");
      return;
    }

    const target = UserAgent.makeURI(`sip:${numpadValue}@${Auth.user.ipServer}`);
    if (!target) {
      console.error("Invalid target URI");
      return;
    }

    const inviterInviteOptions = {
      requestDelegate: {
        onReject: async (response: IncomingResponse) => {
          await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
          // Update state and notify
          setUUID(uuidv4());
          setFetch(true);
          if (response.message.statusCode === 486 && Auth?.user.notificationVisible?.isBusy) {
            console.warn(`[${numpadValue}] Call is busy`);
            showNotification("warning", `"${numpadValue}" is currently busy`);
          } else {
            console.warn(`[${numpadValue}] INVITE rejected`);
          }
          // notification.error({
          //   message: `"${numpadValue}" Missed your call.\n`,
          // });
        },
      },
    };

    if (!simpleUser || !simpleUser.userAgent) {
      console.error("simpleUser or simpleUser.userAgent is not defined");
      return;
    }

    // console.log("Creating Inviter with options:", inviterOptions);
    const inviter = new Inviter(simpleUser.userAgent, target, inviterOptions);

    simpleUser
      .sendInvite(inviter, inviterOptions, inviterInviteOptions)
      .then(async () => {
        try {
          await CallTransaction(numpadValue, uuid, "call", recentCallList, callData);
          // Update state
          setFetch(true);
          setNumpadValue && setNumpadValue("");
          // Additional logic to handle call acceptance or rejection can be added here
        } catch (error) {
          console.error("Error updating recent call data:", error);
        }
      })
      .catch(async (error: any) => {
        setPhoneStatus({ created: false });
        await hangupWhenError(error, numpadValue, uuid, "call", recentCallList, callData, setUUID, setFetch);
      });
  } catch (error) {
    console.error("🚀 ~ callToAnother ~ error:", error);
  }
};

export const callToAnotherVideo = async (
  setPhoneStatus: (newState: SetStateAction<PhoneStatusType>) => void,
  setVideoLayout: (videoLayout: boolean) => void,
  numpadValue: string,
  Auth: any,
  recentCallList: any,
  setFetch: (fetch: boolean) => void,
  uuid: string,
  setUUID: (uuid: string) => void,
  callData: ExternalDatabaseType | null,
  simpleUser: any,
  setNumpadValue?: (numpadValue: string) => void
) => {
  try {
    if (!(await handleCheckPermission())) return;
    setPhoneStatus({ created: true, answer: false });
    setVideoLayout(true);
    simpleUser
      ?.call(
        `sip:${numpadValue}@${Auth?.user?.ipServer}`,
        {
          sessionDescriptionHandlerOptions: {
            streams: new MediaStream(),
            constraints: {
              audio: true,
              video: true,
            },
          },
        },
        {
          // An example of how to get access to a SIP response message for custom handling
          requestDelegate: {
            onReject: async (response: IncomingResponse) => {
              await CallTransaction(numpadValue, uuid, "videoMissed", recentCallList, callData);
              setUUID(uuidv4());
              setFetch(true);
              if (response.message.statusCode === 486 && Auth?.user.notificationVisible?.isBusy) {
                console.warn(`[${numpadValue}] Call is busy`);
                showNotification("warning", `"${numpadValue}" is currently busy`);
              } else {
                console.warn(`[${numpadValue}] INVITE rejected`);
              }
              // notification.error({
              //   message: `"${numpadValue}" Missed your video call.\n`,
              // });
            },
          },
        }
      )
      .then(async () => {
        await CallTransaction(numpadValue, uuid, "videoCall", recentCallList, callData);

        setFetch(true);
        setNumpadValue && setNumpadValue("");
      })
      .catch(() => {
        setPhoneStatus({ created: false });
      });
  } catch (error) {
    console.error("🚀 ~ callToAnotherVideo ~ error:", error);
  }
};

export const inviterOptions = {
  alwaysAcquireMediaFirst: true,
  earlyMedia: true,
  sessionDescriptionHandlerOptions: {
    streams: new MediaStream(),
    constraints: {
      audio: true,
      video: false,
    },
  },
  sessionDescriptionHandlerModifiers: [
    async (sd: RTCSessionDescriptionInit): Promise<RTCSessionDescriptionInit> =>
      sd.sdp ? { ...sd, sdp: selectAudioCodec(sd.sdp, "PCMA") } : sd,
  ],
};
