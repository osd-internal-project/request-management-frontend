import { useState, useEffect, useRef, useMemo, useLayoutEffect } from "react";
import { SimpleUserCustom } from "./simple-user-custom";
import { notification } from "antd";
import { URI } from "sip.js";
import { getVideo } from "../soft-phone-provider/component/media";
import { UserAgentCustom } from "./user-agent-func";
import { SimpleUserOptions } from "sip.js/lib/platform/web";

export const useIsomorphicLayoutEffect =
  typeof window !== "undefined" ? useLayoutEffect : useEffect;
export const useInterval = (
  callback: () => void,
  delay: number | null = 1000
) => {
  const savedCallback = useRef(callback);

  // Remember the latest callback if it changes.
  useIsomorphicLayoutEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // Set up the interval.
  useEffect(() => {
    // Don't schedule if no delay is specified.
    // Note: 0 is a valid value for delay.
    if (!delay && delay !== 0) {
      return;
    }

    const id = setInterval(() => savedCallback.current(), delay);

    return () => clearInterval(id);
  }, [delay]);
};
export type SetStateAction<S> =
  | S
  | Partial<S>
  | ((prevState: S) => S | Partial<S>);

type InitStateObject<S> = {
  [K in keyof S]: S[K] | (() => S[K]);
};

export const useMultiState = <S extends object>(
  initState: InitStateObject<S>
): [S, (newState: SetStateAction<S>) => void] => {
  // Initialize the state by evaluating any functions in initState
  const initialState = useMemo(() => {
    try {
      const state: Partial<S> = {};
      for (const key in initState) {
        state[key] =
          typeof initState[key] === "function"
            ? (initState[key] as Function)()
            : initState[key];
      }
      return state as S;
    } catch (error) {
      console.error('Error useMultiState initializing state:', error);
      return {} as S;
    }
  }, [initState]);

  const [state, setState] = useState(initialState);

  // Enhanced setter function that can update the entire state or individual properties
  const enhancedSetState = (newState: SetStateAction<S>) => {
    try {
      setState((prevState) => {
        const updatedState =
          typeof newState === "function"
            ? (newState as (prevState: S) => S)(prevState)
            : newState;
        // Ensure we only update if there's a meaningful change
        const mergedState = { ...prevState, ...updatedState };
        return prevState === mergedState
          ? prevState
          : mergedState;
      });
    } catch (error) {
      console.error('Error useMultiState updating state:', error);
    }
  };

  return [state, enhancedSetState];
}

export const usePrevious = (value: any) => {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
};

export const useScroll = () => {
  // storing this to get the scroll direction
  const [lastScrollTop, setLastScrollTop] = useState(0);
  // the offset of the document.body
  const [bodyOffset, setBodyOffset] = useState(
    document.body.getBoundingClientRect()
  );
  // the vertical direction
  const [scrollY, setScrollY] = useState(bodyOffset.top);
  // the horizontal direction
  const [scrollX, setScrollX] = useState(bodyOffset.left);
  // scroll direction would be either up or down
  const [scrollDirection, setScrollDirection] = useState<"down" | "up">();

  const listener = () => {
    setBodyOffset(document.body.getBoundingClientRect());
    setScrollY(-bodyOffset.top);
    setScrollX(bodyOffset.left);
    setScrollDirection(lastScrollTop > -bodyOffset.top ? "down" : "up");
    setLastScrollTop(-bodyOffset.top);
  };

  useEffect(() => {
    window.addEventListener("scroll", listener);
    return () => {
      window.removeEventListener("scroll", listener);
    };
  });

  return {
    scrollY,
    scrollX,
    scrollDirection,
  };
};

const useSetupOptions = async (Auth: any) => {
  const audioEle = await getVideo("remote_audio_softphone");
  const videoRemote = await getVideo("remote_video_softphone");
  const videoLocal = await getVideo("local_video_softphone");
  const options: SimpleUserOptions = {
    aor: `sip:${Auth?.user?.username}@${Auth?.user?.ipServer}`,
    media: {
      constraints: { audio: true, video: true },
      remote: {
        audio: audioEle as HTMLAudioElement,
        video: videoRemote as HTMLVideoElement,
      },
      local: { video: videoLocal as HTMLVideoElement },
    },
    userAgentOptions: {
      logLevel: "error",
      authorizationUsername: Auth?.user?.username,
      authorizationPassword: Auth?.user?.password,
      uri: new URI("sip", `${Auth?.user?.username}`, `${Auth?.user?.ipServer}`),
      displayName: Auth?.user?.username,
    },
  };
  return options;
};

let setupUserSimple1CallCount = 0;
export const SetupUserSimple1 = async (Auth: any, setSimpleUser: any) => {
  try {
    const options = await useSetupOptions(Auth);
    if (setupUserSimple1CallCount < 4) {
      const simple1 = new SimpleUserCustom(Auth?.user?.socketServer, options);
      if (simple1) {
        await simple1.connect();
        simple1.isConnected() &&
          (await simple1.register(
            { expires: 3600 },
            {
              requestDelegate: {
                onAccept() {
                  setSimpleUser(simple1);
                },
                onReject: async () => {
                  setSimpleUser(null);
                  simple1.disconnect();
                },
              },
            }
          ));
      }
    }
  } catch (error) {
    setupUserSimple1CallCount += 1;
    setSimpleUser(null);
    console.error("Error in SetupUserSimple1:", error);
    // notification.error({
    //   message: "An error occurred during SetupUserSimple1",
    //   description: `${error}${setupUserSimple1CallCount}`,
    // });
  }
};

let setupAgent1CallCount = 0;
export const SetupUserAgent1 = async (Auth: any, setInviterUser: any) => {
  try {
    const options = await useSetupOptions(Auth);
    if (setupAgent1CallCount < 4) {
      const userAgent1 = new UserAgentCustom(Auth?.user?.socketServer, options);
      if (userAgent1) {
        await userAgent1.connect();
        await userAgent1.register({ expires: 3600 }, {
          requestDelegate: {
            onReject: async () => {
              notification.error({
                message: `Login with number "${Auth?.user?.username}" was rejected.`,
              });
            },
          },
        });
        setInviterUser(userAgent1);
      }
    }
  } catch (error) {
    setupAgent1CallCount += 1;
    console.error("Error in SetupUserAgent1:", error);
    notification.error({
      // message: "An error occurred during SetupUserAgent1",
      message: "An error occurred during setup",
      // description: `${error} ${setupAgent1CallCount}`,
      description: `Something went wrong, please try again later.`,
    });
  }
};