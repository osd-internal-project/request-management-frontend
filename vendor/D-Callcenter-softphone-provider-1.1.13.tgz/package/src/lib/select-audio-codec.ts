/**
 * ฟังก์ชันสำหรับปรับแต่ง SDP ให้ใช้โคเดกเสียงที่ต้องการพร้อมค่า ptime ที่เหมาะสม
 * @param sdp ข้อความ SDP ต้นฉบับ
 * @param codecType ประเภทของโคเดกที่ต้องการใช้ (เช่น "PCMA", "PCMU", "opus", "G722")
 * @param customPtime ค่า packet time ที่กำหนดเอง (ถ้าไม่ระบุจะใช้ค่าแนะนำของแต่ละโคเดก)
 * @returns ข้อความ SDP ที่ถูกปรับแต่งแล้ว
 */
export const selectAudioCodec = (sdp: string, codecType: string, customPtime?: number): string => {
  // ตารางข้อมูลโคเดกและ payload type ที่เกี่ยวข้อง พร้อมค่า ptime ที่แนะนำ
  const codecMap: Record<
    string,
    {
      payloadType: number;
      rtpmap: string;
      recommendedPtime: number;
      fmtp?: string;
    }
  > = {
    PCMA: {
      payloadType: 8,
      rtpmap: "a=rtpmap:8 PCMA/8000",
      recommendedPtime: 20,
    },
    PCMU: {
      payloadType: 0,
      rtpmap: "a=rtpmap:0 PCMU/8000",
      recommendedPtime: 20,
    },
    G722: {
      payloadType: 9,
      rtpmap: "a=rtpmap:9 G722/8000",
      recommendedPtime: 20,
    },
    opus: {
      payloadType: 111,
      rtpmap: "a=rtpmap:111 opus/48000/2",
      recommendedPtime: 20,
      fmtp: "a=fmtp:111 minptime=10;useinbandfec=1;stereo=0",
    },
    iLBC: {
      payloadType: 102,
      rtpmap: "a=rtpmap:102 iLBC/8000",
      recommendedPtime: 30,
      fmtp: "a=fmtp:102 mode=30",
    },
    GSM: {
      payloadType: 3,
      rtpmap: "a=rtpmap:3 GSM/8000",
      recommendedPtime: 20,
    },
    G729: {
      payloadType: 18,
      rtpmap: "a=rtpmap:18 G729/8000",
      recommendedPtime: 20,
      fmtp: "a=fmtp:18 annexb=no",
    },
    AMR: {
      payloadType: 96,
      rtpmap: "a=rtpmap:96 AMR/8000",
      recommendedPtime: 20,
      fmtp: "a=fmtp:96 mode-set=0,2,4,7;mode-change-period=2;mode-change-neighbor=1",
    },
    "AMR-WB": {
      payloadType: 97,
      rtpmap: "a=rtpmap:97 AMR-WB/16000",
      recommendedPtime: 20,
      fmtp: "a=fmtp:97 mode-set=0,2,4;mode-change-period=2;mode-change-neighbor=1",
    },
  };

  // ตรวจสอบว่ามีโคเดกที่ต้องการในตาราง
  if (!codecMap[codecType]) {
    console.error(`ไม่รองรับโคเดก ${codecType} กรุณาเลือกจาก: ${Object.keys(codecMap).join(", ")}`);
    return sdp; // คืนค่า SDP เดิมถ้าไม่พบโคเดกที่ต้องการ
  }

  // รับข้อมูลโคเดกที่ต้องการ
  const selectedCodec = codecMap[codecType];

  // กำหนดค่า ptime ที่จะใช้ (ใช้ค่าที่กำหนดเองถ้ามี หรือใช้ค่าแนะนำของโคเดกนั้น)
  const ptime = customPtime || selectedCodec.recommendedPtime;

  // แยก SDP เป็นบรรทัด
  let lines = sdp.split("\r\n");

  // ค้นหาและแก้ไขบรรทัด m=audio
  const audioLineIndex = lines.findIndex((line) => line.startsWith("m=audio"));
  if (audioLineIndex !== -1) {
    // แทนที่ด้วย payload type ของโคเดกที่เลือก
    lines[audioLineIndex] = `m=audio 9 UDP/TLS/RTP/SAVPF ${selectedCodec.payloadType}`;
  }

  // กรองออกเฉพาะบรรทัดที่เกี่ยวข้องกับโคเดกอื่น
  lines = lines.filter((line) => {
    // เก็บบรรทัดที่ไม่เกี่ยวกับโคเดก
    if (!line.startsWith("a=rtpmap:") && !line.startsWith("a=fmtp:") && !line.startsWith("a=rtcp-fb:")) {
      return true;
    }

    // เก็บเฉพาะบรรทัดที่เกี่ยวข้องกับโคเดกที่เลือก
    if (
      line.startsWith(`a=rtpmap:${selectedCodec.payloadType}`) ||
      line.startsWith(`a=fmtp:${selectedCodec.payloadType}`) ||
      line.startsWith(`a=rtcp-fb:${selectedCodec.payloadType}`)
    ) {
      return true;
    }

    // ลบบรรทัดโคเดกอื่นๆ
    return false;
  });

  // ตรวจสอบและเพิ่มบรรทัด rtpmap ถ้าไม่มี
  if (!lines.some((line) => line.startsWith(`a=rtpmap:${selectedCodec.payloadType}`))) {
    const insertIndex = lines.findIndex((line) => line.startsWith("m=audio")) + 1;
    lines.splice(insertIndex, 0, selectedCodec.rtpmap);
  }

  // เพิ่มบรรทัด fmtp ถ้ามีและไม่มีอยู่แล้ว
  if (selectedCodec.fmtp && !lines.some((line) => line.startsWith(`a=fmtp:${selectedCodec.payloadType}`))) {
    const rtpmapIndex = lines.findIndex((line) => line.startsWith(`a=rtpmap:${selectedCodec.payloadType}`));
    if (rtpmapIndex !== -1) {
      lines.splice(rtpmapIndex + 1, 0, selectedCodec.fmtp);
    }
  }

  // จัดการบรรทัด ptime
  const ptimeLineIndex = lines.findIndex((line) => line.startsWith("a=ptime:"));
  if (ptimeLineIndex !== -1) {
    // อัปเดตค่า ptime ที่มีอยู่
    lines[ptimeLineIndex] = `a=ptime:${ptime}`;
  } else {
    // เพิ่มบรรทัด ptime หลังจากส่วนที่เกี่ยวข้องกับโคเดก
    const rtpmapIndex = lines.findIndex((line) => line.startsWith(`a=rtpmap:${selectedCodec.payloadType}`));
    if (rtpmapIndex !== -1) {
      // เพิ่มหลัง rtpmap และ fmtp (ถ้ามี)
      let insertPosition = rtpmapIndex + 1;
      if (selectedCodec.fmtp) insertPosition++;
      lines.splice(insertPosition, 0, `a=ptime:${ptime}`);
    } else {
      // ถ้าไม่พบ rtpmap ให้เพิ่มหลัง m=audio
      const mediaIndex = lines.findIndex((line) => line.startsWith("m=audio"));
      if (mediaIndex !== -1) {
        lines.splice(mediaIndex + 1, 0, `a=ptime:${ptime}`);
      }
    }
  }

  // เพิ่มข้อมูล codec ใน bundle ถ้าจำเป็น
  if (!lines.some((line) => line.includes("a=group:BUNDLE"))) {
    // หาตำแหน่งที่เหมาะสมสำหรับเพิ่ม bundle
    const sessionEndIndex = lines.findIndex((line) => line.startsWith("t=")) + 1;
    lines.splice(sessionEndIndex, 0, "a=group:BUNDLE 0");
  }

  // ตรวจสอบและเพิ่ม mid ถ้าไม่มี
  if (!lines.some((line) => line.startsWith("a=mid:"))) {
    const mediaIndex = lines.findIndex((line) => line.startsWith("m=audio"));
    if (mediaIndex !== -1) {
      lines.splice(mediaIndex + 1, 0, "a=mid:0");
    }
  }

  // คืนค่า SDP ที่แก้ไขแล้ว
  return lines.join("\r\n");
};

// ตัวอย่างการใช้งาน
/*
  // ใช้ค่า ptime แนะนำสำหรับแต่ละโคเดก
  const pcmaSdp = selectAudioCodec(originalSdp, "PCMA");       // ใช้ค่า ptime 20ms (ค่าแนะนำ)
  const ilbcSdp = selectAudioCodec(originalSdp, "iLBC");       // ใช้ค่า ptime 30ms (ค่าแนะนำ)
  
  // กำหนดค่า ptime เอง
  const opusCustomSdp = selectAudioCodec(originalSdp, "opus", 60);  // ใช้ค่า ptime 60ms แทน 20ms
  */
