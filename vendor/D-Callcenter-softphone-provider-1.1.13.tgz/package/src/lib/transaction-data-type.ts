import { Dispatch, SetStateAction } from "react";
export type CallStatus = "missed" | "call" | "videoMissed" | "videoCall";

export type CallData = {
  id: string;
  name: {
    displayName: string;
    date: string;
    status: CallStatus;
  };
  target: string;
};

export type ContactsData = {
  displayName: string;
  number: string;
};

export type IndexedContactData = {
  id: string;
  name: {
    displayName: string;
    number: string;
    favorite: boolean;
  };
  date: string;
};

// Define the type for Name
interface Name {
  id: string;
  name: {
    displayName: string;
    number: string;
    favorite: boolean;
  };
}

// Define the type for resultContacts
interface resultContacts {
  letter: string;
  names: Name[];
}

// Define the type for CardPhoneTypes
export type CardPhoneTypes = {
  resultContact: resultContacts[];
  isCardVisible: boolean;
  handleCancel: () => void;
  timeStatus: string;
  setTimeStatus: Dispatch<SetStateAction<string>>;
  secondsRemaining: number;
  setSecondsRemaining: Dispatch<SetStateAction<number>>;
  setIsCallConference: Dispatch<SetStateAction<boolean>>;
  setIsCallTransfer: Dispatch<SetStateAction<boolean>>;
  isCallConference: boolean;
  isCallTransfer: boolean;
};

export interface CardPhoneConferenceTypes {
  resultContact: resultContacts[];
  isCardPhoneConference: boolean;
  setTimeConferenceStatus: SettimeConferenceStatusType;
  timeConferenceStatus: TimeConferenceStatusType;
  setSecondsConferenceRemaining: SetsecondsConferenceRemainingType;
  secondsConferenceRemaining: SecondsConferenceRemainingType;
  setIsCallConference: (
    value: boolean | ((prevState: boolean) => boolean)
  ) => void;
  isCallConference: boolean;
  setIsCallTransfer: (
    value: boolean | ((prevState: boolean) => boolean)
  ) => void;
  isCallTransfer: boolean;
}

interface resultContacts {
  letter: string;
  names: Name[];
}

interface Name {
  id: string;
  name: {
    displayName: string;
    number: string;
    favorite: boolean;
  };
}

type TimeConferenceStatusType = string;
type SettimeConferenceStatusType = (
  timeConferenceStatus: TimeConferenceStatusType
) => void;

type SecondsConferenceRemainingType = number;
type SetsecondsConferenceRemainingType = (
  secondsConferenceRemaining: SecondsConferenceRemainingType
) => void;

