/**
 * Class for monitoring WebRTC call statistics and calculating MOS (Mean Opinion Score).
 */
export class CallMonitor {
  private peerConnection: RTCPeerConnection;
  private stopped = false;
  private updateIntervalId?: number;
  private logTimeoutId?: ReturnType<typeof setTimeout>;
  private lastStats?: { mos: number; rtt: number; jitter: number; packetLoss: number };

  /**
   * Initializes the CallMonitor with a given RTCPeerConnection.
   * @param pc - The RTCPeerConnection to monitor.
   */
  constructor(
    pc: RTCPeerConnection,
    private onUpdate?: (data: { mos: number; rtt: number; jitter: number; packetLoss: number }) => void
  ) {
    this.peerConnection = pc;
    this.startMonitoring();
  }

  /**
   * Starts the monitoring process.
   */
  private startMonitoring(): void {
    // Update stats every 1 second
    this.updateIntervalId = window.setInterval(() => {
      this.fetchAndUpdateStats();
    }, 1000);

    // Log every 10 seconds
    const logStats = () => {
      if (this.stopped) return;

      if (this.lastStats) {
        const { mos, rtt, jitter, packetLoss } = this.lastStats;
        const constraints = this.checkAudioConstraints();
        console.log(
          `Calculated MOS Score: ${mos.toFixed(2)} (RTT=${(rtt * 1000).toFixed(2)}ms, Jitter=${(jitter * 1000).toFixed(
            2
          )}ms, PacketLoss=${(packetLoss * 100).toFixed(2)}%)`,
          constraints
        );
      }

      this.logTimeoutId = setTimeout(logStats, 10000); // Schedule next log
    };

    if ("requestIdleCallback" in window) {
      (window as any).requestIdleCallback(() => logStats());
    } else {
      logStats();
    }
  }

  /**
   * Stops the ongoing monitoring loop.
   */
  public stopMonitoring(): void {
    this.stopped = true;

    if (this.updateIntervalId) {
      clearInterval(this.updateIntervalId);
    }

    if (this.logTimeoutId) {
      clearTimeout(this.logTimeoutId);
    }

    console.log("Monitoring has been manually stopped.");
  }

  /**
   * Fetches the WebRTC stats and triggers the onUpdate callback.
   */
  private async fetchAndUpdateStats(): Promise<void> {
    if (this.stopped) return;

    try {
      const stats = await this.peerConnection.getStats();
      const result = this.calculateMos(stats);

      if (result && result.mos !== null) {
        this.lastStats = {
          mos: result.mos,
          rtt: result.rtt,
          jitter: result.jitter,
          packetLoss: result.packetLoss,
        };
        this.onUpdate?.({
          mos: result.mos,
          rtt: result.rtt,
          jitter: result.jitter,
          packetLoss: result.packetLoss,
        });
      }
    } catch (error) {
      console.error("❌ Error while fetching or calculating stats:", error);
    }
  }

  /**
   * Calculates the Mean Opinion Score (MOS) from a given RTCStatsReport.
   * @param stats - The WebRTC statistics report from RTCPeerConnection.
   * @returns Object containing MOS score, RTT, jitter, and packet loss. Returns null if insufficient data.
   */
  private calculateMos(
    stats: RTCStatsReport
  ): { mos: number | null; rtt: number; jitter: number; packetLoss: number } | null {
    let rtt = 0;
    let jitter = 0;
    let packetLoss = 0;

    stats.forEach((report) => {
      if (report.type === "remote-inbound-rtp" && report.kind === "audio") {
        rtt = report.roundTripTime || 0;
        jitter = report.jitter || 0;
        packetLoss =
          report.packetsLost && report.packetsReceived
            ? report.packetsLost / (report.packetsReceived + report.packetsLost)
            : 0;
      }
    });

    if (rtt === 0 && jitter === 0 && packetLoss === 0) {
      return null;
    }

    const effectiveLatency = rtt * 1000 + jitter * 1000 * 2 + 10;
    const mos = this.computeEModelMos(effectiveLatency, packetLoss);
    return { mos, rtt, jitter, packetLoss };
  }

  /**
   * Computes the MOS score using the E-model formula.
   * @param latency - Effective latency in milliseconds.
   * @param loss - Packet loss ratio (0 to 1).
   * @returns MOS score ranging from 1 to 4.5.
   */
  private computeEModelMos(latency: number, loss: number): number {
    const R = 93.2 - latency / 10 - loss * 100;

    if (R > 100) {
      return 4.5;
    } else if (R > 0) {
      return 1 + 0.035 * R + R * (R - 60) * (100 - R) * 0.000007;
    } else {
      return 1;
    }
  }

  /**
   * Returns the current audio constraints being used.
   * @returns MediaTrackConstraints or undefined.
   */
  private checkAudioConstraints(): MediaTrackConstraints | undefined {
    const senders = this.peerConnection.getSenders();
    const audioSender = senders.find((sender) => sender.track?.kind === "audio");
    if (audioSender?.track) {
      return audioSender.track.getConstraints?.();
    } else {
      console.warn("⚠️ No audio sender track found.");
      return undefined;
    }
  }
}
