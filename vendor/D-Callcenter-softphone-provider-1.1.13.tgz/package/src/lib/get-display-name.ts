export const GetDisplayName = (resultContact: any[], remoteUser: string | undefined): string | undefined => {
    const matchingContact = resultContact
        .flatMap((contact) => contact.names)
        .find((name) => name.name.number === remoteUser);
    return matchingContact ? matchingContact.name.displayName : remoteUser;
};