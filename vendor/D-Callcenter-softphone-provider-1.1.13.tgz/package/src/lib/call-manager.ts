/* The `Delegate` class in TypeScript allows users to set custom fetch functions for recent calls and
contacts, and provides methods to trigger updates and deletions with callback functions. */

import { CallData, IndexedContactData } from "./transaction-data-type";

class CallManager {

  private recentCallsFetchFunction?: () => Promise<CallData[]>;
  private contactFetchFunction?: () => Promise<IndexedContactData[]>;

  // Method to allow users to set their own fetch function for recent calls
  setRecentCallsFetchFunction(fetchFunction: () => Promise<CallData[]>) {
    this.recentCallsFetchFunction = fetchFunction;
  }

  // Method to allow users to set their own fetch function for contacts
  setContactFetchFunction(fetchFunction: () => Promise<IndexedContactData[]>) {
    this.contactFetchFunction = fetchFunction;
  }

  onCallUpdate?: (data?: CallData) => void;
  onUpdateContact?: (data?: IndexedContactData) => void;
  onDeleteContact?: (id?: string) => void;
  onDeleteRecentCall?: (id?: string) => void;
  onStatusUpdate?: (statusPhone: { 
    // target: string; 
    status: string }) => void; // New callback for recent call deletion

  constructor(
    onCallUpdate?: (data?: CallData) => void,
    onUpdateContact?: (data?: IndexedContactData) => void,
    onDeleteContact?: (id?: string) => void,
    onDeleteRecentCall?: (id?: string) => void,
    onStatusUpdate?: (statusPhone: { 
      // target: string; 
      status: string }) => void // New constructor parameter for recent call deletion
  ) {
    this.onCallUpdate = onCallUpdate;
    this.onUpdateContact = onUpdateContact;
    this.onDeleteContact = onDeleteContact;
    this.onDeleteRecentCall = onDeleteRecentCall;
    this.onStatusUpdate = onStatusUpdate; // Initialize new callback
  }

  onCall(callback: (data?: CallData) => void) {
    this.onCallUpdate = callback;
  }

  onContactUpdate(callback: (data?: IndexedContactData) => void) {
    this.onUpdateContact = callback;
  }

  onContactDelete(callback: (id?: string) => void) {
    this.onDeleteContact = callback;
  }

  onRecentCallDelete(callback: (id?: string) => void) { // New method for recent call deletion callback
    this.onDeleteRecentCall = callback;
  }

  onSessionStatusUpdate(callback: (SessionStatus: { 
    // target: string; 
    status: string }) => void) {
    this.onStatusUpdate = callback;
  }

  triggerUpdate(data?: CallData) {
    if (this.onCallUpdate) {
      this.onCallUpdate(data);
    }
  }

  triggerContactUpdate(data?: IndexedContactData) {
    if (this.onUpdateContact) {
      this.onUpdateContact(data);
    }
  }

  triggerDelete(id?: string) {
    if (this.onDeleteContact) {
      this.onDeleteContact(id);
    }
  }

  triggerRecentCallDelete(id?: string) { // New method to trigger recent call deletion
    if (this.onDeleteRecentCall) {
      this.onDeleteRecentCall(id);
    }
  }

  triggerStatusUpdate(statusPhone: { 
    // target: string; 
    status: string }) {
    if (this.onStatusUpdate) {
      this.onStatusUpdate(statusPhone);
    }
  }

  // Use the custom fetch function, or fall back to default if not set
  async fetchExternalData(): Promise<CallData[]> {
    if (this.recentCallsFetchFunction) {
      return await this.recentCallsFetchFunction();
    } else {
      console.error("No custom fetch function set for recent calls.");
      return [];
    }
  }

  async fetchExternalContactData(): Promise<IndexedContactData[]> {
    if (this.contactFetchFunction) {
      return await this.contactFetchFunction();
    } else {
      console.error("No custom fetch function set for contacts.");
      return [];
    }
  }
}

export default CallManager;
