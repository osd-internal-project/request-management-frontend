import dayjs from "dayjs";
import { ExternalDatabaseType } from "../context/update-data-transaction-context";
import { CallData, CallStatus, ContactsData, IndexedContactData} from "./transaction-data-type";
import { v4 as uuidv4 } from "uuid";
import { showNotification } from "./notification-handler";

export const CallTransaction = async (
  displayName: string,
  uuid: string,
  status: CallStatus,
  recentCallList: IDBDatabase,
  callData?: ExternalDatabaseType | null
): Promise<void> => {
  const data: CallData = {
    id: uuid,
    name: {
      displayName,
      date: dayjs().format(),
      status,
    },
    target: displayName,
  };

  try {
    const tx = recentCallList.transaction("RecentLists", "readwrite");
    const store = tx.objectStore("RecentLists");

    const request = store.put(data);

    return new Promise<void>((resolve) => {
      request.onsuccess = () => {
          callData?.callManager.triggerUpdate(data);
        resolve();
      };

      request.onerror = () => {
        console.error("Failed to save data to IndexedDB", request.error);
        resolve();
      };

      tx.onabort = () => {
        console.error("Transaction was aborted");
        resolve();
      };
    });
  } catch (error) {
    console.error(`Failed to handle transaction for [${displayName}].`, error);
  }
};

export const DeleteFromStore = async (
  id: string,
  storeName: string,
  db: IDBDatabase,
  callData?: ExternalDatabaseType | null,
): Promise<void> => {
  try {
    const tx = db.transaction(storeName, "readwrite");

    const store = tx.objectStore(storeName);

    // Retrieve the data before deletion
    const getRequest = store.get(id);

    getRequest.onsuccess = () => {
      // const fullContactData = getRequest.result as IndexedContactData;

      const deleteRequest = store.delete(id);
      deleteRequest.onsuccess = () => {
        // console.log(`Successfully deleted ${id} from ${storeName}`);

        if (storeName === "ContactLists" ) {
          callData?.callManager.triggerDelete(id);
        } else  {
          // setRecentData({ id });
          callData?.callManager.triggerRecentCallDelete(id);
        }
      };

      deleteRequest.onerror = () => {
        console.error(`Error deleting ${id} from store ${storeName}:`, deleteRequest.error);
      };
    };

    getRequest.onerror = () => {
      console.error(`Error retrieving ${id} from store ${storeName}:`, getRequest.error);
    };

    tx.onabort = () => {
      console.error("Transaction was aborted");
    };

  } catch (error) {
    console.error("Error handling delete operation:", error);
  }
};


export const UpdateFavoriteStatus = async (
  id: string,
  favorite: boolean,
  db: IDBDatabase,
  callData?: ExternalDatabaseType | null
): Promise<void> => {
  try {
    const tx = db.transaction("ContactLists", "readwrite");
    const store = tx.objectStore("ContactLists");

    const getRequest = store.get(id);

    return new Promise<void>((resolve) => {
      getRequest.onsuccess = () => {
        const contact : IndexedContactData = getRequest.result;
        if (contact) {
          const updatedContact : IndexedContactData = {
            ...contact,
            name: {
              ...contact.name,
              favorite,
            },
          };
          const putRequest = store.put(updatedContact);
          putRequest.onsuccess = () => {
            callData?.callManager.triggerContactUpdate(updatedContact);
            resolve();
          };
          putRequest.onerror = () => {
            console.error("Failed to update favorite status", putRequest.error);
            resolve();
          };
        } else {
          console.error("Contact not found");
          resolve();
        }
      };

      getRequest.onerror = () => {
        console.error("Failed to get contact", getRequest.error);
        resolve();
      };

      tx.onabort = () => {
        console.error("Transaction was aborted");
        resolve();
      };
    });
  } catch (error) {
    console.error("Error updating favorite status:", error);
  }
};

export const checkDuplicateContact = async (
  db: IDBDatabase,
  number: string
): Promise<boolean> => {
  return new Promise<boolean>((resolve, reject) => {
    const tx = db.transaction("ContactLists", "readonly");
    const store = tx.objectStore("ContactLists");
    const index = store.index("number");
    const getRequest = index.get(number);

    getRequest.onsuccess = () => {
      resolve(!!getRequest.result);
    };

    getRequest.onerror = () => {
      console.error("Error checking for duplicate contact:", getRequest.error);
      reject(getRequest.error);
    };
  });
};


export const AddContactToStore = async (
  db: IDBDatabase,
  contactData: ContactsData,
  callData?: ExternalDatabaseType | null, // Include callData to handle callManager updates
): Promise<void> => {

  const newId = uuidv4();
  const data : IndexedContactData  = {
    id: newId,
    name: {
      displayName: contactData.displayName,
      number: contactData.number,
      favorite: false,
    },
    date: dayjs().format(),
  };

  try {
    const tx = db.transaction("ContactLists", "readwrite");
    const store = tx.objectStore("ContactLists");

    const request = store.put(data);

    return new Promise<void>((resolve) => {
      request.onsuccess = () => {
        callData?.callManager.triggerContactUpdate(data);
        resolve();
      };

      request.onerror = () => {
        console.error("Error adding contact to store:", request.error);
        resolve();
      };

      tx.onabort = () => {
        console.error("Transaction was aborted");
        resolve();
      };
    });
  } catch (error) {
    console.error("Error handling add contact operation:", error);
  }
};

export const UpdateContact = async (
  contactId: string,
  contactData: ContactsData,
  recentCallList: IDBDatabase,
  callData?: ExternalDatabaseType | null,
): Promise<void> => {
  try {
    const tx = recentCallList.transaction("ContactLists", "readwrite");
    const store = tx.objectStore("ContactLists");

    const getRequest = store.get(contactId);

    return new Promise<void>((resolve) => {
      getRequest.onsuccess = () => {
        const existingRecord = getRequest.result;
        if (existingRecord) {
          existingRecord.name.displayName = contactData.displayName;
          existingRecord.name.number = contactData.number;
          const putRequest = store.put(existingRecord);
          putRequest.onsuccess = () => {

            callData?.callManager.triggerContactUpdate(existingRecord);

            resolve();
          };
          putRequest.onerror = () => {
            console.error("Failed to update contact", putRequest.error);
            resolve();
          };
        } else {
          const newRecord = {
            id: contactId,
            name: { ...contactData,
              favorite: false,
             },
            date:dayjs().format(),
          };
          const addRequest = store.add(newRecord);
          addRequest.onsuccess = () => {
            callData?.callManager.triggerContactUpdate(newRecord);
            resolve();
          };
          addRequest.onerror = () => {
            console.error("Failed to add new contact", addRequest.error);
            resolve();
          };
        }
      };

      getRequest.onerror = () => {
        console.error("Failed to get contact", getRequest.error);
        resolve();
      };

      tx.onabort = () => {
        console.error("Transaction was aborted");
        resolve();
      };
    });
  } catch (error) {
    console.error("Error updating contact:", error);
  }
};

export const hangupWhenError = async (
  error: any,
  displayName: any,
  uuid: string,
  status: CallStatus,
  recentCallList: IDBDatabase,
  callData: ExternalDatabaseType | null,
  setUUID: (uuid: string) => void,
  setFetch: (fetch: boolean) => void
) => {
  if (!String(error).includes("Peer connection closed")) {
    console.error(`[${displayName}] Unable to connect.`);
    console.error(error);
    showNotification("error", `[${displayName}] Unable to connect.`);
  } else {
    await CallTransaction(displayName, uuid, status, recentCallList, callData);
    setUUID(uuidv4());
    setFetch(true);
    callData?.callManager.triggerStatusUpdate({ status: "Hangup" });
  }
};
