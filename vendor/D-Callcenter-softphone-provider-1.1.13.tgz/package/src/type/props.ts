export type PropsReact = {
    children: React.ReactNode
  }