export { default as SoftPhoneProvider } from "./soft-phone-provider";
export * from "./soft-phone-provider";

export { default as useSoftPhoneUser } from "./context/soft-phone-user-context";
export * from "./context/soft-phone-user-context";

export { default as useSelectStatusContext } from "./context/select-status-context";
export * from "./context/select-status-context";

export { default as useExternalDatabase } from "./context/update-data-transaction-context";
export * from "./context/update-data-transaction-context";

export { default as useCallToReceive } from "./lib/call-to-receive";
export * from "./lib/call-to-receive";

export type { CallData, IndexedContactData } from "./lib/transaction-data-type";
export * from "./lib/transaction-data-type";
