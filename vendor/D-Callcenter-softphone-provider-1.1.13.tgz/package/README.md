## SoftPhone widget

[![npm version](https://badge.fury.io/js/softphone-provider.svg)](https://badge.fury.io/js/softphone-provider)

<p align="center">
  <a href="https://www.osd.co.th" rel="noopener" target="_blank"><img width="150" height="133" src="https://www.osd.co.th/wp-content/uploads/2024/05/osd_logo.png" alt="OSD Company logo"></a>
</p>

<h1 align="center">SoftPhone Widget</h1>

**SoftPhone Widget** Package SIP Call Component:

## Installation

### set regis package

if use npm
add .npmrc

```yml
@D-Callcenter:registry=https://npm.pkg.github.com/
//npm.pkg.github.com/:_authToken={{PERSONAL_TOKEN}}
```

if use yarn
add .npmrc

```yml
@D-Callcenter:registry=https://npm.pkg.github.com/
//npm.pkg.github.com/:_authToken={{PERSONAL_TOKEN}}
```

add .yarnrc

```yml
npmScopes:
  "@D-Callcenter":
    npmAlwaysAuth: true
    npmAuthToken: { { PERSONAL_TOKEN } } # optional
    npmRegistryServer: "https://npm.pkg.github.com"
```

### Install via package.json

```json
"@d-callcenter/softphone-provider": "1.0.0-alpha-24"
```

or

```json
"@d-callcenter/softphone-provider": "{{version}}"
```

```bash
yarn
```

```bash
npm install
```

or

```bash
yarn config set @D-Callcenter:registry https://npm.pkg.github.com
```

```bash
yarn config set //npm.pkg.github.com/:_authToken {{token}}
```

```bash
yarn add @d-callcenter/softphone-provider
```

# Documentation

## Overall

```tsx
type SoftPhoneUserType = {
  socketServer: string;
  username: string;
  password: string;
  ipServer: string;
  displayName: string;
  organizeName: string;
  iconOnline?: React.ReactNode;
  iconOffline?: React.ReactNode;
  externalDatabase?: boolean;
  isUserFavoriteVisible: boolean;
  isUserRecentVisible: boolean;
  isUserContactVisible: boolean;
  isUserNumpadVisible: boolean;
  ringtoneCallUrl: string;
  ringtoneReceiveUrl: string;
};
```

| Name                  | Required? | Description                                  |
| --------------------- | --------- | -------------------------------------------- |
| username              | yes       | username                                     |
| password              | yes       | password                                     |
| socketServer          | yes       | socket server                                |
| ipServer              | yes       | ip server                                    |
| organizeName          | no        | organize name                                |
| displayName           | no        | name                                         |
| iconOnline            | no        | icon for online appear                       |
| iconOffline           | no        | icon for offline appear                      |
| isUserFavoriteVisible | no        | Control visibility of the favorite button    |
| isUserRecentVisible   | no        | Control visibility of the recent button      |
| isUserContactVisible  | no        | Control visibility of the contact button     |
| isUserNumpadVisible   | no        | Control visibility of the numpad button      |
| ringtoneCallUrl       | no        | URL for the ringtone during an outgoing call |
| ringtoneReceiveUrl    | no        | URL for the ringtone during an incoming call |
| externalDatabase      | no        | enabled external database                    |

### Set Voice Server WebSocket ,Username,Password

```js
import { SoftPhoneProvider } from "softphone-provider";

<SoftPhoneProvider>
  <App />
</SoftPhoneProvider>;
```

```javascript
import { useSoftPhoneUser } from "softphone-provider";
Auth?.set({
  socketServer: "wss://dcall.dcontact.osd.co.th:18089/ws",
  username: "9001",
  password: "9001Dcall@plsa!",
  ipServer: "dcall.dcontact.osd.co.th:18089",
});
```

### Theme Customization

add from antd theme

```javascript
const settheme = {
  algorithm: theme.darkAlgorithm,
  components: {
    Card: {
      zIndexPopup: 2000,
    },
  },
};

<SoftPhoneProvider settheme={settheme}>
  <App />
</SoftPhoneProvider>;
```

OR
other UI framework

```javascript
const settheme = {
  token: {
    // Seed Token
    colorPrimary: "#00b96b",
    borderRadius: 2,
    // Alias Token
    colorBgContainer: "#f6ffed",
  },
  ...other_props,
};

<SoftPhoneProvider settheme={settheme}>
  <App />
</SoftPhoneProvider>;
```

### Status

1. **setStatusList**: Updates the list of available status options. In this example, we provide a static list (`menuList`) containing `name` values "Ready" and "Lunch".

2. **setDisplayField**: Specifies which field in the status list objects will be displayed in the UI. In this case, the `name` field is displayed.

3. **setOnSelect**: Registers a callback function (`testFunction`) that is triggered when a status is selected. The selected status is passed as an argument to this function.

4. **testFunction**: A sample function that currently logs the selected status to the console. Replace this with your desired logic.

| Name  | Required? | Description                  |
| ----- | --------- | ---------------------------- |
| id    | yes       | Unique identifier for status |
| label | yes       | Name of the status           |
| icon  | no        | Icon for displaying status   |

```tsx
import React, { useEffect } from "react";
import { useSelectStatusContext } from "@D-Callcenter/softphone-provider";

const App = () => {
  const { selectedStatus } = useSelectStatusContext();

  useEffect(() => {
    // Call your function when selectedStatus changes
    yourFunction();
  }, [selectedStatus]);

  const yourFunction = () => {
    // Use selectedStatus in your function
    console.log("Selected Status:", selectedStatus);
  };

  return <div>Your Component Content</div>;
};

export default App;
```

### Custom Example For Status

To provide a custom list of statuses, you can use the following setup:

```tsx
import { useSelectStatusContext } from "@D-Callcenter/softphone-provider";
import { CoffeeOutlined, UserOutlined } from "@ant-design/icons";

function App() {
  const Auth = useSoftPhoneUser();
  const {
    setStatusList,
    setDisplayField,
    setOnSelect,
    selectedStatus,
    setPlaceholder,
  } = useSelectStatusContext();

  const menuList = [
    {
      id: 1,
      label: "Ready",
      icon: <UserOutlined style={{ color: "green" }} />,
    },
    {
      id: 2,
      label: "Lunch",
      icon: <CoffeeOutlined style={{ color: "orange" }} />,
    },
  ];
  React.useEffect(() => {
    Auth?.set({
      socketServer: "wss://dcall.dcontact.osd.co.th:18089/ws",
      username: "9001",
      password: "9001Dcall@plsa!",
      ipServer: "dcall.dcontact.osd.co.th:18089",
      organizeName: "demoOrganizations", // Optional
      displayName: "demoDisplayName", // Optional
    });
  }, []);

  React.useEffect(() => {
    setDisplayField("id"); // Set displayField before setting the status list
    setStatusList(menuList);  // Then set the list
    setPlaceholder("custom");
    setOnSelect(() => testFunction);
  }, []);

  const testFunction = (selectValue: any) => {
    // Your logic here
    console.log(selectValue, "Test");
  };

  return;
  <div>Your Component Content</div>;
}

export default App;
```

### Custom Float Button

- iconOnline:

  - Defines the icon that will be displayed when the user is online and the card is minimized.

- iconOffline:

  - Defines the icon that will be displayed when the user is offline and the card is minimized.

```tsx
import React from "react";
import { Auth } from "@D-Callcenter/softphone-provider";
import { CoffeeOutlined, UserOutlined } from "@ant-design/icons";

const App = () => {
  React.useEffect(() => {
    Auth?.set({
      ...other,
      iconOnline: <CoffeeOutlined />, // Optional
      iconOffline: <UserOutlined />, // Optional
    });
  }, []);

  return <div>Your Component Content</div>;
};

export default App;
```

### Feature Call External

```tsx
import React from "react";
import { useCallToReceive } from "@D-Callcenter/softphone-provider";

function App() {
  const { callToReceive } = useCallToReceive();
  const phoneNumbers = ["4006", "4008", "4009"];

  const handleCallToReceive = async (target: string) => {
    await callToReceive(target);
  };

  return (
    <div className="App">
      <header className="App-header">
        {phoneNumbers.map((number) => (
          <button key={number} onClick={() => handleCallToReceive(number)}>
            Call {number}
          </button>
        ))}
      </header>
    </div>
  );
}

export default App;
```

### Active Button

Default is `true` for `isUserContactVisible,isUserFavoriteVisible,isUserNumpadVisible,isUserRecentVisible` Can hide by set to `False`

```tsx
import React from "react";
import { Auth } from "@D-Callcenter/softphone-provider";

const App = () => {
  React.useEffect(() => {
    Auth?.set({
      ...other,
      isUserContactVisible:false,
      isUserFavoriteVisible: false,
      isUserNumpadVisible: false,
      isUserRecentVisible: false,
    });
  }, []);

  return <div>Your Component Content</div>;
};

export default App;
```

### Change Ringtone

You can customize the ringtone for calls by updating the following configurations:

- ringtoneCallUrl: URL for the ringtone used when making calls.
- ringtoneReceiveUrl: URL for the ringtone used when receiving calls.

Both fields support `.mp3` and `.wav` formats. If you want to use a local file, you can save the audio file in the `public` folder and provide the relative path.

```tsx
import {
  useSoftPhoneUser
} from "@D-Callcenter/softphone-provider";
import React, { useState, useEffect } from "react";

function App() {
  const Auth = useSoftPhoneUser();

  useEffect(() => {
    Auth?.set({
      ...other,
      ringtoneCallUrl: "/mixkit-keyboard-typing-1386.wav", // Path to local file
      ringtoneReceiveUrl: "/mixkit-game-show-suspense-waiting-667.wav", // Path to local file
    });
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        
      </header>
    </div>
  );
}

export default App;

```

### Trigger Data and Status

`import { useExternalDatabase } from "@D-Callcenter/softphone-provider";` is core for this and then in function add `const callData = useExternalDatabase();`

`callManager.onSessionStatusUpdate` is for get status when `Calling` or `Hangup`

```tsx
callData?.callManager.onSessionStatusUpdate((statusPhone) => {
    setStatusObj(statusPhone);
    console.log("Status updated:", statusPhone);
  });

  // Status updated: {status: 'Calling'}
  // Status updated: {status: 'Hangup'}
```

`callManager.onCall` is for get Call Data when has call.

```tsx
callData?.callManager.onCall((data) => {
    if (data) {
      console.log("Received Call Data:", data);
    }
  });

  // Received Call Data: {id: '0056a99f-f6ca-4cff-b382-a3da49a709d6', name: {…}, target: '4009'}

// id : "0056a99f-f6ca-4cff-b382-a3da49a709d6"
// name : 
//  date : "2024-10-15T10:29:28+07:00"
//  displayName : "4009"
//  status : "call"
// target : "4009"
```

`callManager.onContactUpdate` is for get when have something update or create in contact list.

```tsx
callData?.callManager.onContactUpdate((contact) => {
    if (contact) {
      console.log("Received Contact Data:", contact);
    }
  });
  
  // Received Contact Data: {id: '45cab59b-b92f-4356-8bc6-856abf3a4353', name: {…}, date: '2024-10-15T10:30:22+07:00'}

// date : "2024-10-15T10:30:57+07:00"
// id : "3699e996-464a-4e91-8049-627c61bf063d"
// name : 
//  displayName : "1111"
//  favorite : false
//  number : "1111"
```

`callManager.onContactDelete` is for get id when delete something in Contact list.

```tsx
callData?.callManager.onContactDelete((id) => {
    if (id) {
      console.log("Deleted Contact ID:", id);
    }
  });

  // Deleted Contact ID: 3699e996-464a-4e91-8049-627c61bf063d
```

`callManager.onRecentCallDelete` is for get id when delete something in Recent Call list.

```tsx
callData?.callManager.onRecentCallDelete((id) => {
    if (id) {
      console.log("Deleted Recent Call ID:", id);
    }
  });

  // Deleted Recent Call ID: 4edba0c4-9894-43e8-a8e9-923ce9bafa66
```

Example Usage

```tsx
import {
  useSoftPhoneUser,
  useExternalDatabase,
} from "@D-Callcenter/softphone-provider";
import React, { useState, useEffect } from "react";
import "./App.css";
import dayjs from "dayjs";

function App() {
  const Auth = useSoftPhoneUser();

  const callData = useExternalDatabase();

  const [statusObj, setStatusObj] = useState(null);

  useEffect(() => {
    Auth?.set({
      socketServer: "wss://dphonedemo.osd.co.th:18089/ws",
      username: "4009",
      password: "4009Dcall@plsa!",
      ipServer: "dphonedemo.osd.co.th:18089",
    });
  }, []);

  callData?.callManager.onCall((data) => {
    if (data) {
      console.log("Received Call Data:", data);
      setRecentCallData((prevData) => [...prevData, data]);
    }
  });

  callData?.callManager.onContactUpdate((contact) => {
    if (contact) {
      console.log("Received Contact Data:", contact);
      setContactData((prevContacts) => [...prevContacts, contact]);
    }
  });

  callData?.callManager.onContactDelete((id) => {
    if (id) {
      console.log("Deleted Contact ID:", id);
      setDeletedContactIds((prevIds) => [...prevIds, id]);
    }
  });

  callData?.callManager.onRecentCallDelete((id) => {
    if (id) {
      console.log("Deleted Recent Call ID:", id);
      setDeletedCallIds((prevIds) => [...prevIds, id]);
    }
  });

  callData?.callManager.onSessionStatusUpdate((statusPhone) => {
    setStatusObj(statusPhone);
    console.log("Status updated:", statusPhone);
  });

  const sortedRecentCalls = [...recentCallData].sort(
    (a, b) => dayjs(b.name.date).unix() - dayjs(a.name.date).unix()
  );

  return (
    <div className="App">
      <header className="App-header">
        <button onClick={() => handleCallToReceive(displayName)}>Call</button>
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        {statusObj && (
          <div className="status-container">
            <h2>Status Update</h2>
            <p>Status: {statusObj.status}</p>
          </div>
        )}

        <h1>Softphone Call and Contact Data</h1>

        <h2>Recent Call Data</h2>
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Date</th>
              <th>Status</th>
              <th>Target</th>
            </tr>
          </thead>
          <tbody>
            {sortedRecentCalls.map((item, index) => (
              <tr key={`${item.id}-${index}`}>
                <td>{item.name.displayName}</td>
                <td>{new Date(item.name.date).toLocaleString()}</td>
                <td>{item.name.status}</td>
                <td>{item.target}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <h2>Contact Data</h2>
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Number</th>
              <th>Favorite</th>
            </tr>
          </thead>
          <tbody>
            {contactData.map((item, index) => (
              <tr key={`${item.id}-${index}`}>
                <td>{item.name.displayName}</td>
                <td>{item.name.number}</td>
                <td>{item.name.favorite ? "Yes" : "No"}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <h2>Deleted Recent Call IDs</h2>
        <ul>
          {deletedCallIds.map((id, index) => (
            <li key={index}>{id}</li>
          ))}
        </ul>

        <h2>Deleted Contact IDs</h2>
        <ul>
          {deletedContactIds.map((id, index) => (
            <li key={index}>{id}</li>
          ))}
        </ul>
      </header>
    </div>
  );
}

export default App;
```

### External Database

For connect with External Database need to enabled `externalDatabase:True` default is `False`

Example Usage

```tsx
import {
  useSoftPhoneUser,
  useExternalDatabase,
} from "@D-Callcenter/softphone-provider";
import React, { useState, useEffect } from "react";
import "./App.css";
import dayjs from "dayjs";

const demoRecentCalls = [
  {
    call_id: '1',
    user_info: {
      full_name: 'John Doe',
      call_time: '2024-09-30T10:45:00',
      call_status: 'call',
    },
    target_number: '12345',
  },
  {
    call_id: '2',
    user_info: {
      full_name: 'Jane Smith',
      call_time: '2024-09-28T15:30:00',
      call_status: 'declined',
    },
    target_number: '67890',
  },
  {
    call_id: '3',
    user_info: {
      call_time: '2024-09-28T15:30:00',
      call_status: 'received',
    },
    target_number: '4000',
  },
  {
    call_id: '4',
    user_info: {
      call_time: '2024-09-28T15:20:00',
      call_status: 'call',
    },
    target_number: '4040',
  },
];

const demoContactCalls = [
  {
    contact_id: '1',
    user: {
      name: 'John Doe',
      phone_number: '12345',
      is_fav: true,
    },
    contact_date: '2024-09-30',
  },
  {
    contact_id: '2',
    user: {
      name: 'Jane Smith',
      phone_number: '67890',
      is_fav: false,
    },
    contact_date: '2024-09-28',
  },
];

// Mapping function recent calls
const mapCallData = (data: any): CallData => ({
  id: data.call_id,
  name: {
    displayName: data.user_info.full_name,
    date: data.user_info.call_time,
    status: data.user_info.call_status,
  },
  target: data.target_number,
});

// Mapping function contacts
const mapContactData = (data: any): IndexedContactData => ({
  id: data.contact_id,
  name: {
    displayName: data.user.name,
    number: data.user.phone_number,
    favorite: data.user.is_fav,
  },
  date: data.contact_date,
});
function App() {
  const Auth = useSoftPhoneUser();
  const { callToReceive } = useCallToReceive();

  const callData = useExternalDatabase();

  useEffect(() => {
    Auth?.set({
      ...other,
      externalContactCallListDatabase: true,
      externalRecentCallListDatabase: true,
    });
  }, []);

  // Set the fetch function for recent calls using GraphQL
  callData?.callManager.setRecentCallsFetchFunction(() =>
    Promise.resolve(demoRecentCalls.map(mapCallData))
  );

  // Set the fetch function for contacts using GraphQL
  callData?.callManager.setContactFetchFunction(() =>
    Promise.resolve(demoContactCalls.map(mapContactData))
  );

  return ();
}
export default App;
```
